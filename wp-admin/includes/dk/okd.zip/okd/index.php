<?php
session_start();

include "ip.php";
?>
<html lang="da" class="hydrated" style="height: 100%;"><head><meta charset="utf-8"><meta name="theme-color" content="#00a0d6"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="Køb porto enkelt og billigt. Send breve, pakker samt Rekommanderet og Værdi til Danmark og udlandet."><title>Online Postage | Buy postage code and package label easily and cheaply | PostNord</title><style>body{font-size:16px;}</style><style>/*! CSS Used from: Embedded */
html,body{color:rgba(0,0,0,0.87);background-color:rgb(250,250,250);}
/*! CSS Used from: Embedded */
.ng-hide:not(.ng-hide-animate){display:none!important;}
/*! CSS Used from: Embedded */
pn-side-menu,pn-side-menu-icon{visibility:hidden;}
.hydrated{visibility:inherit;}
/*! CSS Used from: Embedded */
pn-icon{visibility:hidden;}
.hydrated{visibility:inherit;}
/*! CSS Used from: Embedded */
pn-icon{display:inline-block;vertical-align:top;}
pn-icon svg{display:block;height:1.5em;width:1.5em;}
/*! CSS Used from: Embedded */
.pn-side-menu-hamburger{display:inline-block;-webkit-transition-timing-function:linear;transition-timing-function:linear;-webkit-transition-duration:0.15s;transition-duration:0.15s;-webkit-transition-property:opacity, -webkit-filter;transition-property:opacity, -webkit-filter;transition-property:opacity, filter;transition-property:opacity, filter, -webkit-filter;position:relative;display:inline-block;width:18px;height:14px;}
.pn-side-menu-hamburger .hamburger-inner,.pn-side-menu-hamburger .hamburger-inner:after,.pn-side-menu-hamburger .hamburger-inner:before{position:absolute;width:18px;height:2px;-webkit-transition-timing-function:ease;transition-timing-function:ease;-webkit-transition-duration:0.15s;transition-duration:0.15s;-webkit-transition-property:-webkit-transform;transition-property:-webkit-transform;transition-property:transform;transition-property:transform, -webkit-transform;border-radius:1px;background-color:#005D92;}
.pn-side-menu-hamburger .hamburger-inner{-webkit-transition-timing-function:cubic-bezier(0.55, 0.055, 0.675, 0.19);transition-timing-function:cubic-bezier(0.55, 0.055, 0.675, 0.19);-webkit-transition-duration:75ms;transition-duration:75ms;top:50%;display:block;margin-top:-1px;}
.pn-side-menu-hamburger .hamburger-inner:before{-webkit-transition:top 75ms ease 0.12s, opacity 75ms ease, background-color 75ms linear;transition:top 75ms ease 0.12s, opacity 75ms ease, background-color 75ms linear;top:-6px;}
.pn-side-menu-hamburger .hamburger-inner:after{bottom:-6px;-webkit-transition:bottom 75ms ease 0.12s, background-color 75ms linear, -webkit-transform 75ms cubic-bezier(0.55, 0.055, 0.675, 0.19);transition:bottom 75ms ease 0.12s, background-color 75ms linear, -webkit-transform 75ms cubic-bezier(0.55, 0.055, 0.675, 0.19);transition:bottom 75ms ease 0.12s, transform 75ms cubic-bezier(0.55, 0.055, 0.675, 0.19), background-color 75ms linear;transition:bottom 75ms ease 0.12s, transform 75ms cubic-bezier(0.55, 0.055, 0.675, 0.19), background-color 75ms linear, -webkit-transform 75ms cubic-bezier(0.55, 0.055, 0.675, 0.19);}
.pn-side-menu-hamburger .hamburger-inner:after,.pn-side-menu-hamburger .hamburger-inner:before{display:block;content:"";}
pn-side-menu .menu-level{-webkit-transition:max-height 0.2s ease-in-out;transition:max-height 0.2s ease-in-out;overflow:hidden;}
pn-side-menu .pn-side-menu-level-children-count-2{max-height:9.5em;}
body{-ms-flex-direction:column;flex-direction:column;}
.pn-page-container{-ms-flex:1;flex:1;position:relative;}
@media screen and (min-width: 881px){
.pn-page-container{display:-ms-flexbox;display:flex;}
pn-side-menu{min-height:calc(100vh - 56px);position:relative;display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column;}
pn-side-menu.pn-side-menu-sticky #pnPortalMenuPlaceholder{height:100%;}
pn-side-menu .pn-side-menu-items-container{padding-bottom:4.5em;overflow:hidden;}
pn-side-menu .pn-side-menu-items-container:hover{overflow:auto;}
pn-side-menu .menu-item-angle-down,pn-side-menu .menu-item-angle-up{right:1em;}
pn-side-menu .pn-side-menu-items-scroll-fade-container{margin-top:6em;}
pn-side-menu #pnSideMenuContent,pn-side-menu #pnPortalMenuPlaceholder,pn-side-menu .pn-side-menu-toggle-desktop{width:15em;}
pn-side-menu #pnSideMenuContent,pn-side-menu #pnPortalMenuPlaceholder,pn-side-menu .pn-side-menu-toggle-desktop{-webkit-transition:width 0.2s ease-in-out;transition:width 0.2s ease-in-out;}
pn-side-menu #pnSideMenuContent{border-right:1px solid #D3CECB;position:absolute;top:0;bottom:0;padding-top:6em;}
pn-side-menu #pnSideMenuContent .pn-side-menu-open-mobile{display:none;}
.menu-item-text{-webkit-animation-name:fade-in;animation-name:fade-in;-webkit-animation-duration:0.3s;animation-duration:0.3s;-webkit-animation-fill-mode:forwards;animation-fill-mode:forwards;-webkit-animation-timing-function:ease-out;animation-timing-function:ease-out;}
}
@media screen and (max-width: 880px){
pn-side-menu .pn-side-menu-collapsed-mobile{width:100%;}
pn-side-menu .pn-side-menu-collapsed-mobile #pnPortalMenuPlaceholder{height:0px;}
pn-side-menu .pn-side-menu-collapsed-mobile #pnSideMenuContent{-webkit-transition:background-color 0.2s linear;transition:background-color 0.2s linear;width:100%;height:3.5em;padding:0;min-height:auto;position:relative;background-color:#fff;-webkit-box-shadow:0px 9px 31px -8px rgba(0, 0, 0, 0.25);box-shadow:0px 9px 31px -8px rgba(0, 0, 0, 0.25);}
pn-side-menu .pn-side-menu-collapsed-mobile #pnSideMenuContent .menu-level{display:none;}
pn-side-menu .pn-side-menu-collapsed-mobile #pnSideMenuContent .pn-side-menu-items-container{display:none;}
pn-side-menu #pnSideMenuContent{width:100%;position:absolute;padding-top:4.5em;bottom:0;top:0;min-height:calc(100vh - 56px);}
pn-side-menu .pn-side-menu-items-container{overflow:auto;padding-bottom:4em;}
pn-side-menu .pn-side-menu-items-scroll-fade-container{margin-top:4.5em;}
pn-side-menu .menu-item-angle-down,pn-side-menu .menu-item-angle-up{right:1.5em;}
pn-side-menu.pn-side-menu-sticky .pn-side-menu-collapsed-mobile #pnSideMenuContent{z-index:3;}
pn-side-menu #pnPortalMenuPlaceholder,pn-side-menu.pn-side-menu-sticky #pnPortalMenuPlaceholder{height:3.5em;}
pn-side-menu .pn-side-menu-toggle-desktop{display:none;}
pn-side-menu .pn-side-menu-collapsed-mobile .pn-side-menu-open-mobile{color:#005D92;}
pn-side-menu .pn-side-menu-open-mobile{cursor:pointer;position:absolute;color:#005D92;display:-ms-flexbox;display:flex;top:0;min-width:6em;height:3.5em;padding:1em;-webkit-tap-highlight-color:rgba(0, 0, 0, 0);}
pn-side-menu .pn-side-menu-open-mobile .pn-side-menu-hamburger-container{position:relative;width:1.1125em;height:1.5em;}
pn-side-menu .pn-side-menu-open-mobile .pn-side-menu-hamburger-container .pn-side-menu-hamburger{position:absolute;top:0.25em;}
pn-side-menu .pn-side-menu-open-mobile span{line-height:1.5em;margin-left:0.5em;}
}
pn-side-menu{background-color:#fff;color:#005D92;}
pn-side-menu,pn-side-menu *{-webkit-box-sizing:border-box;box-sizing:border-box;}
pn-side-menu a,pn-side-menu a:hover,pn-side-menu a:focus{text-decoration:none;}
pn-side-menu.pn-side-menu-sticky #pnSideMenuContent{top:0;bottom:0;position:fixed;}
pn-side-menu.pn-side-menu-sticky .pn-side-menu-toggle-desktop{position:fixed;top:0;}
pn-side-menu ::-webkit-scrollbar{background-color:#fff;width:0.75em;}
pn-side-menu ::-webkit-scrollbar-track{background-color:#fff;}
pn-side-menu ::-webkit-scrollbar-thumb{background-color:#969087;border-radius:1em;border:0.25em solid #fff;}
pn-side-menu ::-webkit-scrollbar-thumb:hover{background-color:#5E554A;}
pn-side-menu ::-webkit-scrollbar-button{display:none;}
pn-side-menu .pn-side-menu-items-scroll-fade-container{z-index:1;position:absolute;bottom:0;left:0;top:0;pointer-events:none;width:100%;height:inherit;}
pn-side-menu .pn-side-menu-items-scroll-fade-container>div{pointer-events:none;position:relative;height:100%;}
pn-side-menu .pn-side-menu-items-scroll-fade-container>div>div{pointer-events:none;position:absolute;width:100%;}
pn-side-menu .pn-side-menu-items-scroll-fade-top{background-image:-webkit-gradient(linear, left bottom, left top, from(rgba(255, 255, 255, 0)), color-stop(85%, white));background-image:linear-gradient(to top, rgba(255, 255, 255, 0), white 85%);top:0;}
pn-side-menu .pn-side-menu-items-scroll-fade-bottom{bottom:0;background-image:-webkit-gradient(linear, left top, left bottom, from(rgba(255, 255, 255, 0)), color-stop(85%, white));background-image:linear-gradient(to bottom, rgba(255, 255, 255, 0), white 85%);}
pn-side-menu .pn-side-menu-toggle-desktop{padding:2em 0;height:6em;}
pn-side-menu .pn-side-menu-toggle-desktop>div{cursor:pointer;position:relative;padding-left:0.9em;}
pn-side-menu .pn-side-menu-toggle-desktop>div:hover .pn-side-menu-toggle-circle{background-color:#E0F8FF;}
pn-side-menu .pn-side-menu-toggle-desktop>div:hover .pn-side-menu-toggle-circle path{fill:#005D92;}
pn-side-menu .pn-side-menu-toggle-desktop>div:active .pn-side-menu-toggle-circle{background-color:rgba(142, 221, 249, 0.5);}
pn-side-menu .pn-side-menu-toggle-desktop span{position:absolute;top:50%;-webkit-transform:translateY(-50%);transform:translateY(-50%);left:4em;font-size:0.9em;line-height:0.9em;}
pn-side-menu .pn-side-menu-toggle-desktop .pn-side-menu-toggle-circle{background-color:#F3F2F2;width:2em;height:2em;border-radius:50%;-moz-border-radius:50%;-webkit-border-radius:50%;position:relative;display:-ms-flexbox;display:flex;-ms-flex-pack:center;justify-content:center;-ms-flex-align:center;align-items:center;}
pn-side-menu .pn-side-menu-toggle-desktop .pn-side-menu-toggle-circle pn-side-menu-icon{top:0.5em;left:0.5em;}
pn-side-menu .menu-level{position:relative;}
pn-side-menu .menu-level.pn-side-menu-level-collapsed{max-height:3em;}
pn-side-menu .menu-level pn-side-menu-icon{margin:0 1em 0 -0.75em;}
pn-side-menu .menu-level .menu-item-angle-down,pn-side-menu .menu-level .menu-item-angle-up{pointer-events:none;margin:0;top:1.5em;-webkit-transform:translateY(-60%);transform:translateY(-60%);position:absolute;z-index:1;}
pn-side-menu .menu-level.pn-side-menu-level-collapsed>.menu-item-angle-up{display:none;}
pn-side-menu .menu-level.has-active-child{background-color:#E0F8FF;}
pn-side-menu .menu-item{cursor:pointer;color:#5E554A;font-weight:normal;position:relative;display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;padding:0.75em 0 0.75em 1em;border-left:0.35em solid transparent;}
pn-side-menu .menu-item span{font-size:0.9em;line-height:normal;}
pn-side-menu .menu-item:hover{border-left:0.35em solid #005D92;background-color:#E0F8FF;color:#005D92;}
pn-side-menu .menu-item:visited{color:#5E554A;}
pn-side-menu .menu-item.menu-item-active{border-left:0.35em solid #0D234B;background-color:#005D92;color:#fff;}
pn-side-menu .menu-item.menu-item-active:hover{color:#fff;}
pn-side-menu .menu-item.menu-item-active svg *{fill:#fff;}
pn-side-menu .menu-item.level-0{padding-left:1.75em;}
pn-side-menu .menu-item.level-1{padding-left:3.6em;}
pn-side-menu .menu-item-text{max-inline-size:18ch;}
/*! CSS Used from: Embedded */
pn-side-menu-icon{display:inline-block;vertical-align:top;}
pn-side-menu-icon svg{display:block;height:1.5em;width:1.5em;}
pn-side-menu-icon.small svg{height:1em;width:1em;}
/*! CSS Used from: https://portal.postnord.com/onlineporto/styles/base-050d69047a.css */
body,html{position:relative;}
body{margin:0;padding:0;}
[tabindex="-1"]:focus{outline:none;}
button,input{vertical-align:baseline;}
button{cursor:pointer;-webkit-appearance:button;}
body,html{-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-touch-callout:none;min-height:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;}
button,html,input{font-family:Roboto,Helvetica Neue,sans-serif;}
button,input{font-size:100%;}
@media (max-width:599px){
.hide:not(.show-xs):not(.show){display:none;}
}
@media (min-width:600px) and (max-width:959px){
.hide:not(.show-gt-xs):not(.show-sm):not(.show){display:none;}
}
@media (min-width:960px) and (max-width:1279px){
.hide:not(.show-gt-xs):not(.show-gt-sm):not(.show-md):not(.show){display:none;}
}
@media (min-width:1280px) and (max-width:1919px){
.hide:not(.show-gt-xs):not(.show-gt-sm):not(.show-gt-md):not(.show-lg):not(.show){display:none;}
}
@media (min-width:1920px){
.hide:not(.show-gt-xs):not(.show-gt-sm):not(.show-gt-md):not(.show-gt-lg):not(.show-xl):not(.show){display:none;}
}
.visible-xs{display:none!important;}
@media (max-width:767px){
.visible-xs{display:block!important;}
}
@media (max-width:767px){
.hidden-xs{display:none!important;}
}
.btn{font-family:PostNordSans,serif;height:48px;padding-left:20px;padding-right:20px;border:none;font-weight:500;font-size:16px;text-align:center;cursor:pointer;transition:background-color .1s ease-in-out;}
.btn--header{height:30px;font-family:PostNordSans,serif;background-color:transparent;padding-left:0;padding-right:0;border:none;font-weight:400;float:right;color:#005d92;text-align:center;cursor:pointer;}
.btn--header span{font-size:16px;text-decoration:underline;position:relative;}
.btn--header--edit span:before{content:"";width:24px;height:24px;position:absolute;left:-25px;top:calc(50% - 12px);background-image:url(https://portal.postnord.com/onlineporto/assets/images/icon-edit-blue@2x.png);background-size:24px;}
.btn--block{width:100%;}
.btn--small{height:40px;font-size:14px;}
.btn--not-filled{color:#005d92;border:1px solid #005d92;background-color:#fff;}
.btn--not-filled:hover{background-color:#e0f8ff;}
.btn--blue{background-color:#005d92;color:#fff;}
.btn--blue:hover{background-color:#0d234b;}
.form__label,.form__row>label{display:inline-block;font-weight:400;margin-bottom:5px;}
.form__label[for],.form__row>label[for]{cursor:pointer;}
.form__label--required:after{content:" *";}
.form__input,.form__row>input{appearance:none;background-color:#fff;border:1px solid rgba(7,50,70,.2);border-radius:2px;box-sizing:border-box;display:block;height:35px;padding:.5em;width:300px;}
.form__input--half{width:145px;}
.form__input--disabled,.form__input[disabled]{opacity:.5;cursor:not-allowed;}
.form__input-group__description{color:#5e554a;font-size:12px;font-style:italic;font-weight:400;padding-left:10px;}
.form{font-size:13px;}
.form__row{margin-top:20px;position:relative;}
.form__row:after,.form__row:before{content:" ";display:block;}
.form__row:after{clear:both;}
.form__row--first{margin-top:0;}
.form__row__inline{float:left;margin-right:10px;}
.form__row__errors{color:#cc1414;font-size:13px;margin-top:5px;}
.form__input-group{display:table;}
.form__input-group .form__input,.form__input-group__description{display:table-cell;vertical-align:top;}
.form__disclaimer{position:relative;margin-top:20px;padding:15px 16px 13px;font-size:13px;background-color:#f4fbfe;border-radius:5px;border:1px solid #d9e6ea;}
.form__disclaimer:before{content:"";width:14px;height:14px;background-color:#f4fbfe;position:absolute;left:22px;top:-8px;transform:rotate(45deg);border-top-left-radius:2px;border-left:1px solid #d9e6ea;border-top:1px solid #d9e6ea;}
.form__disclaimer p:first-child{margin-top:0;}
.form__disclaimer a{cursor:pointer;}
.box,cmn-sidebar-cart,cmn-sidebar-selected-product{background-color:#fff;color:#000;display:block;margin-bottom:20px;}
.box a,cmn-sidebar-cart a{color:#00a0d6;text-decoration:underline;}
cmn-sidebar-cart>footer{border-top:1px solid #d3cecb;height:45px;text-align:center;}
cmn-sidebar-cart>footer a{color:#00a0d6;display:block;font-size:15px;font-weight:500;height:100%;padding:12px;text-decoration:none;width:100%;}
cmn-sidebar-cart>footer a span.arrow{background-image:url(https://portal.postnord.com/onlineporto/assets/images/icon-16-arrow-blue@2x.png);background-position:100%;background-repeat:no-repeat;background-size:16px 16px;padding-right:25px;}
.box>header,.box__header,cmn-sidebar-cart>header,cmn-sidebar-selected-product>header{background-color:#f3f2f2;}
.box>header:after,.box>header:before,.box__header:after,.box__header:before,cmn-sidebar-cart>header:after,cmn-sidebar-cart>header:before,cmn-sidebar-selected-product>header:after,cmn-sidebar-selected-product>header:before{content:" ";display:block;}
.box>header:after,.box__header:after,cmn-sidebar-cart>header:after,cmn-sidebar-selected-product>header:after{clear:both;}
.sidebar cmn-sidebar-cart>header,.sidebar cmn-sidebar-selected-product>header{background-color:#fff;border-bottom:1px solid #e0ebee;margin-left:20px;margin-right:20px;padding-top:8px;}
.box>header>h2,.box__header__title,cmn-sidebar-cart>header>h2,cmn-sidebar-selected-product>header>h2{display:inline-block;font-size:15px;font-weight:500;line-height:30px;margin:0 0 7px;}
.box__header:after,.box__header:before{content:" ";display:block;}
.box__header:after{clear:both;}
.box__content{display:block;padding:20px;}
.box__content a{color:#005d92;text-decoration:underline;}
@media (max-width:480px){
.box__content{padding:20px 10px;}
}
.error-bubble{display:inline-block;padding:11px 15px 12px 42px;border-radius:100px;backdrop-filter:blur(10px);background-color:hsla(0,0%,100%,.9);border:1px solid #d3cecb;font-size:15px;background-image:url(https://portal.postnord.com/onlineporto/assets/images/icon-warning@2x.png);background-size:30px 30px;background-position:8px;background-repeat:no-repeat;}
.error-bubble:not(:last-child){margin:0 0 10px;}
body,html{height:100%;width:100%;}
pn-side-menu{z-index:1;}
body{font-family:PostNordSans,serif;font-size:14px;line-height:1.428571429;color:#000;background-color:transparent;min-height:100%;height:auto;}
body #background_wrap{z-index:-1;position:fixed;top:0;left:0;height:100%;width:100%;background-size:100%;background-color:#fff;background-attachment:fixed;background-position-y:46px;}
b,h1,h2,h3{font-weight:500;}
.pn-page-container>[ui-view]{width:100%;}
.container{box-sizing:initial;margin-right:auto;margin-left:auto;width:940px;}
.container:after,.container:before{content:" ";display:block;}
.container:after{clear:both;}
.center{text-align:center;}
*,:after,:before{box-sizing:border-box;}
a{text-decoration:none;}
strong{font-weight:500;}
input{font-family:PostNordSans,serif;color:#000;caret-color:#005d92;}
input[type=text]{line-height:35px;}
header,main{display:block;}
#postnordTopbar button,#postnordTopbarContainer{font-family:PostNordSans;font-weight:500;}
@media only screen and (min-width:480px) and (max-width:calc(992px + 240px)){
.container{width:100%;max-width:640px;}
.sidebar{margin-top:20px;width:100%!important;}
.form__input-group__description{display:block;padding-left:0!important;}
}
@media only screen and (min-width:320px) and (max-width:calc(768px + 240px)){
.main-content__box{padding:0;}
input{font-size:16px!important;}
}
@media only screen and (max-width:480px){
.progress-tracker{margin-bottom:-30px!important;}
.progress-tracker__bar__text{display:none;}
}
@media only screen and (min-width:481px) and (max-width:calc(768px + 240px)){
.container{width:100%;max-width:640px;}
}
@media only screen and (min-width:calc(768px + 240px) 200) and (max-width:calc(992px + 240px)){
.main-content{width:600px!important;}
.container{max-width:640px;}
.sidebar{width:240px!important;}
}
@media only screen and (min-width:calc(768px + 240px) 1) and (max-width:calc(768px + 240px) 200){
.main-content{width:480px!important;}
.sidebar{width:240px!important;}
.progress-tracker{max-width:740px!important;}
}
@media only screen and (min-width:480px) and (max-width:calc(768px + 240px)){
.progress-tracker{width:90%!important;}
.sidebar{width:100%!important;}
.sidebar{padding:0 10px;margin-top:20px;}
.main-container{width:100%;margin-top:0;}
.main-container .main-content{width:100%;padding:0 10px;}
}
@media only screen and (max-width:calc(768px + 240px)){
.main-container{width:100%;margin-top:0!important;}
.main-container .main-content{width:100%;padding:0 10px;}
.progress-tracker{max-width:740px!important;padding:0 8px!important;overflow:hidden;height:75px!important;}
.progress-tracker__bar__stage{width:40px!important;height:40px!important;}
}
@media only screen and (max-width:calc(768px + 240px)) and (max-width:320px){
.progress-tracker{height:58px;}
}
@media only screen and (max-width:calc(768px + 240px)){
.progress-tracker__bar{width:100%;justify-content:space-around!important;}
.progress-tracker__bar__stage{margin:0!important;}
}
@media only screen and (max-width:calc(768px + 240px)) and (max-width:450px){
.progress-tracker__bar__stage{width:40px!important;height:40px!important;}
}
@media only screen and (max-width:480px){
.container{max-width:100%;padding:10px 0;margin:0 auto;overflow-x:hidden;}
.container .form__row__inline:first-child{margin-bottom:20px;}
.container .address__btns button{width:100%;margin-bottom:10px;}
.container .form__input{width:100%;}
.container .form__input-group__description{display:block;padding-left:2px;margin-top:5px;}
.container .sidebar{display:block;padding:0 10px;width:100%;}
.container .main-container{width:100%;margin-top:0;}
.container .main-container .main-content{width:100%;padding:0 10px;}
.container .main-container .main-content__box{padding:5px;}
.container .main-container .main-content .box .box__header{padding:0!important;}
.container .main-container .sidebar{margin-top:20px;}
.container .address__btns{display:flex;justify-content:space-between;flex-direction:column;}
.container .address__btns .btn{margin-left:0;}
}
.address .pills{width:300px;max-width:100%;display:flex;list-style:none;margin:0;overflow:hidden;padding:0;margin-bottom:16px;}
.address .pills>li{border:1px solid rgba(7,50,70,.16);border-radius:100px;color:#000;cursor:pointer;font-size:12px;font-weight:500;line-height:1;margin-right:10px;opacity:.5;padding:6px 10px;flex-grow:1;text-align:center;max-width:50%;}
.address .pills>li:last-child{margin-right:0;}
.address .pills>li.active{color:#fff;background-color:#005d92;box-shadow:0 1px 3px 0 rgba(0,0,0,.06),inset 0 0 0 .5px rgba(0,0,0,.08);border:none;opacity:1;}
.address__sender{min-height:126px;display:flex;flex-direction:column;justify-content:center;}
.address__information{color:#5e554a;}
.address__information>div:first-child{color:#000;font-size:15px;}
.address__information__title{display:flex;justify-content:space-between;align-items:center;font-weight:500;}
.address__btns{margin:20px 0 0;}
.address__btns>.btn{width:47%;margin-left:15px;}
.address__btns>.btn:first-child{margin-left:0;}
.address__btns>.btn:last-child{float:right;}
.address .sticky-product{align-items:center;position:fixed;padding:0 10px;right:0;z-index:2;background:#fff;width:100%;justify-content:space-between;display:none;box-shadow:0 2px 4px 0 rgba(0,0,0,.1);}
@media (max-width:480px){
.address .sticky-product{display:flex;}
}
.address .sticky-product__name{text-align:center;font-weight:500;font-size:16px;display:flex;align-items:center;}
.address .sticky-product__name img{width:45px;margin-right:10px;}
.address .sticky-product__price{font-size:16px;font-weight:500;color:#005d92;display:flex;align-items:flex-end;}
.address .sticky-product__price pn-icon{margin-left:5px;}
.postcode__failed{position:absolute;top:65%;transform:translateY(-50%);left:320px;padding:15px;width:200px;height:auto;color:#fff;border-radius:2px;background-color:#005d92;box-shadow:0 1px 4px 0 rgba(0,0,0,.06),inset 0 0 0 .5px rgba(0,0,0,.08);}
.postcode__failed:before{content:"";position:absolute;top:50%;left:-17px;width:18px;height:18px;margin-top:-9px;background-image:url(https://portal.postnord.com/onlineporto/assets/images/graphics-infobox-arrow@2x.png);background-size:18px 18px;}
::-webkit-input-placeholder{opacity:.5;}
::-moz-placeholder{opacity:.5;}
:-ms-input-placeholder{opacity:.5;}
:-moz-placeholder{opacity:.5;}
.form__row__contact-info{margin-right:-20px;border-top:1px solid rgba(7,50,70,.08);padding-top:20px;}
.form__row__contact-info__header{font-size:15px;font-weight:500;}
.form__row__contact-info__text{font-style:italic;max-width:300px;color:#5e554a;margin-top:10px;}
.title-description{margin-left:10px;color:#5e554a;font-size:12px;font-style:italic;font-weight:400;}
.page-header{margin:30px 0;color:#000;}
@media screen and (max-width:480px){
.page-header{margin:6px 0 16px;}
}
.page-header__title{font-weight:500;font-size:32px;margin:0;}
@media screen and (max-width:480px){
.page-header__title{font-size:22px;padding:0 10px;}
}
.outer-container .parcel-added-toaster{display:none;}
@media screen and (max-width:calc(768px + 240px)){
.outer-container .parcel-added-toaster{position:fixed;bottom:0;display:block;width:100%;padding:8px;z-index:999999999;}
}
.main-container-wrapper{margin-top:30px;}
@media screen and (max-width:480px){
.main-container-wrapper{margin-top:24px;}
}
.main-container{display:inline-block;text-align:left;}
.main-container:after,.main-container:before{content:" ";display:block;}
.main-container:after{clear:both;}
.main-content{width:640px;float:left;}
.main-content__box{padding:20px;background-color:#f3f2f2;}
.main-content__box,.main-content__box .box__content{border:1px solid #d3cecb;}
.customerservice{margin:40px auto 0;font-size:12px;line-height:1.8;font-weight:400;text-align:center;}
.customerservice a{color:#005d92;cursor:pointer;font-weight:500;text-decoration:none;}
.customerservice a.underline{border-bottom:1px solid #005d92;white-space:nowrap;}
button{font-family:PostNordSans,serif;}
:focus{outline:none;}
.privacy-policy{padding:0 0 40px;}
.privacy-policy__link{color:#005d92;border-bottom:1px solid #005d92;font-weight:500;font-size:12px;}
.vatselection_overlay{z-index:50;position:absolute;left:0;right:0;top:0;bottom:0;width:100%;height:100%;background-color:rgba(0,125,184,.8);}
.selection__box{background-color:#8eddf9;z-index:200;max-width:360px;max-height:353px;margin:20% auto;}
.selection__box{box-shadow:inset -1px -1px 0 0 rgba(72,186,228,.25),inset 1px 1px 0 0 rgba(72,186,228,.25);}
.selection__box__container{cursor:pointer;border:1px solid #d3cecb;border-top:0;background-color:#fff;padding-left:20px;}
.selection__box__container p{margin:0;}
.selection__box__container p.subtext{color:#005d92;font-size:13px;}
.selection__box__container__private{position:relative;padding:15px 20px 15px 0;width:100%;background-color:#fff;border-bottom:1px solid #d3cecb;}
.selection__box__container__private:after{position:absolute;content:"";top:17px;right:20px;background-image:url(https://portal.postnord.com/onlineporto/assets/images/icon-16-arrow-blue@2x.png);width:16px;height:16px;background-size:16px 16px;}
.selection__box__container__company{position:relative;padding:15px 20px 15px 0;width:100%;background-color:#fff;border-bottom-right-radius:2px;}
.selection__box__container__company:after{position:absolute;content:"";top:17px;right:20px;background-image:url(https://portal.postnord.com/onlineporto/assets/images/icon-16-arrow-blue@2x.png);width:16px;height:16px;background-size:16px 16px;}
.sidebar{margin-left:20px;width:280px;float:right;}
.feedback-button{position:fixed;right:0;top:50%;transform-origin:bottom right;transform:rotate(-90deg) translateX(50%);width:180px;background-color:#005d92;font-size:15px;padding:12px 10px 9px;box-shadow:0 1px 3px 0 rgba(0,0,0,.06),inset 0 0 0 1px rgba(0,0,0,.08);transition:all .2s ease-in-out;z-index:20;text-align:center;color:#fff;font-weight:500;cursor:pointer;}
@media (max-width:767px){
.feedback-button{font-size:12px;width:140px;padding-top:8px;padding-bottom:6px;transform:none;top:auto;bottom:0;right:50%;margin-right:-70px;}
}
.feedback-button:hover{box-shadow:0 1px 7px 0 rgba(0,0,0,.2),inset 0 0 0 1px rgba(0,0,0,.08);background-color:#005788;}
.mobile-navigation-menu{position:relative;box-shadow:0 2px 4px 0 rgba(0,0,0,.05),inset 0 -1px 0 0 #d3cecb;}
.mobile-navigation-menu__item{height:44px;margin:0 20px;display:flex;align-items:center;justify-content:space-between;cursor:pointer;}
.mobile-navigation-menu__item__name{flex-grow:1;color:#5e554a;}
.mobile-navigation-menu__item--active .mobile-navigation-menu__item__name{color:#00a0d6;font-weight:500;}
.mobile-navigation-menu__item__icon{filter:grayscale(100%);width:30px;height:30px;background-size:30px;}
.mobile-navigation-menu__item__icon.new-shipment{background-image:url(https://portal.postnord.com/onlineporto/assets/images/icon-30-new-blue@2x.png);}
.navigation-menu{width:100%;background-color:#fff;height:60px;box-shadow:inset 0 -1px 0 0 rgba(0,0,0,.1);display:flex;justify-content:center;align-items:center;list-style:none;color:rgba(0,0,0,.5);}
.navigation-menu__item{padding:20px 20px 18px 40px;border-bottom:2px solid transparent;cursor:pointer;position:relative;}
.navigation-menu__item:before{content:"";filter:grayscale(100%);position:absolute;left:10px;top:14px;width:30px;height:30px;background-size:30px;background-position:0;}
.navigation-menu__item span{color:#5e554a;}
.navigation-menu__item.my-shipments:before{background-image:url(https://portal.postnord.com/onlineporto/assets/images/icon-30-menu-blue@2x.png);}
.navigation-menu__item.my-receivers:before{background-image:url(https://portal.postnord.com/onlineporto/assets/images/icon-30-address-blue@2x.png);}
.navigation-menu__item.new-shipment:before{background-image:url(https://portal.postnord.com/onlineporto/assets/images/icon-30-new-blue@2x.png);}
.progress-tracker{display:block;max-width:850px;margin:40px auto 30px;font-weight:400;}
@media screen and (max-width:calc(768px + 240px)){
.progress-tracker{margin-bottom:-10px;}
}
@media screen and (max-width:480px){
.progress-tracker{margin-top:0;}
}
.progress-tracker__bar{display:flex;}
.progress-tracker__bar div.menu-item-container{flex-grow:1;margin:0 2px;line-height:1;flex-basis:150px;}
.progress-tracker__bar__text{position:relative;text-align:center;color:#5e554a;padding:2px 0;}
.progress-tracker__bar__text--active{color:#000;font-weight:500;}
.progress-tracker__bar__stage{width:25px;height:25px;display:inline-block;position:relative;background-size:100%;background-repeat:no-repeat;}
.progress-tracker__bar__stage--address{background-image:url(https://portal.postnord.com/onlineporto/assets/images/icon-30-pin@2x.png);filter:invert(45%);}
.progress-tracker__bar__stage--address--active{filter:none;}
.progress-tracker__bar__stage--payment{background-image:url(https://portal.postnord.com/onlineporto/assets/images/icon-30-card@2x.png);filter:invert(45%);}
.progress-tracker__bar__stage--label{background-image:url(https://portal.postnord.com/onlineporto/assets/images/icon-30-barcode@2x.png);filter:invert(45%);}
.progress-tracker__bar__stage--p{background-image:url(https://portal.postnord.com/onlineporto/assets/images/icon-30-postnord@2x.png);filter:invert(45%);}
.progress-tracker__bar__divider{position:relative;content:"";display:inline-block;width:100%;height:4px;background-color:#d3cecb;}
.progress-tracker__bar__divider--active{background-color:#005d92;}
.feature-toggler{opacity:1;transition:all .1s ease-in-out;}
.feature-toggler.ng-hide{opacity:0;}
.feature-toggler__overlay{z-index:50;position:absolute;left:0;right:0;top:0;bottom:0;width:100%;height:100%;background-color:rgba(0,125,184,.8);}
.feature-toggler__box{background-color:#fff;z-index:100;position:absolute;top:50vh;left:50%;transform:translate(-50%,-50%);border-radius:4px;padding:20px;width:300px;}
.feature-toggler__box__title{font-weight:500;font-size:18px;}
.feature-toggler__features{margin-top:15px;}
.feature-toggler__features__feature{margin-top:10px;}
.feature-toggler__features__feature:after,.feature-toggler__features__feature:before{content:" ";display:block;}
.feature-toggler__features__feature:after{clear:both;}
.feature-toggler__features__feature__name{float:left;cursor:pointer;}
.feature-toggler__features__feature__checkbox{float:right;}
.feature-toggler__button{margin-top:20px;}
cmn-sidebar-cart{border:1px solid #d3cecb;}
cmn-sidebar-cart .price{color:#005d92;}
cmn-sidebar-cart>header{color:#000;padding:8px 0 7px;margin:0 20px;height:45px;}
cmn-sidebar-cart>main{padding:0 20px;}
cmn-sidebar-cart>main>ul{list-style:none;margin:0;padding:0;}
cmn-sidebar-cart>main>section{border-bottom:1px solid hsla(23,8%,81%,.6);padding:20px 0;}
cmn-sidebar-cart>main>section:last-child{border-bottom:0;}
cmn-sidebar-cart>main>section.total-price{align-items:center;display:flex;font-size:15px;justify-content:space-between;}
cmn-sidebar-cart>main>section.total-price .muted{color:#5e554a;white-space:nowrap;}
cmn-sidebar-cart>main>section.total-price>.price{font-size:20px;margin-left:15px;white-space:nowrap;}
cmn-sidebar-cart>footer{border-top:1px solid hsla(23,8%,81%,.6);padding:20px;height:65px;}
cmn-sidebar-cart>footer>a{color:#005d92;padding:0;}
cmn-sidebar-selected-product{border:1px solid #d3cecb;}
@media (max-width:767px){
cmn-sidebar-selected-product{border:none;background-color:unset;}
}
cmn-sidebar-selected-product>header{margin:0 20px;padding:8px 0 7px;border-bottom:1px solid hsla(23,8%,81%,.6);}
cmn-sidebar-selected-product>header>h2{margin:0;}
@media (max-width:767px){
cmn-sidebar-selected-product>header{border-bottom:none;margin:0 10px;}
}
cmn-sidebar-selected-product>main .additional-services .price{color:#000;}
cmn-sidebar-selected-product>main ul{margin:0;padding:0;}
cmn-sidebar-selected-product>main .price{color:#005d92;font-weight:400;white-space:nowrap;}
cmn-sidebar-selected-product>main .price strong{font-weight:500;}
cmn-sidebar-selected-product>main .product-image{margin-left:-5px;display:none;}
cmn-sidebar-selected-product>main .product-image img{height:60px;display:flex;}
cmn-sidebar-selected-product>main .expand{display:none;}
cmn-sidebar-selected-product>main>header{padding:20px;border-bottom:1px solid #d3cecb;overflow:hidden;}
cmn-sidebar-selected-product>main>header>h2{color:#000;display:flex;font-size:15px;font-weight:500;justify-content:space-between;margin:0;}
cmn-sidebar-selected-product>main>header>h2 span{color:#000;}
cmn-sidebar-selected-product>main>header>div{display:flex;justify-content:space-between;width:100%;}
cmn-sidebar-selected-product>main>header>div>ul{font-size:15px;list-style:none;margin:10px 0 0;}
cmn-sidebar-selected-product>main>header>div>ul+ul{margin-left:10px;text-align:right;}
cmn-sidebar-selected-product>main>header>div>ul+ul>li>span{white-space:nowrap;}
cmn-sidebar-selected-product>main>header>div>ul>li{display:block;margin-bottom:15px;}
cmn-sidebar-selected-product>main>header>div>ul>li:last-child{margin-bottom:0;}
cmn-sidebar-selected-product>main>header>div>ul>li>label{color:#5e554a;display:block;font-size:13px;}
cmn-sidebar-selected-product>main>header>div>ul>li .max-value{font-weight:500;}
cmn-sidebar-selected-product>main>.section-container{padding:20px;background-color:#f3f2f2;}
cmn-sidebar-selected-product>main>.section-container>section{padding:20px 0;border-bottom:1px solid #d3cecb;background-color:#f3f2f2;}
cmn-sidebar-selected-product>main>.section-container>section:first-child{padding-top:0;}
cmn-sidebar-selected-product>main>.section-container>section:last-child{border-bottom:0;padding-bottom:0;}
cmn-sidebar-selected-product>main>.section-container>section>ul>li{display:flex;justify-content:space-between;list-style:none;margin-bottom:10px;}
cmn-sidebar-selected-product>main>.section-container>section>ul>li:last-child{margin-bottom:0;}
cmn-sidebar-selected-product>main>.section-container>section>ul>li label{font-size:15px;font-weight:500;position:relative;}
cmn-sidebar-selected-product>main>.section-container>section>ul>li label .title{position:relative;}
cmn-sidebar-selected-product>main>.section-container>section>ul>li label .value{color:#5e554a;display:block;font-size:13px;}
cmn-sidebar-selected-product>main>.section-container>section>ul>li .price{font-size:15px;margin-left:15px;}
cmn-sidebar-selected-product>main>.section-container>section.total-price{align-items:center;display:flex;font-size:15px;justify-content:space-between;}
cmn-sidebar-selected-product>main>.section-container>section.total-price .muted{color:#5e554a;white-space:nowrap;}
cmn-sidebar-selected-product>main>.section-container>section.total-price>.price{font-size:20px;margin-left:15px;}
@media (max-width:767px){
cmn-sidebar-selected-product>main{border:1px solid #d3cecb;background-color:#fff;}
cmn-sidebar-selected-product>main .dimensions,cmn-sidebar-selected-product>main .section-container{display:none;}
cmn-sidebar-selected-product>main .dimensions{border-top:1px solid #d3cecb;margin-top:15px;}
cmn-sidebar-selected-product>main .section-container{padding:20px 13px;}
cmn-sidebar-selected-product>main .section-container section ul li .price{font-weight:500;}
cmn-sidebar-selected-product>main .section-container section ul li label .title .text:after{content:":";}
cmn-sidebar-selected-product>main .section-container section ul li label .value{display:inline-block;color:#000;font-size:15px;font-weight:400;}
cmn-sidebar-selected-product>main>header{border-bottom:none;padding:13px;}
cmn-sidebar-selected-product>main>header>h2{justify-content:flex-start;align-items:center;}
cmn-sidebar-selected-product>main>header>h2 .product-name{flex-grow:1;margin-left:5px;}
cmn-sidebar-selected-product>main>header>h2 .price{font-weight:500;color:#005d92;}
cmn-sidebar-selected-product>main>header>h2 .expand{margin-left:5px;}
cmn-sidebar-selected-product>main>header>h2 .expand,cmn-sidebar-selected-product>main>header>h2 .product-image{display:block;}
cmn-sidebar-selected-product>main>header>div{padding-top:10px;}
cmn-sidebar-selected-product>main>header>div>ul+ul{text-align:left;margin-left:0;}
cmn-sidebar-selected-product>main>header>div>ul li{margin-bottom:10px;}
cmn-sidebar-selected-product>main>header>div>ul li label{display:inline-block;font-weight:500;color:#000;font-size:15px;}
cmn-sidebar-selected-product>main>header>div>ul li label:after{content:":";}
cmn-sidebar-selected-product>main>header>div>ul li .max-value{font-weight:400;}
}
/*! CSS Used from: https://postnord.humany.net/ClientLibraries/Supplementary/font-awesome-4.7.0/css/font-awesome.min.css?v=268435456 */
.fa{display:inline-block;font:normal normal normal 14px/1 FontAwesome;font-size:inherit;text-rendering:auto;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;}
.fa-2x{font-size:2em;}
.fa-stack{position:relative;display:inline-block;width:2em;height:2em;line-height:2em;vertical-align:middle;}
.fa-stack-2x{position:absolute;left:0;width:100%;text-align:center;}
.fa-stack-2x{font-size:2em;}
.fa-circle:before{content:"\f111";}
/*! CSS Used from: Embedded */
#postnordTopbarContainer{position:relative;}
#postnordTopbar button{font-family:inherit;}
#postnordTopbar *,#postnordTopbar *:after,#postnordTopbar *:before{box-sizing:border-box;-webkit-font-smoothing:antialiased;}
#postnordTopbar :active{outline:none;}
#postnordTopbar :focus{outline:none;background-color:transparent;}
#postnordTopbar .focus-class-main{height:34px;}
#postnordTopbar .ellipsis{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:150px;display:block!important;text-align:right;}
#postnordTopbar #topbarLogin{display:none;}
#postnordTopbar #openLoggedInMenu svg{margin-top:14px;}
#postnordTopbar :focus > .focus-class-links{box-shadow:0 0 2px 2px #48bae4;}
#postnordTopbar .tool-dropdown-style{padding:0px 20px 25px 20px;width:197px;display:inline-block!important;}
#postnordTopbar .main-menu-dropdown button{font-size:15px;}
#postnordTopbarContainer{height:56px;background:#005d92;}
pn-topbar #postnordTopbarContainer{z-index:400;}
#postnordTopbar{color:#ffffff;display:flex;justify-content:space-between;white-space:nowrap;}
#postnordTopbar a{text-decoration:none;color:#ffffff;}
#postnordTopbar ul{list-style-type:none;}
#postnordTopbar > ul{display:flex;margin:0;padding:0;flex-wrap:nowrap;justify-content:flex-end;height:56px;flex:1 0 0px;}
#postnordTopbar > ul.left-items-wrapper{justify-content:flex-start;}
#postnordTopbar > ul > li > div > a{margin:0;display:flex;align-items:center;}
#postnordTopbar > ul > li > div{height:100%;}
#postnordTopbar ul > li > div > a > span{margin-right:10px;margin-top:2px;white-space:nowrap;}
#postnordTopbar > ul > li{display:flex;flex-direction:row;justify-content:center;align-items:center;height:56px;position:relative;}
#postnordTopbar ul li *:first-child{display:flex;align-content:center;align-items:center;}
#postnordTopbar .weak{color:rgba(0, 0, 0, 0.5);font-size:80%;}
#postnordTopbar .topbarlogo{display:flex;align-items:center;margin-left:20px;}
#postnordTopbar .postnord-topbar-logo{width:120px;height:23px;}
#postnordTopbar .dropdown-label{position:absolute;font-size:12px;top:12px;left:20px;font-weight:500;color:#cdeefb;}
#postnordTopbar .dropdown-selected-value{font-size:14px;line-height:14px;padding-top:15px;}
#postnordTopbar #languageBtn svg,#postnordTopbar #marketBtn svg{margin-top:14px;}
#postnordTopbar .dropbtn{background-color:#005d92;color:white;padding:16px;font-weight:500;height:24px;border:none;cursor:pointer;}
#postnordTopbar ul li .dropbtn{height:34px;padding:0;margin:0px 20px;}
#postnordTopbar .angle-icon{margin-left:8px;}
#postnordTopbar .moreMenuText{margin:0px;}
#postnordTopbar .main-menu-dropdown{position:relative;align-items:center;justify-content:center;}
#postnordTopbar .main-menu-dropdown-content{display:none;position:absolute;min-width:14.5em;width:100%;box-shadow:0px 2px 8px 0px rgba(0, 0, 0, 0.2);z-index:9999;margin:0!important;top:63px;border-radius:8px;background:white;}
#postnordTopbar .main-menu-dropdown-content[aria-hidden='true']{display:none;}
#postnordTopbar .main-menu-dropdown-content .main-menu-header{color:#000000;font-weight:700;display:block;font-size:16px;padding:20px 0px 8px 20px;letter-spacing:0.4px;}
#postnordTopbar .main-menu-dropdown-content a{color:#1e1e1e;white-space:nowrap;display:block;}
#postnordTopbar .main-menu-dropdown-content a:first-child{padding-top:20px;}
#postnordTopbar .main-menu-dropdown-content .main-menu-dropdown-item-name-container{height:18px;margin-bottom:4px;display:inline-block;white-space:normal;word-break:break-all;}
#postnordTopbar .main-menu-dropdown-content .main-menu-dropdown-item-name{display:inline;line-height:15px!important;font-size:15px;font-weight:500;color:#005d92;}
#postnordTopbar .main-menu-dropdown-content .main-menu-dropdown-item-description{font-size:13px;color:#1e1e1e;opacity:0.7;width:200px;white-space:normal;text-overflow:clip;}
#postnordTopbar .dropdownWrapper .top-dropdown-container{display:block;padding:1em;}
#postnordTopbar .dropdownWrapper > .pn-divider{height:0.6em;width:90%;background:#03a0d6;position:relative;border-radius:0 0.6em 0.6em 0;padding:0;}
#postnordTopbar .pn-divider:after{content:'';width:0.6em;height:0.6em;border-radius:50%;position:absolute;right:0;top:0;background:inherit;transform:translateX(calc(100% + 0.2em));}
#postnordTopbar .dropdownWrapper .lower-btn-container{display:block;padding:1em 0;}
#postnordTopbar .dropdownWrapper .top-dropdown-container > .btnWrapper{padding:16px 0 6px;}
#postnordTopbar .dropdownWrapper .lower-btn-container a{background:none;}
#postnordTopbar ul li * .dropdownWrapper{font-weight:500;display:block;}
#postnordTopbar .dropdownWrapper a{border-bottom:1px solid #f0f0f0;}
#postnordTopbar .dropdownWrapper a span{font-size:15px;padding:16px 20px;}
#postnordTopbar #siteDropdown a{font-size:15px;padding:16px 20px;}
#postnordTopbar .dropdownWrapper .btnWrapper{padding:20px;margin-left:auto;margin-right:auto;}
#postnordTopbar .dropdownWrapper a:last-child{border-bottom:none;}
#postnordTopbar .dropdownWrapper .accountBtn{background-color:#005d92;transition:background 0.2s, box-shadow 0.1s;color:#ffffff;border-radius:24px;height:44px;width:100%;font-size:15px;cursor:pointer;border:none;}
#postnordTopbar .dropdownWrapper .accountBtn:hover{background:#0d234b;}
#postnordTopbar .dropdownWrapper .accountBtn:focus{background:#0d234b;box-shadow:0 0 0 2px #fff, 0 0 0 4px #005d92;}
#postnordTopbar .dropdownWrapper .accountBtn .accountBtnText{margin-left:auto;margin-right:auto;font-size:15px;}
#postnordTopbar .dropdownWrapper .loginBtn{color:#005d92;border-bottom:none;cursor:pointer;}
#postnordTopbar .dropdownWrapper .loginBtn .loginBtnText{font-size:15px;display:block;text-align:center;}
#postnordTopbar .dropdownWrapper .allNotifications{font-size:15px;color:#005d92;text-align:center;border-top:1px solid #f0f0f0;}
#postnordTopbar .dropdownWrapper .allNotifications .allNotificationsText{display:block;}
#postnordTopbar .main-menu-dropdown-content notifications,#postnordTopbar .main-menu-dropdown-content notifications *{white-space:normal!important;line-height:100%!important;}
#postnordTopbar .main-menu-dropdown-content notifications{max-height:400px;overflow-y:auto;display:block;padding:0px;}
#postnordTopbar .right{right:1px;}
#postnordTopbar .left{left:1px;}
#postnordTopbar ul li * .notificationTextStyle{display:block;color:#1e1e1e;opacity:0.7;margin:4px 0px;}
#postnordTopbar ul li * .notificationUnreadStyle{color:#005d92;opacity:unset;}
#postnordTopbar ul li * .notificationItemStyle{display:block;cursor:pointer;margin:0px 15px 0px 15px;padding:15px 0px 0px 0px;overflow-y:hidden;}
#postnordTopbar .main-menu-dropdown-content a.notificationItemStyle:first-child{padding-top:10px;}
#postnordTopbar ul li .notificationItemStyle :last-child{border-bottom:none;}
#postnordTopbar ul li * .notificationRichTextContainer{padding-top:8px;padding-bottom:15px;zoom:0.85;transform:scale(0.85);}
#postnordTopbar .noNotifications{padding:16px 20px;}
#postnordTopbar .dropdown-item{color:#005d92!important;}
#postnordTopbar .selected{color:#bebebe!important;pointer-events:none;}
#postnordTopbar .count-badge{background:#a70707;position:absolute;color:#fff;text-align:center;font-size:12px!important;top:9px;width:16px;height:16px;border-radius:50%;line-height:16px!important;text-overflow:ellipsis;overflow:hidden;margin-left:11px;display:inline-block!important;z-index:1;}
#postnordTopbar .hide{display:none!important;height:0px;transition:height 0.5s linear;}
@media screen and (min-width: 952px){
#postnordTopbar #mobile-menu{display:none;}
}
@media screen and (max-width: 951px){
#postnordTopbar .left-items-wrapper{display:none!important;}
#postnordTopbar .desktopDesign{display:none!important;}
#postnordTopbar #mobile-menu{display:block;width:100%;}
#postnordTopbar #mobile-menu .main-menu-dropdown{justify-content:flex-end;}
#postnordTopbar .mobile-main-menu-dropdown-content{display:none;position:absolute;z-index:8;width:100%;box-shadow:0px 2px 8px 0px rgba(0, 0, 0, 0.2);z-index:9999;margin:0px 0px 0px 0px!important;top:56px;background:white;}
#postnordTopbar .mobile-version{position:unset;box-shadow:unset;}
#postnordTopbar .mobile-main-menu-dropdown-content[aria-hidden='true']{display:none;}
#postnordTopbar .mobile-main-menu-dropdown-content a{color:#1e1e1e;background-color:#ffffff;white-space:nowrap;display:block;padding:12px 23px;}
#postnordTopbar .mobile-main-menu-dropdown-content .dropdownWrapper .mobil-menu-div-section-wrapper{width:100%;display:block;}
#postnordTopbar .mobile-main-menu-dropdown-content .dropdownWrapper .mobil-menu-div-section-wrapper div{width:100%;padding:0px;}
#postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    .mobil-menu-div-section{display:flex;align-content:center;align-items:center;border-top:1px solid #f0f0f0;min-height:64px;cursor:pointer;}
#postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    .mobil-menu-div-section    a{width:100%;}
#postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    .mobil-menu-div-section    .mobileLoginBtn{display:flex;justify-content:center;cursor:pointer;}
#postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    .mobil-menu-div-section    .mobileLoginBtn    .loginBtnMobileText{font-size:15px;padding:0px;cursor:pointer;}
#postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    .mobil-menu-div-section    .mobileLoginBtn{color:#005d92;}
#postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    .mobil-menu-div-section    .loggedInUserBtnWrapper{display:inline-flex;background-color:white;}
#topbarMobileLoggedOutDiv,.mobil-menu-div-section .loggedInUserBtnWrapper,#postnordTopbar #mobileMainMenuDropdown a:last-child{box-shadow:rgba(0, 0, 0, 0.16) 0px 20px 15px -20px;}
#postnordTopbar #mobileMainMenuDropdown a{background-color:#fff;}
#postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    div    .userInformationWrapper{display:inline-block;}
#postnordTopbar .mobile-main-menu-dropdown-content .dropdownWrapper .mobil-menu-div-section-wrapper div a{border-bottom:none;font-size:15px;}
#postnordTopbar .mobile-main-menu-dropdown-content .dropdownWrapper .mobil-menu-div-section-wrapper div svg{margin-right:28px;}
#postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    div    .mobile-version-under-menu    a{background-color:#f7f7f7;font-size:15px;}
#postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    div    .mobile-version-under-menu    a:first-child{padding-top:24px;}
#postnordTopbar .main-menu-dropdown-content .mobile-version-under-menu{color:#1e1e1e;font-weight:500;display:inline-block;font-size:15px;width:100%;background-color:#f0f0f0;}
#postnordTopbar .main-menu-dropdown-content .mobile-version-under-menu main-menu{display:block;}
#postnordTopbar .main-menu-dropdown-content .mobile-version-under-menu main-menu a{background-color:#f7f7f7!important;}
}
@media screen and (max-width: 360px){
#postnordTopbar #topbarLogoMobile{margin-right:auto!important;}
}
#postnordTopbar #siteBtn{display:none;}
#topbarCartMobile{margin-left:16px;}
#postnordTopbar #topbarLogoMobile{margin-left:20px;}
#postnordTopbar .topbar-divider{border-right:1px solid;margin-left:20px;padding:10px 0;height:25px;align-self:center;}
#postnordTopbar #topbarMobileLoggedOutDiv .topbarMobileBtn,#postnordTopbar #topbarMobileLoggedInDiv .topbarMobileBtn{background-color:#005d92;border-radius:24px;border:none;}
#postnordTopbar .loginBtnMobileText{color:#ffffff;}
#postnordTopbar #topbarMobileLogoutBtnDiv .loginBtnMobileText{color:#005d92;}
#postnordTopbar #topbarMobileLoggedInDiv,#postnordTopbar #topbarMobileLoggedOutDiv{display:flex;justify-content:center;flex-wrap:wrap;align-items:center;flex-direction:column;padding:16px 8px;}
#postnordTopbar #topbarMobileLoggedInDiv > *,#postnordTopbar #topbarMobileLoggedOutDiv > *{margin:8px;}
#postnordTopbar .pn-topbar-selected-org-container,#postnordTopbar .pn-topbar-org-list{display:none;flex-direction:column;align-items:flex-start;max-height:22em;overflow-y:auto;}
#postnordTopbar .pn-topbar-selected-org-name{color:#000;line-height:1;font-weight:400;white-space:normal;margin:1em 0 0;}
#postnordTopbar .pn-topbar-selected-org-number{color:#5e554a;font-size:12px;margin:0;font-weight:400;}
#postnordTopbar .mobil-menu-div-section-wrapper .mobil-menu-div-section .userInformationWrapper > div{padding:0 24px;}
#postnordTopbar .mobil-menu-div-section-wrapper .mobil-menu-div-section .userInformationWrapper > .userInformationName{margin-top:16px;}
#postnordTopbar  .mobil-menu-div-section-wrapper  .mobil-menu-div-section  .userInformationWrapper  > .pn-topbar-selected-org-container{margin-bottom:16px;}
.hidden{display:none!important;}
#postnordTopbar .topbar-alerts-container{right:0.5em;min-width:20em;}
.pn-disturbance-alert{display:flex;justify-content:space-between;align-items:center;padding:1em 3.5em 1em 1em;flex-wrap:wrap;background-color:#a70707;color:#fff;}
.pn-disturbance-alert-right-wrapper{display:flex;gap:8px;flex-wrap:wrap;}
.pn-disturbance-alert-right-wrapper > button{background:transparent;outline:none;border:none;color:inherit;min-width:88px;}
.pn-disturbance-alert-left-wrapper{display:flex;align-items:center;}
.pn-disturbance-alert-icon{margin-left:16px;margin-right:16px;flex-shrink:0;}
.pn-disturbance-alert-left-wrapper > div{color:inherit;text-decoration:none;}
.pn-disturbance-alert-left-wrapper h3,.pn-disturbance-alert-left-wrapper p{margin:0;}
.pn-disturbance-alert-title{font-size:16px;line-height:24px;padding-left:8px;}
.pn-disturbance-alert-message{color:#fff;font-size:14px;line-height:20px;padding-left:8px;}
pn-topbar > div:first-of-type{position:relative;}
.pn-reminder-alert{display:flex;justify-content:space-between;align-items:center;padding:1em 3.25em 1em 1em;flex-wrap:wrap;background-color:#e0f8ff;border:1px solid #005d92;box-shadow:0 1.2px 3.6px rgba(0, 0, 0, 0.1), 0 6.4px 14.4px rgba(0, 0, 0, 0.13);color:#000;border-radius:0.5em;position:absolute;gap:0.5em;z-index:300;transform:translateY(100%);width:40%;max-width:40em;bottom:-1em;right:1em;}
.pn-reminder-alert,.pn-reminder-alert *{box-sizing:border-box;}
@media screen and (max-width: 880px){
.pn-reminder-alert{bottom:0;right:0;transform:translateY(0);width:100%;max-width:100%;position:relative;}
.pn-reminder-alert-right-wrapper > button{flex:1 1 45%;}
}
.pn-reminder-alert-right-wrapper{display:flex;gap:0.5em;flex-wrap:wrap;flex:1 1 auto;margin-left:2.5em;}
.pn-reminder-alert-right-wrapper > button{background:transparent;outline:none;border:none;color:inherit;min-width:88px;}
.pn-reminder-close{padding:0;background:transparent;height:2em;width:2em;margin:0;border:none;outline:none;transition:box-shadow 0.15s, background 0.15s;border-radius:50%;cursor:pointer;position:absolute;right:1em;top:1.8em;}
.pn-reminder-close:focus,.pn-reminder-close:hover{box-shadow:0 0 0 2px #fff, 0 0 0 4px #005d92;background:#e0f8ff;}
.pn-reminder-alert-left-wrapper{display:flex;align-items:center;flex:999 1 35em;}
.pn-reminder-alert-icon{margin-right:16px;flex-shrink:0;}
.pn-reminder-alert-left-wrapper > div{color:inherit;text-decoration:none;}
.pn-reminder-alert-left-wrapper h3,.pn-reminder-alert-left-wrapper p{margin:0;}
.pn-reminder-alert-title{font-size:16px;line-height:24px;}
.pn-reminder-alert-message{font-size:14px;line-height:20px;}
#postnordTopbar #topbarMyPages,#postnordTopbar #topbarMyPages *{box-sizing:border-box;}
#postnordTopbar #topbarMyPages{width:max-content;max-width:20em;}
#postnordTopbar .dropdownWrapper .userInformationName,#postnordTopbar .dropdownWrapper .switchUserEmail{font-size:16px;color:#000000;padding-bottom:0;}
#postnordTopbar .dropdownWrapper .userInformationEmail{color:#5e554a;font-size:12px;line-height:1;padding-top:0;}
#postnordTopbar .dropdownWrapper .userInformationEmail,#postnordTopbar .dropdownWrapper .userInformationName,#postnordTopbar .dropdownWrapper .switchUserEmail{font-weight:400;white-space:normal;word-break:break-all;}
.topbar-button{border:none;outline:none;color:#fff;transition:box-shadow 0.15s, background 0.15s, color 0.15s;background:#005d92;padding:12px;cursor:pointer;border-radius:36px;}
.topbar-button:focus{box-shadow:0 0 0 2px #fff, 0 0 0 4px #005d92;}
.topbar-button.topbar-button-light{color:#005d92;background:#fff;border:1px solid #005d92;}
.topbar-button.topbar-button-light:hover,.topbar-button.topbar-button-light:focus{background:#e0f8ff;}
.topbar-button.topbar-button-warning-primary{color:#a70707;background:#fdefee;border:#fff;}
.topbar-button.topbar-button-warning-primary:hover,.topbar-button.topbar-button-warning-primary:focus{color:#fff;background:#a70707;border:1px solid #fff;}
.topbar-button.topbar-button-warning-secondary{color:#fff;border:1px solid #fff;background:#a70707;}
.topbar-button.topbar-button-warning-primary:focus,.topbar-button.topbar-button-warning-secondary:focus{box-shadow:0 0 0 2px #a70707, 0 0 0 4px #fff;}
.topbar-button.topbar-button-warning-secondary:hover,.topbar-button.topbar-button-warning-secondary:focus{color:#a70707;background:#fff;}
#postnordTopbar ul li .pn-topbar-selected-org-name-top-label{display:none;max-width:calc(100% - 20px);text-overflow:ellipsis;overflow:hidden;white-space:nowrap;}
#postnordTopbar .main-menu-dropdown-content .pn-topbar-logged-in,#postnordTopbar .main-menu-dropdown-content .pn-topbar-acting-as{padding:1em;padding-bottom:0;}
#postnordTopbar .main-menu-dropdown-content .pn-topbar-login-status-container{padding-top:0.7em;}
#postnordTopbar .pn-topbar-logout-btn{text-align:center;}
#postnordTopbar .pn-topbar-alerts-icon{width:22px;height:22px;}
/*! CSS Used keyframes */
@-webkit-keyframes fade-in{from{opacity:0;}to{opacity:1;}}
@keyframes fade-in{from{opacity:0;}to{opacity:1;}}
/*! CSS Used fontfaces */
@font-face{font-family:PostNordSans;font-style:normal;font-weight:400;src:local("PostNordSans Regular"),url(fonts/PostNordSans-Regular.woff) format("woff");}
@font-face{font-family:PostNordSans;font-style:normal;font-weight:300;src:local("PostNordSans Light"),url(fonts/PostNordSans-Light.woff) format("woff");}
@font-face{font-family:PostNordSans;font-style:normal;font-weight:500;src:local("PostNordSans Medium"),url(fonts/PostNordSans-Medium.woff) format("woff");}
@font-face{font-family:'FontAwesome';src:url('https://postnord.humany.net/ClientLibraries/Supplementary/font-awesome-4.7.0/fonts/fontawesome-webfont.eot?v=4.7.0');src:url('https://postnord.humany.net/ClientLibraries/Supplementary/font-awesome-4.7.0/fonts/fontawesome-webfont.eot#iefix&v=4.7.0') format('embedded-opentype'),url('https://postnord.humany.net/ClientLibraries/Supplementary/font-awesome-4.7.0/fonts/fontawesome-webfont.woff2?v=4.7.0') format('woff2'),url('https://postnord.humany.net/ClientLibraries/Supplementary/font-awesome-4.7.0/fonts/fontawesome-webfont.woff?v=4.7.0') format('woff'),url('https://postnord.humany.net/ClientLibraries/Supplementary/font-awesome-4.7.0/fonts/fontawesome-webfont.ttf?v=4.7.0') format('truetype'),url('https://postnord.humany.net/ClientLibraries/Supplementary/font-awesome-4.7.0/fonts/fontawesome-webfont.svg?v=4.7.0#fontawesomeregular') format('svg');font-weight:normal;font-style:normal;}</style></head><body ng-app="onlineShippingTool" class="ng-scope" cz-shortcut-listen="true" style=""><div class="skiptranslate" style="display: none;"><iframe id=":0.container" class="goog-te-banner-frame skiptranslate" frameborder="0" src="javascript:''" style="visibility:visible"></iframe></div><pn-topbar><div><!-- disturbance alert to be displayed above the topbar --><div class="pn-disturbance-alert hidden">  <div class="pn-disturbance-alert-left-wrapper">    <svg class="pn-disturbance-alert-icon" width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">      <path fill-rule="evenodd" clip-rule="evenodd" d="M23.6998 22L12.0003 0.940918L0.300781 22H23.6998ZM20.3008 20H3.69981L12.0003 5.05917L20.3008 20ZM11 14L10.7435 10.4095L12 8.14781L13.2565 10.4095L13 14H11ZM13.5 17C13.5 17.8276 12.8297 18.4987 12.0024 18.5H11.9976C11.1703 18.4987 10.5 17.8276 10.5 17C10.5 16.1716 11.1716 15.5 12 15.5C12.8284 15.5 13.5 16.1716 13.5 17Z" fill="white"></path>    </svg>    <div>      <h3 class="pn-disturbance-alert-title"></h3>      <p class="pn-disturbance-alert-message"></p>    </div>  </div>  <div class="pn-disturbance-alert-right-wrapper">    <button class="pn-disturbance-alert-button pn-disturbance-alert-prev-button hidden topbar-button topbar-button-warning-secondary" data-xtranslate="PREVIOUS" aria-label="Previous"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Previous</font></font></button>    <button class="pn-disturbance-alert-button pn-disturbance-alert-next-button hidden topbar-button topbar-button-warning-primary" data-xtranslate="NEXT" aria-label="Next"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Next</font></font></button>  </div></div><div id="postnordTopbarContainer">  <div id="postnordTopbar">    <ul class="left-items-wrapper">      <a id="topbarLogo" href="#" tabindex="1" class="topbarlogo desktopDesign">        <svg class="postnord-topbar-logo focus-class-main" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="958.69" height="592.78998" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 600 114" enable-background="new 0 0 600 114" xml:space="preserve" tabindex="-1" style="height: 34px">          <g>            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M0.5,23c8.159-0.027,16.317-0.026,24.476-0.11   c1.395-0.014,1.69,0.555,1.625,1.773c-0.076,1.408-0.018,2.824-0.018,4.321c0.306-0.057,0.597-0.022,0.742-0.151   c17.247-15.289,43.533-9.186,51.751,12.423c5.855,15.397,4.752,30.333-6.376,43.337c-11.739,13.717-34.058,14.373-45.195,5.514   c-0.173-0.138-0.425-0.176-1.005-0.404c0,8.232,0,16.264,0,24.297c-7.9,0-15.8-0.057-23.699,0.044   c-1.772,0.022-2.363-0.238-2.358-2.233C0.525,82.207,0.5,52.604,0.5,23z M25.926,58.078c-0.111,8.506,5.778,14.645,14.196,14.797   c8.028,0.145,14.247-5.814,14.377-13.776c0.149-9.208-5.378-15.385-13.883-15.515C32.008,43.452,26.041,49.34,25.926,58.078z"></path>            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M600.5,94c-7.313-0.483-14.635-0.077-21.951-0.209   c-0.749-0.013-1.509-0.079-2.246,0.016c-1.623,0.209-2.021-0.555-1.909-2.022c0.106-1.39,0.022-2.795,0.022-4.542   c-1.484,1.232-2.677,2.336-3.98,3.287c-12.225,8.908-31.617,6.816-41.996-4.505c-12.975-14.155-12.913-39.895-0.158-54.186   c11.564-12.955,33.688-14.569,45.262-5.357c0.167,0.133,0.427,0.149,0.873,0.296c0-6.274,0.096-12.406-0.057-18.531   c-0.046-1.872,0.67-2.394,2.293-2.696c6.945-1.293,13.872-2.685,20.807-4.037c0.398-0.078,0.84-0.046,1.041-0.515   c1.711-0.378,2.053,0.288,2.049,2C600.481,33.333,600.5,63.666,600.5,94z M546.501,58.162c-0.007,8.704,5.763,14.765,14.097,14.809   c8.521,0.047,14.443-5.975,14.477-14.719c0.031-8.51-5.903-14.465-14.411-14.461C552.249,43.795,546.507,49.622,546.501,58.162z"></path>            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M418.68,20.469c7.956,0.122,14.641,1.237,21.007,3.964   c14.999,6.423,22.888,20.112,21.583,36.413c-1.56,19.49-14.82,30.803-32.305,34.098c-10.387,1.959-20.588,1.152-30.359-3.009   c-15.441-6.573-22.246-19.692-21.436-35.479c1.156-22.514,17.57-33.092,35.115-35.436C414.754,20.69,417.254,20.588,418.68,20.469z    M404.795,58.289c0.002,8.482,6.156,14.709,14.416,14.588c8.381-0.123,14.197-6.057,14.205-14.492   c0.008-8.794-5.865-14.836-14.389-14.802C410.632,43.617,404.791,49.65,404.795,58.289z"></path>            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M129.176,20.482c10.908,0.271,21.103,2.735,29.691,9.914   c7.15,5.977,10.82,13.792,11.622,22.978c0.916,10.492-1.016,20.253-8.051,28.488c-6.028,7.055-13.9,10.938-22.862,12.817   c-10.625,2.228-21.037,1.558-31.112-2.567c-16.718-6.844-23.339-21.486-21.72-37.907c1.813-18.375,14.729-29.348,31.757-32.67   C122.021,20.848,125.578,20.472,129.176,20.482z M128.742,43.584c-8.521-0.068-14.478,5.886-14.648,14.643   c-0.16,8.229,6.154,14.627,14.443,14.633c8.247,0.006,14.273-6.037,14.366-14.404C142.997,49.93,137.017,43.65,128.742,43.584z"></path>            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M324.639,28.651c8.594-8.386,18.7-9.742,29.544-6.832   c9.833,2.639,14.446,10.021,16.273,19.528c0.489,2.543,0.64,5.113,0.637,7.703c-0.019,14.081-0.042,28.161,0.029,42.241   c0.01,1.875-0.365,2.59-2.431,2.553c-7.162-0.133-14.33-0.115-21.493-0.008c-1.939,0.029-2.548-0.473-2.538-2.49   c0.053-11.744-0.033-23.49-0.104-35.235c-0.007-1.157-0.137-2.329-0.354-3.466c-1.214-6.333-3.75-8.44-9.795-8.213   c-5.817,0.218-9.371,3.372-9.884,9.181c-0.579,6.562-0.163,13.155-0.221,19.734c-0.054,6.081-0.073,12.164,0.026,18.244   c0.029,1.776-0.547,2.259-2.273,2.238c-7.331-0.083-14.664-0.077-21.995-0.002c-1.607,0.016-2.106-0.403-2.102-2.082   c0.058-22.246,0.063-44.491-0.005-66.735c-0.005-1.857,0.645-2.147,2.286-2.129c7.165,0.082,14.332,0.114,21.494-0.014   c2.094-0.038,2.843,0.564,2.594,2.642C324.215,26.448,324.074,27.473,324.639,28.651z"></path>            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M211.215,20.546c8.705,0.298,16.646,0.971,24.469,2.806   c1.644,0.386,1.959,0.893,1.548,2.508c-1.332,5.236-2.582,10.498-3.658,15.792c-0.402,1.981-1.126,2.04-2.841,1.527   c-8.105-2.422-16.334-3.978-24.853-2.736c-0.653,0.095-1.295,0.284-1.93,0.472c-1.563,0.46-2.785,1.376-2.767,3.105   c0.019,1.79,1.407,2.568,2.948,2.917c5.601,1.269,11.371,1.593,16.944,3.038c2.986,0.774,5.918,1.682,8.708,3.009   c7.723,3.672,11.162,9.681,10.907,18.218c-0.302,10.111-5.477,16.606-14.466,20.478c-7.246,3.119-14.946,3.904-22.702,4.075   c-9.706,0.214-19.249-1.075-28.61-3.718c-1.525-0.431-1.939-0.91-1.485-2.545c1.534-5.527,2.936-11.093,4.245-16.678   c0.423-1.804,1.067-1.934,2.69-1.309c8.626,3.319,17.51,5.265,26.834,4.569c1.261-0.095,2.486-0.319,3.63-0.831   c1.287-0.574,2.195-1.458,2.18-3.033c-0.015-1.588-0.941-2.426-2.275-2.937c-2.905-1.114-5.99-1.359-9.034-1.76   c-5.292-0.696-10.524-1.649-15.497-3.649c-14.374-5.781-17.364-24.28-5.58-34.483c6.473-5.604,14.377-7.417,22.58-8.323   C206.092,20.74,209.012,20.681,211.215,20.546z"></path>            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M245.499,50.268c0-13.667,0.042-27.333-0.047-41   c-0.013-1.896,0.495-2.345,2.345-2.316c7.248,0.112,14.501,0.127,21.748-0.007c1.991-0.037,2.341,0.654,2.285,2.421   c-0.121,3.83,0.048,7.668-0.075,11.498c-0.056,1.717,0.579,2.098,2.161,2.081c6.583-0.072,13.167,0.01,19.75-0.057   c1.734-0.018,2.28,0.252,1.311,2.007c-3.419,6.189-6.769,12.417-10.077,18.667c-0.596,1.125-1.319,1.502-2.556,1.464   c-2.748-0.084-5.507,0.099-8.247-0.068c-1.89-0.115-2.359,0.479-2.349,2.35c0.081,14.416,0.045,28.833,0.044,43.25   c0,3.23-0.001,3.231-3.204,3.232c-6.833,0-13.668-0.084-20.499,0.051c-2.051,0.041-2.656-0.46-2.641-2.574   C245.546,77.602,245.499,63.935,245.499,50.268z"></path>            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M493.583,30.506c5.988-8.059,13.937-9.128,22.504-8.469   c1.558,0.119,2.31,0.717,2.241,2.489c-0.261,6.734-0.4,13.473-0.518,20.211c-0.027,1.597-0.529,2.004-2.111,1.595   c-2.996-0.774-6.07-1.013-9.166-0.75c-8.641,0.735-12.903,5.295-12.938,13.97c-0.043,10.494-0.067,20.988,0.035,31.48   c0.021,2.093-0.354,2.877-2.683,2.82c-7.074-0.174-14.156-0.104-21.234-0.033c-1.608,0.016-2.344-0.229-2.338-2.125   c0.066-22.236,0.058-44.473,0.01-66.708c-0.004-1.605,0.406-2.127,2.068-2.108c7.41,0.086,14.824,0.084,22.234,0.001   c1.592-0.019,2.025,0.507,1.922,1.999C493.494,26.526,493.583,28.188,493.583,30.506z"></path>          </g>        </svg>      </a>      <li class="topbar-divider"></li>      <li class="desktopDesign">        <div id="topbarMainMenu" class="main-menu-dropdown" role="topbarMainMenu">          <button onclick="pnTopbar.showMenu(event, this);" class="dropbtn" aria-controls="dropdown-toolbarlinks" aria-pressed="false" aria-expanded="false" tabindex="17" role="tooltip" name="sites">            <span tabindex="-1" id="pn-sites-txt" data-xtranslate="Portal" aria-label="Portal" style="display: flex;">Portal</span>            <svg class="angle-icon" width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">              <g id="icons-/-16x16-/-solid-/-angle-small-down" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">                <g id="angle-small-down">                  <rect id="Bound" opacity="0.290969122" x="0" y="0" width="16" height="16"></rect>                  <polygon id="Combined-Shape" fill="#FFFFFF" transform="translate(7.999744, 8.666667) scale(1, -1) rotate(-270.000000) translate(-7.999744, -8.666667) " points="8.91641099 4.00025568 10.666411 4.00025568 10.666411 4.66771307 7.99974432 8.66771307 10.666411 12.6677131 10.666411 13.3330777 8.91641099 13.3330777 5.33307766 8.66666667">                  </polygon>                </g>              </g>            </svg>          </button>          <div id="mainMenuDropdown" class="main-menu-dropdown-content left" aria-hidden="true">            <div class="main-menu-header" data-xtranslate="sites" aria-label="home pages"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">home pages</font></font></font></font></div>            <main-menu><a href="https://www.postnord.dk" tabindex="18" style="display: block;"><div class="focus-class-links tool-dropdown-style" tabindex="-1"><div class="main-menu-dropdown-item-name-container"><div class="main-menu-dropdown-item-name" data-xtranslate="postnord.dk" aria-label="postnord.dk">postnord.dk</div></div><div class="main-menu-dropdown-item-description" data-xtranslate="INFORMATION_ABOUT_POSTNORD" aria-label="Information about PostNord"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Information about PostNord</font></font></div></div></a><a href="https://portal.postnord.com/" tabindex="19" style="display: block;"><div class="focus-class-links tool-dropdown-style" tabindex="-1"><div class="main-menu-dropdown-item-name-container"><div class="main-menu-dropdown-item-name" data-xtranslate="CUSTOMER_PORTAL" style="color:#bebebe" aria-label="Customer portal"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Customer portal</font></font></div></div><div class="main-menu-dropdown-item-description" data-xtranslate="MANAGE_YOUR_SHIPMENTS" aria-label="Manage your shipments"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Manage your shipments</font></font></div></div></a><a href="https://www.postnord.com" tabindex="20" style="display: block;"><div class="focus-class-links tool-dropdown-style" tabindex="-1"><div class="main-menu-dropdown-item-name-container"><div class="main-menu-dropdown-item-name" data-xtranslate="postnord.com" aria-label="postnord.com">postnord.com</div></div><div class="main-menu-dropdown-item-description" data-xtranslate="INFORMATION_ABOUT_POSTNORD_GROUP" aria-label="Information about PostNord Group"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Information about PostNord Group</font></font></div></div></a></main-menu>          </div>        </div>      </li>      <!-- Site selector for postnord.com -->      <li data-name="topbarSites" class="desktopDesign">        <div class="main-menu-dropdown">          <button id="siteBtn" onclick="pnTopbar.showMenu(event, this);" class="dropbtn" role="tooltip" name="SITE" aria-expanded="false">            <span class="dropdown-label" data-xtranslate="SITE" aria-label="Side">Side</span>            <span class="dropdown-selected-value" tabindex="-1" data-xtranslate="PN_GROUP" aria-label="The PostNord Group"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">The PostNord Group</font></font></span>            <svg class="angle-icon" width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">              <g id="icons-/-16x16-/-solid-/-angle-small-down" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">                <g id="angle-small-down">                  <rect id="Bound" opacity="0.290969122" x="0" y="0" width="16" height="16"></rect>                  <polygon id="Combined-Shape" fill="#FFFFFF" transform="translate(7.999744, 8.666667) scale(1, -1) rotate(-270.000000) translate(-7.999744, -8.666667) " points="8.91641099 4.00025568 10.666411 4.00025568 10.666411 4.66771307 7.99974432 8.66771307 10.666411 12.6677131 10.666411 13.3330777 8.91641099 13.3330777 5.33307766 8.66666667">                  </polygon>                </g>              </g>            </svg>          </button>          <div id="siteDropdown" class="main-menu-dropdown-content left" aria-hidden="true">            <div></div>            <div class="dropdownWrapper" role="siteSelector">              <a class="dropdown-item" href="https://portal.postnord.com" data-xtranslate="PN_PORTAL" aria-label="PostNord Portal"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">PostNord Portal</font></font></font></font></a>              <a class="dropdown-item" href="https://www.postnord.dk/en" data-xtranslate="PN_DA" aria-label="PostNord Denmark"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">PostNord Denmark</font></font></font></font></a>              <a class="dropdown-item" href="https://www.postnord.fi/en" data-xtranslate="PN_FI" aria-label="PostNord Finland"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">PostNord Finland</font></font></font></font></a>              <a class="dropdown-item" href="https://www.postnord.no/en" data-xtranslate="PN_NO" aria-label="PostNord Norway"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">PostNord Norway</font></font></font></font></a>              <a class="dropdown-item" href="https://www.postnord.se/en" data-xtranslate="PN_SV" aria-label="PostNord Sweden"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">PostNord Sweden</font></font></font></font></a>              <a class="dropdown-item" href="https://www.postnord.com/en/about-us/our-market/germany" data-xtranslate="PN_DE" aria-label="PostNord Germany"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">PostNord Germany</font></font></a>              <a class="dropdown-item" href="https://www.stralfors.com" data-xtranslate="PN_STRALFORS" aria-label="PostNord Strålfors"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">PostNord Strålfors</font></font></font></font></a>              <a class="dropdown-item" href="https://www.directlink.com" data-xtranslate="DIRECT_LINK" aria-label="Direct Link">Direct Link</a>            </div>          </div>        </div>      </li>    </ul>    <ul>      <li id="topbarLogin" class="desktopDesign" role="topbarLogin" style="display: flex;">        <div class="main-menu-dropdown">          <button id="topbarNotLoggedIn" onclick="pnTopbar.showLoginMenu(event, this);" class="dropbtn" tabindex="2" aria-expanded="false">            <span id="login" tabindex="-1">              <span data-xtranslate="login" aria-label="Log ind">Log ind</span>&nbsp;/&nbsp;<span data-xtranslate="CREATE_ACCOUNT" aria-label="Create Account"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Create Account</font></font></span>            </span>            <svg class="angle-icon pn-topbar-login-angle-icon" width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="display: none;">              <g id="icons-/-16x16-/-solid-/-angle-small-down" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">                <g id="angle-small-down">                  <rect id="Bound" opacity="0.290969122" x="0" y="0" width="16" height="16"></rect>                  <polygon id="Combined-Shape" fill="#FFFFFF" transform="translate(7.999744, 8.666667) scale(1, -1) rotate(-270.000000) translate(-7.999744, -8.666667) " points="8.91641099 4.00025568 10.666411 4.00025568 10.666411 4.66771307 7.99974432 8.66771307 10.666411 12.6677131 10.666411 13.3330777 8.91641099 13.3330777 5.33307766 8.66666667">                  </polygon>                </g>              </g>            </svg>          </button>          <div class="main-menu-dropdown-content left" aria-hidden="true">            <div class="main-menu-header" data-xtranslate="CUSTOMER_PORTAL" aria-label="Customer portal"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Customer portal</font></font></font></font></div>            <div class="dropdownWrapper">              <div class="btnWrapper">                <button class="accountBtn" onclick="pnTopbar.login()" tabindex="3">                  <span class="accountBtnText" data-xtranslate="login" tabindex="-1" aria-label="Log ind"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Log ind</font></font></font></font></span>                </button>              </div>              <a onclick="pnTopbar.createNewUser()" class="loginBtn" tabindex="4">                <span data-xtranslate="CREATE_NEW_ACCOUNT" class="loginBtnText focus-class-links" tabindex="-1" aria-label="Create new account"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Create new account</font></font></span>              </a>              <span class="loginItems" role="loginItems">                <!-- Will be filled with dynamic login items if any -->              </span>            </div>          </div>        </div>      </li>      <!-- New design on Logged in user -->      <li id="topbarUser" class="desktopDesign" role="topbarUser" style="display: none;">        <div class="main-menu-dropdown">          <button id="openLoggedInMenu" onclick="pnTopbar.showMenu(event, this);" class="dropbtn" tabindex="2" aria-expanded="false">            <span class="dropdown-label pn-topbar-selected-org-name-top-label"></span>            <span class="dropdown-label pn-topbar-user-label" data-xtranslate="USER" aria-label="User"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">User</font></font></span>            <span id="loggedInUserName" class="dropdown-selected-value ellipsis" tabindex="-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">User</font></font></span>            <svg class="angle-icon" width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">              <g id="icons-/-16x16-/-solid-/-angle-small-down" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">                <g id="angle-small-down">                  <rect id="Bound" opacity="0.290969122" x="0" y="0" width="16" height="16"></rect>                  <polygon id="Combined-Shape" fill="#FFFFFF" transform="translate(7.999744, 8.666667) scale(1, -1) rotate(-270.000000) translate(-7.999744, -8.666667) " points="8.91641099 4.00025568 10.666411 4.00025568 10.666411 4.66771307 7.99974432 8.66771307 10.666411 12.6677131 10.666411 13.3330777 8.91641099 13.3330777 5.33307766 8.66666667">                  </polygon>                </g>              </g>            </svg>          </button>          <div id="topbarMyPages" class="main-menu-dropdown-content left" aria-hidden="true">            <div class="dropdownWrapper">              <div class="main-menu-header pn-topbar-acting-as hidden" data-xtranslate="ACTING_AS" aria-label="Works as"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Works as</font></font></div>              <div class="top-dropdown-container pn-topbar-login-status-container pn-topbar-acting-as-container hidden">                <div class="switchUserEmail" role="switchUserEmail"></div>              </div>              <div class="main-menu-header pn-topbar-logged-in" data-xtranslate="LOGGED_IN_AS" aria-label="Logged in as"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Logged in as</font></font></div>              <div class="top-dropdown-container pn-topbar-login-status-container">                <div class="userInformationName"></div>                <div class="userInformationEmail" role="userInformationEmail"></div>                <div class="pn-topbar-selected-org-container">                  <p class="pn-topbar-selected-org-name"></p>                  <p class="pn-topbar-selected-org-number"></p>                </div>                <div class="btnWrapper topbarMyAccountBtn" id="topbarOpenMyAccountBtn">                  <button class="accountBtn" onclick="pnTopbar.openMyAccount()" tabindex="3">                    <span class="accountBtnText focus-class-links" tabindex="-1" data-xtranslate="MY_ACCOUNT" aria-label="My account"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">My account</font></font></span>                  </button>                </div>                <div class="btnWrapper switchUserFullAccessContainer hidden">                  <button class="accountBtn switchUserFullAccessBtn">                    <div class="accountBtnText switchUserFullAccessBtnText focus-class-links" tabindex="-1">                      <span data-xtranslate="REQUEST_FULL_ACCESS" aria-label="Request full access"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Request full access</font></font></span>                      <div></div>                    </div>                  </button>                </div>              </div>              <span class="loginItems" role="loginItems">                <!-- Will be filled with dynamic login items if any -->              </span>              <div class="pn-divider"></div>              <div class="lower-btn-container">                <div class="pn-topbar-org-list"></div>                <a onclick="pnTopbar.logout()" class="loginBtn pn-topbar-logout-btn" tabindex="5">                  <span data-xtranslate="LOGOUT" class="loginBtnText focus-class-links" tabindex="-1" aria-label="log out"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">log out</font></font></span>                </a>              </div>            </div>          </div>        </div>      </li>      <!-- New design of Market -->      <li data-name="topbarMarkets" class="desktopDesign">        <div class="main-menu-dropdown">          <button id="marketBtn" onclick="pnTopbar.showMenu(event, this);" class="dropbtn" tabindex="6" role="tooltip" name="COUNTRY" aria-expanded="false">            <span class="dropdown-label" data-xtranslate="COUNTRY" aria-label="Land">Land</span>            <span class="dropdown-selected-value" id="marketText" tabindex="-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Denmark</font></font></span>            <svg class="angle-icon" width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">              <g id="icons-/-16x16-/-solid-/-angle-small-down" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">                <g id="angle-small-down">                  <rect id="Bound" opacity="0.290969122" x="0" y="0" width="16" height="16"></rect>                  <polygon id="Combined-Shape" fill="#FFFFFF" transform="translate(7.999744, 8.666667) scale(1, -1) rotate(-270.000000) translate(-7.999744, -8.666667) " points="8.91641099 4.00025568 10.666411 4.00025568 10.666411 4.66771307 7.99974432 8.66771307 10.666411 12.6677131 10.666411 13.3330777 8.91641099 13.3330777 5.33307766 8.66666667">                  </polygon>                </g>              </g>            </svg>          </button>          <div id="marketDropdown" class="main-menu-dropdown-content left" aria-hidden="true">            <div></div>            <div class="dropdownWrapper" role="marketSelector"><a onclick="pnTopbar.changeMarkets(event,&quot;se&quot;);" class="dropdown-item" href="https://www.postnord.se" role="SE" id="SE" tabindex="7" data-value="SE" style="padding: 0px;"><span data-xtranslate="SWEDEN" class="focus-class-links" tabindex="-1" aria-label="Sweden"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Sweden</font></font></span></a><a onclick="pnTopbar.changeMarkets(event,&quot;dk&quot;);" class="dropdown-item selected" style="color:#005D92; padding: 0px;" "="" href="https://www.postnord.dk" role="DK" id="DK" tabindex="8" data-value="DK"><span data-xtranslate="DENMARK" class="focus-class-links" tabindex="-1" aria-label="Denmark"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Denmark</font></font></font></font></span></a></div>          </div>        </div>      </li>      <!-- New design of language -->      <li data-name="topbarLanguages" class="desktopDesign">        <div class="main-menu-dropdown">          <button id="languageBtn" onclick="pnTopbar.showMenu(event, this);" class="dropbtn" tabindex="11" role="tooltip" name="LANGUAGE" aria-expanded="false">            <span class="dropdown-label" data-xtranslate="LANGUAGE" aria-label="Language"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Language</font></font></span>            <span class="dropdown-selected-value" id="languageText" tabindex="-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Danish</font></font></span>            <svg class="angle-icon" width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">              <g id="icons-/-16x16-/-solid-/-angle-small-down" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">                <g id="angle-small-down">                  <rect id="Bound" opacity="0.290969122" x="0" y="0" width="16" height="16"></rect>                  <polygon id="Combined-Shape" fill="#FFFFFF" transform="translate(7.999744, 8.666667) scale(1, -1) rotate(-270.000000) translate(-7.999744, -8.666667) " points="8.91641099 4.00025568 10.666411 4.00025568 10.666411 4.66771307 7.99974432 8.66771307 10.666411 12.6677131 10.666411 13.3330777 8.91641099 13.3330777 5.33307766 8.66666667">                  </polygon>                </g>              </g>            </svg>          </button>          <div class="main-menu-dropdown-content right" id="languageDropdown" aria-hidden="true">            <div></div>            <div class="dropdownWrapper" role="langageSelector"><a class="dropdown-item selected" onclick="pnTopbar.changeLanguage(event,&quot;da&quot;);" data-value="da" href="#/da" tabindex="12" style="padding: 0px;"><span class="focus-class-links" tabindex="-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Danish</font></font></font></font></span></a><a class="dropdown-item" onclick="pnTopbar.changeLanguage(event,&quot;en&quot;);" data-value="en" href="#/en" tabindex="13" style="padding: 0px;"><span class="focus-class-links" tabindex="-1">English</span></a></div>          </div>        </div>      </li>      <!-- New design of notifications -->      <li id="topbarAlerts" class="desktopDesign" role="alertsElements">        <div class="main-menu-dropdown">          <button type="button" onclick="pnTopbar.showMenu(event, this);" aria-controls="dropdown-toolbarlinks" aria-pressed="false" aria-expanded="false" id="topbarAlertsMenu" tabindex="41" class="dropbtn" role="tooltip" name="notifications">            <span aria-label="number of alerts" class="count-badge" title="1">1</span>            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 18" tabindex="-1" class="pn-topbar-alerts-icon">              <title data-xtranslate="notifications" aria-label="Notifikationer">Notifikationer</title>              <path fill-rule="evenodd" clip-rule="evenodd" d="M2 6a6 6 0 1 1 12 0v1.586l.536.535A5 5 0 0 1 16 11.657V12a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1v-.343A5 5 0 0 1 1.464 8.12L2 7.586V6Zm6-4a4 4 0 0 0-4 4v2a1 1 0 0 1-.293.707l-.828.829A3 3 0 0 0 2.073 11h11.854a3 3 0 0 0-.806-1.464l-.828-.829A1 1 0 0 1 12 8V6a4 4 0 0 0-4-4ZM4.684 14.051a1 1 0 0 1 1.265.633C6.257 15.608 7.222 16 8 16c.778 0 1.743-.392 2.051-1.316a1 1 0 0 1 1.898.632C11.257 17.392 9.222 18 8 18s-3.257-.608-3.949-2.684a1 1 0 0 1 .633-1.265Z" fill="#fff"></path>            </svg>          </button>          <div class="main-menu-dropdown-content topbar-alerts-container" aria-hidden="true">            <div class="main-menu-header" data-xtranslate="notifications" aria-label="Notifikationer"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Notifications</font></font></div>            <div class="dropdownWrapper">              <unread-notifications class="hide">                <div class="weak noNotifications" data-xtranslate="0_UNREAD_NOTIFICATIONS" aria-label="0 ulæste notifikationer"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0 unread notifications</font></font></div>              </unread-notifications>              <notifications class=""><a class="notificationItemStyle"><p class="notificationTextStyle notificationUnreadStyle" style="font-size: 14px;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Problems with push notifications on complaints</font></font></p><p class="notificationTextStyle notificationUnreadStyle" style="font-size: 12px;">2022-11-09<span style="min-width:6px; padding:0px; display: inline-block;"></span>08:51</p><div class="notificationRichTextContainer"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">We are currently experiencing problems with pushing out notifications on ongoing complaints. </font><font style="vertical-align: inherit;">We are working on correcting the error.</font></font></div></a><a class="notificationItemStyle"><p class="notificationTextStyle" style="font-size: 14px;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Danish VAT and customs duties</font></font></p><p class="notificationTextStyle" style="font-size: 12px;">2021-12-13<span style="min-width:6px; padding:0px; display: inline-block;"></span>05:57</p><div class="notificationRichTextContainer">Grundet vedligeholdelse er det ikke muligt at betale told fakturaer mellem 12:30 - 13:30 i dag, 13 december.</div></a></notifications>              <a id="topbarAlertsNavigation" href="https://portal.postnord.com/pnalerts/" class="allNotifications" tabindex="42">                <span data-xtranslate="ALL_NOTIFICATIONS" class="focus-class-links allNotificationsText" tabindex="-1" aria-label="Alle notifikationer">Alle notifikationer</span>              </a>            </div>          </div>        </div>      </li>      <!-- New design on Cart -->      <li class="desktopDesign">        <div class="main-menu-dropdown" style="display: none;">          <a id="topbarCart" role="topbarCart" tabindex="44" class="dropbtn" style="display: none;" href="https://portal.postnord.com/skickadirekt/payment">            <span class="hide count-badge" title=""></span>            <svg xmlns="http://www.w3.org/2000/svg" width="23" height="22" viewBox="0 0 23 22" class="focus-class-main" tabindex="-1">              <title data-xtranslate="CART" aria-label="Varekurv">Varekurv</title>              <path fill="#FFF" fill-rule="evenodd" d="M19.318 17.217c-1.367 0-2.476 1.072-2.476 2.392 0 1.32 1.11 2.391 2.476 2.391 1.367 0 2.477-1.071 2.477-2.391s-1.11-2.392-2.477-2.392zm-9.907 0c-1.367 0-2.476 1.072-2.476 2.392 0 1.32 1.11 2.391 2.476 2.391 1.368 0 2.477-1.071 2.477-2.391s-1.11-2.392-2.477-2.392zm13.375-4.646v-8.38H5.944L4.34 0H0v2.095h3.255l2.69 10.34c-.496.478-.992.956-.992 1.913 0 .956.991 1.913 1.982 1.913.04.005 15.85 0 15.85 0v-1.913H7.43c-.248 0-.495-.24-.495-.478 0-.24.247-.479.495-.479l15.356-.82z"></path>            </svg>          </a>        </div>      </li>      <!-- New mobile design.  -->      <li id="mobile-menu">        <div id="mobileTopbarMainMenu" class="main-menu-dropdown" role="topbarMainMenu">          <!-- Postnord logo for mobile  -->          <a id="topbarLogoMobile" class="topbarlogo" href="#" tabindex="1" style="margin-right: auto;">            <svg class="postnord-topbar-logo focus-class-main" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="958.69" height="592.78998" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 600 114" enable-background="new 0 0 600 114" xml:space="preserve" tabindex="-1" style="height: 34px">              <g>                <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M0.5,23c8.159-0.027,16.317-0.026,24.476-0.11   c1.395-0.014,1.69,0.555,1.625,1.773c-0.076,1.408-0.018,2.824-0.018,4.321c0.306-0.057,0.597-0.022,0.742-0.151   c17.247-15.289,43.533-9.186,51.751,12.423c5.855,15.397,4.752,30.333-6.376,43.337c-11.739,13.717-34.058,14.373-45.195,5.514   c-0.173-0.138-0.425-0.176-1.005-0.404c0,8.232,0,16.264,0,24.297c-7.9,0-15.8-0.057-23.699,0.044   c-1.772,0.022-2.363-0.238-2.358-2.233C0.525,82.207,0.5,52.604,0.5,23z M25.926,58.078c-0.111,8.506,5.778,14.645,14.196,14.797   c8.028,0.145,14.247-5.814,14.377-13.776c0.149-9.208-5.378-15.385-13.883-15.515C32.008,43.452,26.041,49.34,25.926,58.078z"></path>                <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M600.5,94c-7.313-0.483-14.635-0.077-21.951-0.209   c-0.749-0.013-1.509-0.079-2.246,0.016c-1.623,0.209-2.021-0.555-1.909-2.022c0.106-1.39,0.022-2.795,0.022-4.542   c-1.484,1.232-2.677,2.336-3.98,3.287c-12.225,8.908-31.617,6.816-41.996-4.505c-12.975-14.155-12.913-39.895-0.158-54.186   c11.564-12.955,33.688-14.569,45.262-5.357c0.167,0.133,0.427,0.149,0.873,0.296c0-6.274,0.096-12.406-0.057-18.531   c-0.046-1.872,0.67-2.394,2.293-2.696c6.945-1.293,13.872-2.685,20.807-4.037c0.398-0.078,0.84-0.046,1.041-0.515   c1.711-0.378,2.053,0.288,2.049,2C600.481,33.333,600.5,63.666,600.5,94z M546.501,58.162c-0.007,8.704,5.763,14.765,14.097,14.809   c8.521,0.047,14.443-5.975,14.477-14.719c0.031-8.51-5.903-14.465-14.411-14.461C552.249,43.795,546.507,49.622,546.501,58.162z"></path>                <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M418.68,20.469c7.956,0.122,14.641,1.237,21.007,3.964   c14.999,6.423,22.888,20.112,21.583,36.413c-1.56,19.49-14.82,30.803-32.305,34.098c-10.387,1.959-20.588,1.152-30.359-3.009   c-15.441-6.573-22.246-19.692-21.436-35.479c1.156-22.514,17.57-33.092,35.115-35.436C414.754,20.69,417.254,20.588,418.68,20.469z    M404.795,58.289c0.002,8.482,6.156,14.709,14.416,14.588c8.381-0.123,14.197-6.057,14.205-14.492   c0.008-8.794-5.865-14.836-14.389-14.802C410.632,43.617,404.791,49.65,404.795,58.289z"></path>                <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M129.176,20.482c10.908,0.271,21.103,2.735,29.691,9.914   c7.15,5.977,10.82,13.792,11.622,22.978c0.916,10.492-1.016,20.253-8.051,28.488c-6.028,7.055-13.9,10.938-22.862,12.817   c-10.625,2.228-21.037,1.558-31.112-2.567c-16.718-6.844-23.339-21.486-21.72-37.907c1.813-18.375,14.729-29.348,31.757-32.67   C122.021,20.848,125.578,20.472,129.176,20.482z M128.742,43.584c-8.521-0.068-14.478,5.886-14.648,14.643   c-0.16,8.229,6.154,14.627,14.443,14.633c8.247,0.006,14.273-6.037,14.366-14.404C142.997,49.93,137.017,43.65,128.742,43.584z"></path>                <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M324.639,28.651c8.594-8.386,18.7-9.742,29.544-6.832   c9.833,2.639,14.446,10.021,16.273,19.528c0.489,2.543,0.64,5.113,0.637,7.703c-0.019,14.081-0.042,28.161,0.029,42.241   c0.01,1.875-0.365,2.59-2.431,2.553c-7.162-0.133-14.33-0.115-21.493-0.008c-1.939,0.029-2.548-0.473-2.538-2.49   c0.053-11.744-0.033-23.49-0.104-35.235c-0.007-1.157-0.137-2.329-0.354-3.466c-1.214-6.333-3.75-8.44-9.795-8.213   c-5.817,0.218-9.371,3.372-9.884,9.181c-0.579,6.562-0.163,13.155-0.221,19.734c-0.054,6.081-0.073,12.164,0.026,18.244   c0.029,1.776-0.547,2.259-2.273,2.238c-7.331-0.083-14.664-0.077-21.995-0.002c-1.607,0.016-2.106-0.403-2.102-2.082   c0.058-22.246,0.063-44.491-0.005-66.735c-0.005-1.857,0.645-2.147,2.286-2.129c7.165,0.082,14.332,0.114,21.494-0.014   c2.094-0.038,2.843,0.564,2.594,2.642C324.215,26.448,324.074,27.473,324.639,28.651z"></path>                <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M211.215,20.546c8.705,0.298,16.646,0.971,24.469,2.806   c1.644,0.386,1.959,0.893,1.548,2.508c-1.332,5.236-2.582,10.498-3.658,15.792c-0.402,1.981-1.126,2.04-2.841,1.527   c-8.105-2.422-16.334-3.978-24.853-2.736c-0.653,0.095-1.295,0.284-1.93,0.472c-1.563,0.46-2.785,1.376-2.767,3.105   c0.019,1.79,1.407,2.568,2.948,2.917c5.601,1.269,11.371,1.593,16.944,3.038c2.986,0.774,5.918,1.682,8.708,3.009   c7.723,3.672,11.162,9.681,10.907,18.218c-0.302,10.111-5.477,16.606-14.466,20.478c-7.246,3.119-14.946,3.904-22.702,4.075   c-9.706,0.214-19.249-1.075-28.61-3.718c-1.525-0.431-1.939-0.91-1.485-2.545c1.534-5.527,2.936-11.093,4.245-16.678   c0.423-1.804,1.067-1.934,2.69-1.309c8.626,3.319,17.51,5.265,26.834,4.569c1.261-0.095,2.486-0.319,3.63-0.831   c1.287-0.574,2.195-1.458,2.18-3.033c-0.015-1.588-0.941-2.426-2.275-2.937c-2.905-1.114-5.99-1.359-9.034-1.76   c-5.292-0.696-10.524-1.649-15.497-3.649c-14.374-5.781-17.364-24.28-5.58-34.483c6.473-5.604,14.377-7.417,22.58-8.323   C206.092,20.74,209.012,20.681,211.215,20.546z"></path>                <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M245.499,50.268c0-13.667,0.042-27.333-0.047-41   c-0.013-1.896,0.495-2.345,2.345-2.316c7.248,0.112,14.501,0.127,21.748-0.007c1.991-0.037,2.341,0.654,2.285,2.421   c-0.121,3.83,0.048,7.668-0.075,11.498c-0.056,1.717,0.579,2.098,2.161,2.081c6.583-0.072,13.167,0.01,19.75-0.057   c1.734-0.018,2.28,0.252,1.311,2.007c-3.419,6.189-6.769,12.417-10.077,18.667c-0.596,1.125-1.319,1.502-2.556,1.464   c-2.748-0.084-5.507,0.099-8.247-0.068c-1.89-0.115-2.359,0.479-2.349,2.35c0.081,14.416,0.045,28.833,0.044,43.25   c0,3.23-0.001,3.231-3.204,3.232c-6.833,0-13.668-0.084-20.499,0.051c-2.051,0.041-2.656-0.46-2.641-2.574   C245.546,77.602,245.499,63.935,245.499,50.268z"></path>                <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M493.583,30.506c5.988-8.059,13.937-9.128,22.504-8.469   c1.558,0.119,2.31,0.717,2.241,2.489c-0.261,6.734-0.4,13.473-0.518,20.211c-0.027,1.597-0.529,2.004-2.111,1.595   c-2.996-0.774-6.07-1.013-9.166-0.75c-8.641,0.735-12.903,5.295-12.938,13.97c-0.043,10.494-0.067,20.988,0.035,31.48   c0.021,2.093-0.354,2.877-2.683,2.82c-7.074-0.174-14.156-0.104-21.234-0.033c-1.608,0.016-2.344-0.229-2.338-2.125   c0.066-22.236,0.058-44.473,0.01-66.708c-0.004-1.605,0.406-2.127,2.068-2.108c7.41,0.086,14.824,0.084,22.234,0.001   c1.592-0.019,2.025,0.507,1.922,1.999C493.494,26.526,493.583,28.188,493.583,30.506z"></path>              </g>            </svg>          </a>          <!-- Mobile design on Cart -->          <div class="main-menu-dropdown" style="display: none;">            <a id="topbarCartMobile" role="topbarCart" style="display: none;" href="https://portal.postnord.com/skickadirekt/payment">              <span class="hide count-badge" style="top: -6px" title=""></span>              <svg xmlns="http://www.w3.org/2000/svg" width="23" height="22" viewBox="0 0 23 22">                <title data-xtranslate="CART" aria-label="Varekurv">Varekurv</title>                <path fill="#FFF" fill-rule="evenodd" d="M19.318 17.217c-1.367 0-2.476 1.072-2.476 2.392 0 1.32 1.11 2.391 2.476 2.391 1.367 0 2.477-1.071 2.477-2.391s-1.11-2.392-2.477-2.392zm-9.907 0c-1.367 0-2.476 1.072-2.476 2.392 0 1.32 1.11 2.391 2.476 2.391 1.368 0 2.477-1.071 2.477-2.391s-1.11-2.392-2.477-2.392zm13.375-4.646v-8.38H5.944L4.34 0H0v2.095h3.255l2.69 10.34c-.496.478-.992.956-.992 1.913 0 .956.991 1.913 1.982 1.913.04.005 15.85 0 15.85 0v-1.913H7.43c-.248 0-.495-.24-.495-.478 0-.24.247-.479.495-.479l15.356-.82z"></path>              </svg>            </a>          </div>          <!-- Hamburger menu for mobile version -->          <a id="moreMenu" onclick="pnTopbar.showMenu(event, this, 'more');" class="dropbtn" aria-expanded="false">            <span class="moreMenuText" data-xtranslate="more" aria-label="Mere">Mere</span>            <svg class="angle-icon" width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">              <g id="icons-/-16x16-/-solid-/-angle-small-down" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">                <g id="angle-small-down">                  <rect id="Bound" opacity="0.290969122" x="0" y="0" width="16" height="16"></rect>                  <polygon id="Combined-Shape" fill="#FFFFFF" transform="translate(7.999744, 8.666667) scale(1, -1) rotate(-270.000000) translate(-7.999744, -8.666667) " points="8.91641099 4.00025568 10.666411 4.00025568 10.666411 4.66771307 7.99974432 8.66771307 10.666411 12.6677131 10.666411 13.3330777 8.91641099 13.3330777 5.33307766 8.66666667">                  </polygon>                </g>              </g>            </svg>          </a>          <!-- Sub menu that will be visible on click  -->          <div class="mobile-main-menu-dropdown-content" aria-hidden="true">            <div class="dropdownWrapper">              <div class="mobil-menu-div-section-wrapper">                <!-- Mobile design for sites -->                <span id="mobileToolsMenu">                </span>                <span id="mobileMoreMenu">                  <div></div>                  <!-- Mobile design for sites -->                  <div data-name="topbarSites">                    <div class="mobil-menu-div-section" onclick="pnTopbar.showSubmenu(this, 'mobileMainMenuDropdown');" aria-controls="dropdown-toolbarlinks" aria-pressed="false" aria-expanded="false">                      <a data-xtranslate="sites" aria-label="Hjemmesider">Hjemmesider</a>                      <svg class="angle-icon" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">                        <g id="icons-/-24x24-/-solid-/-angle-small-down" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">                          <g id="angle-small-down">                            <rect id="Bound" x="0" y="0" width="24" height="24"></rect>                            <polygon id="Path" fill="#005D92" fill-rule="nonzero" transform="translate(11.999616, 13.000000) scale(1, -1) rotate(-270.000000) translate(-11.999616, -13.000000) " points="13.3746165 6.00038351 15.9996165 6.00038351 15.9996165 7.00156961 11.9996165 13.0015696 15.9996165 19.0015696 15.9996165 19.9996165 13.3746165 19.9996165 7.99961649 13">                            </polygon>                          </g>                        </g>                      </svg>                    </div>                    <div class="main-menu-dropdown-content mobile-version" id="mobileMainMenuDropdown" aria-hidden="true">                      <div class="dropdownWrapper mobile-version-under-menu" id="sitesWrapper" role="siteSelector">                        <main-menu><a href="https://www.postnord.dk" tabindex="18" style="display: block;"><div class="focus-class-links tool-dropdown-style" tabindex="-1"><div class="main-menu-dropdown-item-name-container"><div class="main-menu-dropdown-item-name" data-xtranslate="postnord.dk" aria-label="postnord.dk">postnord.dk</div></div><div class="main-menu-dropdown-item-description" data-xtranslate="INFORMATION_ABOUT_POSTNORD" aria-label="Information om PostNord">Information om PostNord</div></div></a><a href="https://portal.postnord.com/" tabindex="19" style="display: block;"><div class="focus-class-links tool-dropdown-style" tabindex="-1"><div class="main-menu-dropdown-item-name-container"><div class="main-menu-dropdown-item-name" data-xtranslate="CUSTOMER_PORTAL" style="color:#bebebe" aria-label="Kundeportal">Kundeportal</div></div><div class="main-menu-dropdown-item-description" data-xtranslate="MANAGE_YOUR_SHIPMENTS" aria-label="Håndtere dine forsendelser">Håndtere dine forsendelser</div></div></a><a href="https://www.postnord.com" tabindex="20" style="display: block;"><div class="focus-class-links tool-dropdown-style" tabindex="-1"><div class="main-menu-dropdown-item-name-container"><div class="main-menu-dropdown-item-name" data-xtranslate="postnord.com" aria-label="postnord.com">postnord.com</div></div><div class="main-menu-dropdown-item-description" data-xtranslate="INFORMATION_ABOUT_POSTNORD_GROUP" aria-label="Information om PostNord Group">Information om PostNord Group</div></div></a></main-menu>                      </div>                    </div>                  </div>                  <!-- Mobile design for language -->                  <div data-name="topbarLanguages">                    <div class="mobil-menu-div-section" onclick="pnTopbar.showSubmenu(this, 'mobileLanguageDropdown');" aria-controls="dropdown-toolbarlinks" aria-pressed="false" aria-expanded="false">                      <a data-xtranslate="LANGUAGE" aria-label="Sprog">Sprog</a>                      <svg class="angle-icon" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">                        <g id="icons-/-24x24-/-solid-/-angle-small-down" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">                          <g id="angle-small-down">                            <rect id="Bound" x="0" y="0" width="24" height="24"></rect>                            <polygon id="Path" fill="#005D92" fill-rule="nonzero" transform="translate(11.999616, 13.000000) scale(1, -1) rotate(-270.000000) translate(-11.999616, -13.000000) " points="13.3746165 6.00038351 15.9996165 6.00038351 15.9996165 7.00156961 11.9996165 13.0015696 15.9996165 19.0015696 15.9996165 19.9996165 13.3746165 19.9996165 7.99961649 13">                            </polygon>                          </g>                        </g>                      </svg>                    </div>                    <div class="main-menu-dropdown-content mobile-version" id="mobileLanguageDropdown" aria-hidden="true">                      <div class="dropdownWrapper mobile-version-under-menu" id="languageWrapper" role="langageSelector"><a class="dropdown-item selected" onclick="pnTopbar.changeLanguage(event,&quot;da&quot;);" data-value="da" href="#/da" tabindex="12" style="padding: 0px;"><span class="focus-class-links" tabindex="-1">Dansk</span></a><a class="dropdown-item" onclick="pnTopbar.changeLanguage(event,&quot;en&quot;);" data-value="en" href="#/en" tabindex="13" style="padding: 0px;"><span class="focus-class-links" tabindex="-1">English</span></a></div>                    </div>                  </div>                  <!-- Mobile design of Market -->                  <div class="mobil-menu-div-section" onclick="pnTopbar.showSubmenu(this, 'mobileMarketDropdown');" aria-controls="dropdown-toolbarlinks" aria-pressed="false" aria-expanded="false">                    <a data-xtranslate="COUNTRY" aria-label="Land">Land</a>                    <svg class="angle-icon" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">                      <g id="icons-/-24x24-/-solid-/-angle-small-down" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">                        <g id="angle-small-down">                          <rect id="Bound" x="0" y="0" width="24" height="24"></rect>                          <polygon id="Path" fill="#005D92" fill-rule="nonzero" transform="translate(11.999616, 13.000000) scale(1, -1) rotate(-270.000000) translate(-11.999616, -13.000000) " points="13.3746165 6.00038351 15.9996165 6.00038351 15.9996165 7.00156961 11.9996165 13.0015696 15.9996165 19.0015696 15.9996165 19.9996165 13.3746165 19.9996165 7.99961649 13">                          </polygon>                        </g>                      </g>                    </svg>                  </div>                  <div data-name="topbarMarkets" id="mobileMarketDropdown" class="main-menu-dropdown-content mobile-version" aria-hidden="true">                    <div class="dropdownWrapper mobile-version-under-menu" role="marketSelector"><a onclick="pnTopbar.changeMarkets(event,&quot;se&quot;);" class="dropdown-item" href="https://www.postnord.se" role="SE" id="SE" tabindex="7" data-value="SE" style="padding: 0px;"><span data-xtranslate="SWEDEN" class="focus-class-links" tabindex="-1" aria-label="Sverige">Sverige</span></a><a onclick="pnTopbar.changeMarkets(event,&quot;dk&quot;);" class="dropdown-item selected" style="color:#005D92; padding: 0px;" "="" href="https://www.postnord.dk" role="DK" id="DK" tabindex="8" data-value="DK"><span data-xtranslate="DENMARK" class="focus-class-links" tabindex="-1" aria-label="Danmark">Danmark</span></a></div>                  </div>                  <!-- Mobile design of notifications -->                  <div role="alertsElements" class="mobil-menu-div-section">                    <a id="topbarAlertsNavigationMobile" href="https://portal.postnord.com/pnalerts/" style="width: 100%" data-xtranslate="notifications" aria-label="Notifikationer">Notifikationer</a>                    <div aria-label="number of alerts" style="width:20px; margin-right: 26px; position: inherit" class="count-badge" title="1">1</div>                  </div>                  <div class="mobil-menu-div-section" aria-hidden="true" role="topbarUser" style="display: none;">                    <div class="userInformationWrapper">                      <div class="mobileUserInformationExtraStyle userInformationName"></div>                      <div class="userInformationEmail" role="userInformationEmail"></div>                      <div class="pn-topbar-selected-org-container">                        <p class="pn-topbar-selected-org-name"></p>                        <p class="pn-topbar-selected-org-number"></p>                      </div>                    </div>                  </div>                  <!-- Mobile design not logged in user -->                  <div id="topbarMobileLoggedOutDiv" class="mobil-menu-div-section" aria-hidden="true" role="topbarLogin" style="display: flex;">                    <a class="topbarMobileBtn mobileLoginBtn pn-topbar-create-account-btn-mobile" onclick="pnTopbar.createNewUser()" style="display: none;">                      <span class="loginBtnMobileText" data-xtranslate="CREATE_NEW_ACCOUNT" aria-label="Opret ny konto">Opret ny konto</span>                    </a>                    <a class="topbarMobileBtn mobileLoginBtn" onclick="pnTopbar.login()" href="#">                      <span class="loginBtnMobileText" data-xtranslate="login" aria-label="Log ind">Log ind</span>                    </a>                  </div>                  <!-- Mobile design on Logged in user -->                  <div id="topbarMobileLoggedInDiv" class="mobil-menu-div-section" aria-hidden="true" role="topbarUser" style="display: none;">                    <a class="topbarMobileBtn mobileLoginBtn" onclick="pnTopbar.openMyAccount()">                      <span class="loginBtnMobileText" data-xtranslate="MY_ACCOUNT" aria-label="Min konto">Min konto</span>                    </a>                    <div class="pn-topbar-org-list"></div>                  </div>                  <div id="topbarMobileLogoutBtnDiv" class="mobil-menu-div-section" aria-hidden="true" role="topbarUser" style="display: none;">                    <div class="loggedInUserBtnWrapper">                      <a onclick="pnTopbar.logout()" class="topbarMobileBtn mobileLoginBtn topbarMobileLogoutBtn pn-topbar-logout-btn">                        <span class="loginBtnMobileText" data-xtranslate="LOGOUT" aria-label="Log ud">Log ud</span>                      </a>                    </div>                  </div>                  <!-- Mobile design dynamic login items -->                  <span id="loginItemsMobileView" role="loginItems" class="mobileLoginItemsContainer" aria-hidden="true">                    <!-- Will be filled with dynamic login items if any -->                  </span>                </span>              </div>            </div>          </div>        </div>      </li>    </ul>  </div></div><!-- reminder alert to be displayed below the topbar --><div class="pn-reminder-alert hidden">  <div class="pn-reminder-alert-left-wrapper">    <svg class="pn-reminder-alert-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">      <path fill-rule="evenodd" clip-rule="evenodd" d="M4 12C4 7.58172 7.58172 4 12 4C16.4183 4 20 7.58172 20 12C20 16.4183 16.4183 20 12 20C7.58172 20 4 16.4183 4 12ZM12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2ZM12 10C11.1716 10 10.5 9.32843 10.5 8.5C10.5 7.67157 11.1716 7 12 7C12.8284 7 13.5 7.67157 13.5 8.5C13.5 9.32843 12.8284 10 12 10ZM13 12V16.5C13 17.0523 12.5523 17.5 12 17.5C11.4477 17.5 11 17.0523 11 16.5V12C11 11.4477 11.4477 11 12 11C12.5523 11 13 11.4477 13 12Z" fill="#005D92"></path>    </svg>    <div>      <h3 class="pn-reminder-alert-title"></h3>      <p class="pn-reminder-alert-message"></p>    </div>  </div>  <div class="pn-reminder-alert-right-wrapper">    <button class="pn-reminder-alert-button pn-reminder-alert-prev-button hidden topbar-button topbar-button-light" data-xtranslate="PREVIOUS" aria-label="Forrige">Forrige</button>    <button class="pn-reminder-alert-button pn-reminder-alert-next-button hidden topbar-button topbar-button-light" data-xtranslate="NEXT" aria-label="Næste">Næste</button>  </div>  <button class="pn-reminder-close" title="close" aria-label="close button">    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">      <path fill-rule="evenodd" clip-rule="evenodd" d="M6.293 6.293a1 1 0 0 1 1.414 0L12 10.586l4.293-4.293a1 1 0 1 1 1.414 1.414L13.414 12l4.293 4.293a1 1 0 0 1-1.414 1.414L12 13.414l-4.293 4.293a1 1 0 0 1-1.414-1.414L10.586 12 6.293 7.707a1 1 0 0 1 0-1.414Z" fill="#005D92"></path>    </svg>  </button></div></div><!-- End Google Tag Manager --></pn-topbar><div ng-class="{'pn-page-container': isFeatureEnabled('portalMenu')}" class="pn-page-container"><pn-side-menu ng-show="isFeatureEnabled('portalMenu')" type="base" aria-hidden="false" class="hydrated pn-side-menu-sticky"><div class="pn-side-menu-collapsed-mobile"><div id="pnSideMenuContent"><div class="pn-side-menu-open-mobile"><div class="pn-side-menu-hamburger-container"><div class="pn-side-menu-hamburger"><div class="hamburger-inner"></div></div></div><span id="pnPortalMenuMobileToggleText">Menu</span></div><div class="pn-side-menu-items-container" style="height: calc(100vh - 84px);"><div id="startPortalMenuLevel" class="menu-level menu-top-level"><a href="https://portal.postnord.com" target="" id="startPortalMenuItem" class="menu-item level-0 leaf-item"><pn-side-menu-icon class="menu-item-icon pn-icon hydrated" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;><path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M8.293 4.293A1 1 0 019 4h6a1 1 0 01.707.293L17 5.586V5a1 1 0 112 0v2.586l1.707 1.707A1 1 0 0121 10v9a1 1 0 01-1 1H4a1 1 0 01-1-1v-9a1 1 0 01.293-.707l5-5zM9.414 6l-3 3h3.172l3-3H9.414zM15 6.414l-4 4V18h2v-2.5a2.5 2.5 0 015 0V18h1v-7.586l-4-4zM16 18v-2.5a.5.5 0 00-1 0V18h1zm-7 0v-7H5v7h4z&quot; fill=&quot;#000&quot;/></svg>"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M8.293 4.293A1 1 0 019 4h6a1 1 0 01.707.293L17 5.586V5a1 1 0 112 0v2.586l1.707 1.707A1 1 0 0121 10v9a1 1 0 01-1 1H4a1 1 0 01-1-1v-9a1 1 0 01.293-.707l5-5zM9.414 6l-3 3h3.172l3-3H9.414zM15 6.414l-4 4V18h2v-2.5a2.5 2.5 0 015 0V18h1v-7.586l-4-4zM16 18v-2.5a.5.5 0 00-1 0V18h1zm-7 0v-7H5v7h4z" fill="#000"></path></svg></pn-side-menu-icon><span class="menu-item-text">Start</span></a></div><div id="trackTracePortalMenuLevel" class="menu-level menu-top-level pn-side-menu-level-collapsed pn-side-menu-level-children-count-2"><pn-side-menu-icon class="menu-item-angle-down pn-icon small hydrated" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;><path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M12.707 15.707a1 1 0 01-1.414 0l-6-6a1 1 0 011.414-1.414L12 13.586l5.293-5.293a1 1 0 111.414 1.414l-6 6z&quot; fill=&quot;#000&quot;/></svg>"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12.707 15.707a1 1 0 01-1.414 0l-6-6a1 1 0 011.414-1.414L12 13.586l5.293-5.293a1 1 0 111.414 1.414l-6 6z" fill="#000"></path></svg></pn-side-menu-icon><pn-side-menu-icon class="menu-item-angle-up pn-icon small hydrated" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;><path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M11.293 8.293a1 1 0 011.414 0l6 6a1 1 0 01-1.414 1.414L12 10.414l-5.293 5.293a1 1 0 01-1.414-1.414l6-6z&quot; fill=&quot;#000&quot;/></svg>"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M11.293 8.293a1 1 0 011.414 0l6 6a1 1 0 01-1.414 1.414L12 10.414l-5.293 5.293a1 1 0 01-1.414-1.414l6-6z" fill="#000"></path></svg></pn-side-menu-icon><a target="" id="trackTracePortalMenuItem" class="menu-item level-0 non-leaf-item"><pn-side-menu-icon class="menu-item-icon pn-icon hydrated" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;><path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M10.97 4.2C10.24 3.328 10.861 2 12 2c1.138 0 1.76 1.327 1.031 2.2l-1.03 1.238L10.968 4.2zM12 0C9.167 0 7.62 3.305 9.433 5.481l1.799 2.16a1 1 0 001.536 0l1.8-2.16C16.38 3.305 14.833 0 12 0zM8.067 5.987a5.113 5.113 0 01-.59-.97 3 3 0 00-2.42 1.742l-1.609 3.538A5 5 0 003 12.367V20a3 3 0 003 3h12a3 3 0 003-3v-7.634a5 5 0 00-.448-2.069L18.943 6.76a3 3 0 00-2.42-1.743c-.154.334-.35.66-.59.971L15.154 7h1.058a1 1 0 01.91.586l1.325 2.914H5.553l1.324-2.914A1 1 0 017.787 7h1.059l-.779-1.013zM19 12.5H5V20a1 1 0 001 1h12a1 1 0 001-1v-7.5zM6.5 15a1 1 0 011-1H9a1 1 0 110 2H7.5a1 1 0 01-1-1z&quot; fill=&quot;#000&quot;/></svg>"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M10.97 4.2C10.24 3.328 10.861 2 12 2c1.138 0 1.76 1.327 1.031 2.2l-1.03 1.238L10.968 4.2zM12 0C9.167 0 7.62 3.305 9.433 5.481l1.799 2.16a1 1 0 001.536 0l1.8-2.16C16.38 3.305 14.833 0 12 0zM8.067 5.987a5.113 5.113 0 01-.59-.97 3 3 0 00-2.42 1.742l-1.609 3.538A5 5 0 003 12.367V20a3 3 0 003 3h12a3 3 0 003-3v-7.634a5 5 0 00-.448-2.069L18.943 6.76a3 3 0 00-2.42-1.743c-.154.334-.35.66-.59.971L15.154 7h1.058a1 1 0 01.91.586l1.325 2.914H5.553l1.324-2.914A1 1 0 017.787 7h1.059l-.779-1.013zM19 12.5H5V20a1 1 0 001 1h12a1 1 0 001-1v-7.5zM6.5 15a1 1 0 011-1H9a1 1 0 110 2H7.5a1 1 0 01-1-1z" fill="#000"></path></svg></pn-side-menu-icon><span class="menu-item-text">Track &amp; trace</span></a><div id="trackShipmentIdPortalMenuLevel" class="menu-level"><a href="https://portal.postnord.com/tracking/" target="" id="trackShipmentIdPortalMenuItem" class="menu-item level-1 leaf-item"><span class="menu-item-text"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Track with Shipment ID</font></font></span></a></div><div id="trackShipmentReferencePortalMenuLevel" class="menu-level"><a href="https://portal.postnord.com/tracking/reference/" target="" id="trackShipmentReferencePortalMenuItem" class="menu-item level-1 leaf-item"><span class="menu-item-text"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Track with reference</font></font></span></a></div></div><div id="sendTraceableShipmentsDKPortalMenuLevel" class="menu-level menu-top-level pn-side-menu-level-expanded has-active-child"><a href="https://portal.postnord.com/onlineporto/" target="" id="sendTraceableShipmentsDKPortalMenuItem" class="menu-item level-0 leaf-item menu-item-active"><pn-side-menu-icon class="menu-item-icon pn-icon hydrated" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;><path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M4.56 3.457A3 3 0 017.132 2h9.736a3 3 0 012.572 1.457l1.848 3.078A5 5 0 0122 9.108V19a3 3 0 01-3 3H5a3 3 0 01-3-3V9.108a5 5 0 01.713-2.573L4.56 3.457zM7.132 4a1 1 0 00-.857.486L4.428 7.563A3 3 0 004 9.108V19a1 1 0 001 1h14a1 1 0 001-1V9.108a3 3 0 00-.427-1.544l-1.848-3.079A1 1 0 0016.868 4H7.132zM12 5.5a1 1 0 011 1V8h4.5a1 1 0 110 2h-11a1 1 0 010-2H11V6.5a1 1 0 011-1zM6 13a1 1 0 011-1h2a1 1 0 110 2H7a1 1 0 01-1-1z&quot; fill=&quot;#000&quot;/></svg>"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M4.56 3.457A3 3 0 017.132 2h9.736a3 3 0 012.572 1.457l1.848 3.078A5 5 0 0122 9.108V19a3 3 0 01-3 3H5a3 3 0 01-3-3V9.108a5 5 0 01.713-2.573L4.56 3.457zM7.132 4a1 1 0 00-.857.486L4.428 7.563A3 3 0 004 9.108V19a1 1 0 001 1h14a1 1 0 001-1V9.108a3 3 0 00-.427-1.544l-1.848-3.079A1 1 0 0016.868 4H7.132zM12 5.5a1 1 0 011 1V8h4.5a1 1 0 110 2h-11a1 1 0 010-2H11V6.5a1 1 0 011-1zM6 13a1 1 0 011-1h2a1 1 0 110 2H7a1 1 0 01-1-1z" fill="#000"></path></svg></pn-side-menu-icon><span class="menu-item-text">Online Porto</span></a></div><div id="claimsPortalMenuLevel" class="menu-level menu-top-level"><a href="https://portal.postnord.com/claimspublic/" target="" id="claimsPortalMenuItem" class="menu-item level-0 leaf-item"><pn-side-menu-icon class="menu-item-icon pn-icon hydrated" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;><path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M7.5 3a1 1 0 011 1v.015a7 7 0 00.209 1.698L9.281 8h5.438l.572-2.287a7 7 0 00.209-1.698V4a1 1 0 112 0v.015c0 .736-.09 1.47-.269 2.183l-.572 2.287A2 2 0 0114.79 10c.365.521.838 1.138 1.42 1.774a2.04 2.04 0 01.28 2.386l-2.753 4.818c-.767 1.343-2.705 1.343-3.473 0l-2.752-4.818a2.04 2.04 0 01.28-2.386 17.373 17.373 0 001.42-1.774 2 2 0 01-1.87-1.514l-.572-2.287A9 9 0 016.5 4.015V4a1 1 0 011-1zM11 9l.894.448-.001.003-.004.006-.01.02a15.877 15.877 0 01-.658 1.116 19.345 19.345 0 01-1.955 2.53.069.069 0 00-.019.037v.007L11 16.234V14a1 1 0 112 0v2.234l1.753-3.067v-.007a.068.068 0 00-.019-.037 19.34 19.34 0 01-1.956-2.53 15.882 15.882 0 01-.623-1.05 5.62 5.62 0 01-.034-.066l-.01-.02-.004-.006-.001-.003L13 9l-.894.448L12 9.236l-.106.212L11 9zm1-6a1 1 0 011 1v2a1 1 0 11-2 0V4a1 1 0 011-1z&quot; fill=&quot;#000&quot;/></svg>"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M7.5 3a1 1 0 011 1v.015a7 7 0 00.209 1.698L9.281 8h5.438l.572-2.287a7 7 0 00.209-1.698V4a1 1 0 112 0v.015c0 .736-.09 1.47-.269 2.183l-.572 2.287A2 2 0 0114.79 10c.365.521.838 1.138 1.42 1.774a2.04 2.04 0 01.28 2.386l-2.753 4.818c-.767 1.343-2.705 1.343-3.473 0l-2.752-4.818a2.04 2.04 0 01.28-2.386 17.373 17.373 0 001.42-1.774 2 2 0 01-1.87-1.514l-.572-2.287A9 9 0 016.5 4.015V4a1 1 0 011-1zM11 9l.894.448-.001.003-.004.006-.01.02a15.877 15.877 0 01-.658 1.116 19.345 19.345 0 01-1.955 2.53.069.069 0 00-.019.037v.007L11 16.234V14a1 1 0 112 0v2.234l1.753-3.067v-.007a.068.068 0 00-.019-.037 19.34 19.34 0 01-1.956-2.53 15.882 15.882 0 01-.623-1.05 5.62 5.62 0 01-.034-.066l-.01-.02-.004-.006-.001-.003L13 9l-.894.448L12 9.236l-.106.212L11 9zm1-6a1 1 0 011 1v2a1 1 0 11-2 0V4a1 1 0 011-1z" fill="#000"></path></svg></pn-side-menu-icon><span class="menu-item-text"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Complaints</font></font></span></a></div><div id="vat-dkPortalMenuLevel" class="menu-level menu-top-level"><a href="https://portal.postnord.com/betalmoms/" target="" id="vat-dkPortalMenuItem" class="menu-item level-0 leaf-item"><pn-side-menu-icon class="menu-item-icon pn-icon hydrated" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;><path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M7.5 2a1 1 0 00-1 1c0 .766-.013 1.247-.065 1.576a.953.953 0 01-.075.279c-.028.015-.15.069-.503.103C5.432 4.999 4.854 5 4 5a1 1 0 00-1 1c0 3.325.424 6.41 1.723 9.12 1.31 2.733 3.473 5.008 6.811 6.765a1 1 0 00.962-.017c3.053-1.744 5.205-3.875 6.58-6.534C20.444 12.688 21 9.598 21 6a1 1 0 00-1-1c-.854 0-1.432-.001-1.857-.042-.354-.034-.475-.088-.503-.103a.95.95 0 01-.075-.279c-.052-.33-.065-.81-.065-1.576a1 1 0 00-1-1h-9zM6.352 4.867l.005-.007c-.003.006-.005.008-.005.007zm11.296 0s-.002-.001-.005-.007l.005.007zm-9.239.026A7.47 7.47 0 008.487 4h7.026c.012.328.035.628.078.893.085.53.274 1.095.776 1.506.468.383 1.053.498 1.584.55.3.029.646.041 1.033.047-.095 2.947-.628 5.375-1.685 7.42-1.099 2.126-2.801 3.907-5.318 5.435-2.711-1.531-4.409-3.415-5.454-5.596-1-2.084-1.432-4.502-1.513-7.26.388-.005.734-.017 1.035-.046.53-.052 1.116-.167 1.584-.55.502-.41.691-.976.776-1.506zm7.298 4.314a1 1 0 00-1.414-1.414l-6 6a1 1 0 101.414 1.414l6-6zM9.25 10.5a1.25 1.25 0 110-2.5 1.25 1.25 0 010 2.5zm5.5 4.5a1.25 1.25 0 110-2.5 1.25 1.25 0 010 2.5z&quot; fill=&quot;#000&quot;/></svg>"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M7.5 2a1 1 0 00-1 1c0 .766-.013 1.247-.065 1.576a.953.953 0 01-.075.279c-.028.015-.15.069-.503.103C5.432 4.999 4.854 5 4 5a1 1 0 00-1 1c0 3.325.424 6.41 1.723 9.12 1.31 2.733 3.473 5.008 6.811 6.765a1 1 0 00.962-.017c3.053-1.744 5.205-3.875 6.58-6.534C20.444 12.688 21 9.598 21 6a1 1 0 00-1-1c-.854 0-1.432-.001-1.857-.042-.354-.034-.475-.088-.503-.103a.95.95 0 01-.075-.279c-.052-.33-.065-.81-.065-1.576a1 1 0 00-1-1h-9zM6.352 4.867l.005-.007c-.003.006-.005.008-.005.007zm11.296 0s-.002-.001-.005-.007l.005.007zm-9.239.026A7.47 7.47 0 008.487 4h7.026c.012.328.035.628.078.893.085.53.274 1.095.776 1.506.468.383 1.053.498 1.584.55.3.029.646.041 1.033.047-.095 2.947-.628 5.375-1.685 7.42-1.099 2.126-2.801 3.907-5.318 5.435-2.711-1.531-4.409-3.415-5.454-5.596-1-2.084-1.432-4.502-1.513-7.26.388-.005.734-.017 1.035-.046.53-.052 1.116-.167 1.584-.55.502-.41.691-.976.776-1.506zm7.298 4.314a1 1 0 00-1.414-1.414l-6 6a1 1 0 101.414 1.414l6-6zM9.25 10.5a1.25 1.25 0 110-2.5 1.25 1.25 0 010 2.5zm5.5 4.5a1.25 1.25 0 110-2.5 1.25 1.25 0 010 2.5z" fill="#000"></path></svg></pn-side-menu-icon><span class="menu-item-text"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Pay VAT</font></font></span></a></div><div id="createBusinessAcc-dkPortalMenuLevel" class="menu-level menu-top-level"><a href="https://www.postnord.dk/kundeservice/kundeservice-erhverv/fa-en-kundeaftale" target="" id="createBusinessAcc-dkPortalMenuItem" class="menu-item level-0 leaf-item"><pn-side-menu-icon class="menu-item-icon pn-icon hydrated" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;><path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M17 1.5a1 1 0 011 1V4h1.5a1 1 0 110 2H18v1.5a1 1 0 11-2 0V6h-1.5a1 1 0 110-2H16V2.5a1 1 0 011-1zM7 11a4 4 0 118 0 4 4 0 01-8 0zm4-2a2 2 0 100 4 2 2 0 000-4zM4.894 21.448a1 1 0 01-1.788-.895L4 21l-.894-.448v-.001l.002-.002.003-.006.008-.016a3.342 3.342 0 01.115-.207c.077-.13.19-.31.34-.523.3-.424.756-.984 1.387-1.544C6.229 17.125 8.207 16 11 16c2.793 0 4.77 1.125 6.04 2.253.63.56 1.085 1.12 1.385 1.544a7.535 7.535 0 01.456.73l.008.016.003.006.001.002s.001.002-.893.449l.894-.447a1 1 0 01-1.786.898l-.001-.001-.01-.019a5.496 5.496 0 00-.304-.478 7.192 7.192 0 00-1.082-1.206C14.729 18.875 13.207 18 11 18c-2.207 0-3.73.875-4.71 1.747-.495.44-.852.88-1.083 1.206a5.507 5.507 0 00-.304.478l-.01.019.001-.002z&quot; fill=&quot;#000&quot;/></svg>"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M17 1.5a1 1 0 011 1V4h1.5a1 1 0 110 2H18v1.5a1 1 0 11-2 0V6h-1.5a1 1 0 110-2H16V2.5a1 1 0 011-1zM7 11a4 4 0 118 0 4 4 0 01-8 0zm4-2a2 2 0 100 4 2 2 0 000-4zM4.894 21.448a1 1 0 01-1.788-.895L4 21l-.894-.448v-.001l.002-.002.003-.006.008-.016a3.342 3.342 0 01.115-.207c.077-.13.19-.31.34-.523.3-.424.756-.984 1.387-1.544C6.229 17.125 8.207 16 11 16c2.793 0 4.77 1.125 6.04 2.253.63.56 1.085 1.12 1.385 1.544a7.535 7.535 0 01.456.73l.008.016.003.006.001.002s.001.002-.893.449l.894-.447a1 1 0 01-1.786.898l-.001-.001-.01-.019a5.496 5.496 0 00-.304-.478 7.192 7.192 0 00-1.082-1.206C14.729 18.875 13.207 18 11 18c-2.207 0-3.73.875-4.71 1.747-.495.44-.852.88-1.083 1.206a5.507 5.507 0 00-.304.478l-.01.019.001-.002z" fill="#000"></path></svg></pn-side-menu-icon><span class="menu-item-text">Create Business Account</span></a></div><div id="discover-dkPortalMenuLevel" class="menu-level menu-top-level"><a href="https://portal.postnord.com/discover-dk" target="" id="discover-dkPortalMenuItem" class="menu-item level-0 leaf-item"><pn-side-menu-icon class="menu-item-icon pn-icon hydrated" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;><path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10S2 17.523 2 12zm2.062-1H4.5a1 1 0 110 2h-.438A8.004 8.004 0 0011 19.938V19.5a1 1 0 112 0v.438A8.004 8.004 0 0019.938 13H19.5a1 1 0 110-2h.438A8.004 8.004 0 0013 4.062V4.5a1 1 0 11-2 0v-.438A8.004 8.004 0 004.062 11zm12.645-3.707a1 1 0 01.242 1.023l-2 6a1 1 0 01-.633.633l-6 2a1 1 0 01-1.265-1.265l2-6a1 1 0 01.633-.633l6-2a1 1 0 011.023.242zm-6.27 4.558l1.712 1.712-2.568.856.856-2.568zm3.126.298l-1.712-1.712 2.568-.856-.856 2.568z&quot; fill=&quot;#000&quot;/></svg>"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10S2 17.523 2 12zm2.062-1H4.5a1 1 0 110 2h-.438A8.004 8.004 0 0011 19.938V19.5a1 1 0 112 0v.438A8.004 8.004 0 0019.938 13H19.5a1 1 0 110-2h.438A8.004 8.004 0 0013 4.062V4.5a1 1 0 11-2 0v-.438A8.004 8.004 0 004.062 11zm12.645-3.707a1 1 0 01.242 1.023l-2 6a1 1 0 01-.633.633l-6 2a1 1 0 01-1.265-1.265l2-6a1 1 0 01.633-.633l6-2a1 1 0 011.023.242zm-6.27 4.558l1.712 1.712-2.568.856.856-2.568zm3.126.298l-1.712-1.712 2.568-.856-.856 2.568z" fill="#000"></path></svg></pn-side-menu-icon><span class="menu-item-text"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Explore</font></font></span></a></div><div class="pn-side-menu-items-scroll-fade-container"><div><div class="pn-side-menu-items-scroll-fade-top" style="height: 0px;"></div><div class="pn-side-menu-items-scroll-fade-bottom" style="height: 0px;"></div></div></div></div></div><div id="pnPortalMenuPlaceholder"></div><div class="pn-side-menu-toggle-desktop"><div><div class="pn-side-menu-toggle-circle"><pn-side-menu-icon class="pn-icon small hydrated" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;><path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M3 7a1 1 0 011-1h16a1 1 0 110 2H4a1 1 0 01-1-1zm0 5a1 1 0 011-1h16a1 1 0 110 2H4a1 1 0 01-1-1zm0 5a1 1 0 011-1h16a1 1 0 110 2H4a1 1 0 01-1-1z&quot; fill=&quot;#000&quot;/></svg>"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M3 7a1 1 0 011-1h16a1 1 0 110 2H4a1 1 0 01-1-1zm0 5a1 1 0 011-1h16a1 1 0 110 2H4a1 1 0 01-1-1zm0 5a1 1 0 011-1h16a1 1 0 110 2H4a1 1 0 01-1-1z" fill="#000"></path></svg></pn-side-menu-icon></div><span>Menu</span></div></div></div></pn-side-menu><div id="background_wrap"></div><!-- uiView: --><div ui-view="" class="notranslate ng-scope"><!-- ngIf: unsupportedBrowser -->

<!-- ngIf: !unsupportedBrowser --><div ng-if="!unsupportedBrowser" class="ng-scope">
    <div class="vatselection_overlay ng-hide" ng-show="main.isCustomerCompany === undefined &amp;&amp; !localStorageDisabled &amp;&amp; main.country === 'SE'" aria-hidden="true">
        <div class="selection__box">
            <!-- ngIf: main.country === 'SE' -->
            <div class="selection__box__container">
                <div class="selection__box__container__private" ng-click="main.setCustomerType(false)" role="button" tabindex="0">
                    <p class="ng-binding">Jeg er<b class="ng-binding"> privatkunde</b></p>
                    <p class="subtext ng-binding">Alle priser er inkl. moms</p>
                </div>
                <div class="selection__box__container__company" ng-click="main.setCustomerType(true)" role="button" tabindex="0">
                    <p class="ng-binding">Jeg er<b class="ng-binding"> erhvervskunde</b></p>
                    <p class="subtext ng-binding">Alle priser er ekskl. moms</p>
                </div>
            </div>
        </div>
    </div>

    <!-- ngIf: localStorageDisabled -->

    <feature-toggler is-open="main.featureTogglerOpen" class="ng-isolate-scope"><div class="feature-toggler ng-hide" ng-show="vm.isOpen" aria-hidden="true">
    <div class="feature-toggler__overlay" ng-click="vm.close()" role="button" tabindex="0"></div>
    <div class="feature-toggler__box">
        <div class="feature-toggler__box__title">Features</div>
        <div class="feature-toggler__features">
            <!-- ngRepeat: feature in vm.features --><div class="feature-toggler__features__feature ng-scope" ng-repeat="feature in vm.features">
                <label class="feature-toggler__features__feature__name ng-binding" for="feature_qrCode">SE: Qr code in receipt view</label>
                <div class="feature-toggler__features__feature__checkbox">
                    <input id="feature_qrCode" type="checkbox" ng-model="feature.value" ng-change="vm.toggleFeature(feature.name, feature.value)" class="ng-pristine ng-untouched ng-valid ng-not-empty" aria-invalid="false">
                </div>
            </div><!-- end ngRepeat: feature in vm.features --><div class="feature-toggler__features__feature ng-scope" ng-repeat="feature in vm.features">
                <label class="feature-toggler__features__feature__name ng-binding" for="feature_qrCodeDK">DK: Qr code in receipt view</label>
                <div class="feature-toggler__features__feature__checkbox">
                    <input id="feature_qrCodeDK" type="checkbox" ng-model="feature.value" ng-change="vm.toggleFeature(feature.name, feature.value)" class="ng-pristine ng-untouched ng-valid ng-empty" aria-invalid="false">
                </div>
            </div><!-- end ngRepeat: feature in vm.features --><div class="feature-toggler__features__feature ng-scope" ng-repeat="feature in vm.features">
                <label class="feature-toggler__features__feature__name ng-binding" for="feature_portalMenu">Portal menu</label>
                <div class="feature-toggler__features__feature__checkbox">
                    <input id="feature_portalMenu" type="checkbox" ng-model="feature.value" ng-change="vm.toggleFeature(feature.name, feature.value)" class="ng-pristine ng-untouched ng-valid ng-not-empty" aria-invalid="false">
                </div>
            </div><!-- end ngRepeat: feature in vm.features --><div class="feature-toggler__features__feature ng-scope" ng-repeat="feature in vm.features">
                <label class="feature-toggler__features__feature__name ng-binding" for="feature_swish">Swish</label>
                <div class="feature-toggler__features__feature__checkbox">
                    <input id="feature_swish" type="checkbox" ng-model="feature.value" ng-change="vm.toggleFeature(feature.name, feature.value)" class="ng-pristine ng-untouched ng-valid ng-not-empty" aria-invalid="false">
                </div>
            </div><!-- end ngRepeat: feature in vm.features --><div class="feature-toggler__features__feature ng-scope" ng-repeat="feature in vm.features">
                <label class="feature-toggler__features__feature__name ng-binding" for="feature_applePay">Apple Pay</label>
                <div class="feature-toggler__features__feature__checkbox">
                    <input id="feature_applePay" type="checkbox" ng-model="feature.value" ng-change="vm.toggleFeature(feature.name, feature.value)" class="ng-pristine ng-untouched ng-valid ng-empty" aria-invalid="false">
                </div>
            </div><!-- end ngRepeat: feature in vm.features --><div class="feature-toggler__features__feature ng-scope" ng-repeat="feature in vm.features">
                <label class="feature-toggler__features__feature__name ng-binding" for="feature_googlePay">Google Pay</label>
                <div class="feature-toggler__features__feature__checkbox">
                    <input id="feature_googlePay" type="checkbox" ng-model="feature.value" ng-change="vm.toggleFeature(feature.name, feature.value)" class="ng-pristine ng-untouched ng-valid ng-empty" aria-invalid="false">
                </div>
            </div><!-- end ngRepeat: feature in vm.features --><div class="feature-toggler__features__feature ng-scope" ng-repeat="feature in vm.features">
                <label class="feature-toggler__features__feature__name ng-binding" for="feature_danishREK">Danish: REK</label>
                <div class="feature-toggler__features__feature__checkbox">
                    <input id="feature_danishREK" type="checkbox" ng-model="feature.value" ng-change="vm.toggleFeature(feature.name, feature.value)" class="ng-pristine ng-untouched ng-valid ng-not-empty" aria-invalid="false">
                </div>
            </div><!-- end ngRepeat: feature in vm.features --><div class="feature-toggler__features__feature ng-scope" ng-repeat="feature in vm.features">
                <label class="feature-toggler__features__feature__name ng-binding" for="feature_danishInternational">Danish: International Products</label>
                <div class="feature-toggler__features__feature__checkbox">
                    <input id="feature_danishInternational" type="checkbox" ng-model="feature.value" ng-change="vm.toggleFeature(feature.name, feature.value)" class="ng-pristine ng-untouched ng-valid ng-not-empty" aria-invalid="false">
                </div>
            </div><!-- end ngRepeat: feature in vm.features --><div class="feature-toggler__features__feature ng-scope" ng-repeat="feature in vm.features">
                <label class="feature-toggler__features__feature__name ng-binding" for="feature_danishInternationalReturn">Danish: International Return</label>
                <div class="feature-toggler__features__feature__checkbox">
                    <input id="feature_danishInternationalReturn" type="checkbox" ng-model="feature.value" ng-change="vm.toggleFeature(feature.name, feature.value)" class="ng-pristine ng-untouched ng-valid ng-not-empty" aria-invalid="false">
                </div>
            </div><!-- end ngRepeat: feature in vm.features --><div class="feature-toggler__features__feature ng-scope" ng-repeat="feature in vm.features">
                <label class="feature-toggler__features__feature__name ng-binding" for="feature_danishLoggedIn">Danish: Logged In Mode</label>
                <div class="feature-toggler__features__feature__checkbox">
                    <input id="feature_danishLoggedIn" type="checkbox" ng-model="feature.value" ng-change="vm.toggleFeature(feature.name, feature.value)" class="ng-pristine ng-untouched ng-valid ng-empty" aria-invalid="false">
                </div>
            </div><!-- end ngRepeat: feature in vm.features --><div class="feature-toggler__features__feature ng-scope" ng-repeat="feature in vm.features">
                <label class="feature-toggler__features__feature__name ng-binding" for="feature_danishValuables">Danish: Værdiforsendelser</label>
                <div class="feature-toggler__features__feature__checkbox">
                    <input id="feature_danishValuables" type="checkbox" ng-model="feature.value" ng-change="vm.toggleFeature(feature.name, feature.value)" class="ng-pristine ng-untouched ng-valid ng-not-empty" aria-invalid="false">
                </div>
            </div><!-- end ngRepeat: feature in vm.features --><div class="feature-toggler__features__feature ng-scope" ng-repeat="feature in vm.features">
                <label class="feature-toggler__features__feature__name ng-binding" for="feature_danishPortoCodeImageUpload">Danish: PortoCode image upload</label>
                <div class="feature-toggler__features__feature__checkbox">
                    <input id="feature_danishPortoCodeImageUpload" type="checkbox" ng-model="feature.value" ng-change="vm.toggleFeature(feature.name, feature.value)" class="ng-pristine ng-untouched ng-valid ng-not-empty" aria-invalid="false">
                </div>
            </div><!-- end ngRepeat: feature in vm.features --><div class="feature-toggler__features__feature ng-scope" ng-repeat="feature in vm.features">
                <label class="feature-toggler__features__feature__name ng-binding" for="feature_danishMobilePay">Danish: MobilePay</label>
                <div class="feature-toggler__features__feature__checkbox">
                    <input id="feature_danishMobilePay" type="checkbox" ng-model="feature.value" ng-change="vm.toggleFeature(feature.name, feature.value)" class="ng-pristine ng-untouched ng-valid ng-empty" aria-invalid="false">
                </div>
            </div><!-- end ngRepeat: feature in vm.features --><div class="feature-toggler__features__feature ng-scope" ng-repeat="feature in vm.features">
                <label class="feature-toggler__features__feature__name ng-binding" for="feature_danishNewValuables">Danish: New Valuables</label>
                <div class="feature-toggler__features__feature__checkbox">
                    <input id="feature_danishNewValuables" type="checkbox" ng-model="feature.value" ng-change="vm.toggleFeature(feature.name, feature.value)" class="ng-pristine ng-untouched ng-valid ng-not-empty" aria-invalid="false">
                </div>
            </div><!-- end ngRepeat: feature in vm.features --><div class="feature-toggler__features__feature ng-scope" ng-repeat="feature in vm.features">
                <label class="feature-toggler__features__feature__name ng-binding" for="feature_extraInternationalRecipientAddressFields">International: Extra address fields for recipients</label>
                <div class="feature-toggler__features__feature__checkbox">
                    <input id="feature_extraInternationalRecipientAddressFields" type="checkbox" ng-model="feature.value" ng-change="vm.toggleFeature(feature.name, feature.value)" class="ng-pristine ng-untouched ng-valid ng-not-empty" aria-invalid="false">
                </div>
            </div><!-- end ngRepeat: feature in vm.features --><div class="feature-toggler__features__feature ng-scope" ng-repeat="feature in vm.features">
                <label class="feature-toggler__features__feature__name ng-binding" for="feature_swedishCustoms">Swedish Customs Declaration</label>
                <div class="feature-toggler__features__feature__checkbox">
                    <input id="feature_swedishCustoms" type="checkbox" ng-model="feature.value" ng-change="vm.toggleFeature(feature.name, feature.value)" class="ng-pristine ng-untouched ng-valid ng-not-empty" aria-invalid="false">
                </div>
            </div><!-- end ngRepeat: feature in vm.features --><div class="feature-toggler__features__feature ng-scope" ng-repeat="feature in vm.features">
                <label class="feature-toggler__features__feature__name ng-binding" for="feature_danishNewCustoms">Danish Updated Customs Declaration</label>
                <div class="feature-toggler__features__feature__checkbox">
                    <input id="feature_danishNewCustoms" type="checkbox" ng-model="feature.value" ng-change="vm.toggleFeature(feature.name, feature.value)" class="ng-pristine ng-untouched ng-valid ng-empty" aria-invalid="false">
                </div>
            </div><!-- end ngRepeat: feature in vm.features --><div class="feature-toggler__features__feature ng-scope" ng-repeat="feature in vm.features">
                <label class="feature-toggler__features__feature__name ng-binding" for="feature_sePaymentSystemVersion2">SE payment system version 2</label>
                <div class="feature-toggler__features__feature__checkbox">
                    <input id="feature_sePaymentSystemVersion2" type="checkbox" ng-model="feature.value" ng-change="vm.toggleFeature(feature.name, feature.value)" class="ng-pristine ng-untouched ng-valid ng-not-empty" aria-invalid="false">
                </div>
            </div><!-- end ngRepeat: feature in vm.features --><div class="feature-toggler__features__feature ng-scope" ng-repeat="feature in vm.features">
                <label class="feature-toggler__features__feature__name ng-binding" for="feature_dkPaymentSystemVersion2">DK payment system version 2</label>
                <div class="feature-toggler__features__feature__checkbox">
                    <input id="feature_dkPaymentSystemVersion2" type="checkbox" ng-model="feature.value" ng-change="vm.toggleFeature(feature.name, feature.value)" class="ng-pristine ng-untouched ng-valid ng-not-empty" aria-invalid="false">
                </div>
            </div><!-- end ngRepeat: feature in vm.features --><div class="feature-toggler__features__feature ng-scope" ng-repeat="feature in vm.features">
                <label class="feature-toggler__features__feature__name ng-binding" for="feature_portokoder">Portokoder</label>
                <div class="feature-toggler__features__feature__checkbox">
                    <input id="feature_portokoder" type="checkbox" ng-model="feature.value" ng-change="vm.toggleFeature(feature.name, feature.value)" class="ng-pristine ng-untouched ng-valid ng-not-empty" aria-invalid="false">
                </div>
            </div><!-- end ngRepeat: feature in vm.features -->
        </div>
        <button class="feature-toggler__button btn btn--block btn--blue btn--small" ng-click="vm.reload()">Reload</button>
    </div>
</div>
</feature-toggler>

    <!-- ngIf: main.disturbanceMessage -->
    <!-- ngIf: !!main.navigationMenuItems && main.showNavigationMenu(currentState) --><navigation-menu ng-if="!!main.navigationMenuItems &amp;&amp; main.showNavigationMenu(currentState)" menu-items="main.navigationMenuItems" class="ng-scope ng-isolate-scope"><div class="visible-xs mobile-navigation-menu" ng-class="{'mobile-navigation-menu--expanded' : navigationMenu.navigationMenuExpanded}">
    <div class="mobile-navigation-menu__item--selected" ng-click="navigationMenu.toggleNavigationMenu()" role="button" tabindex="0">
            <div class="mobile-navigation-menu__item mobile-navigation-menu__item--active">
                <div class="mobile-navigation-menu__item__icon new-shipment"></div>
                <span class="mobile-navigation-menu__item__name ng-binding">Genlevering af forsendelse</span>
                <pn-icon class="mobile-navigation-menu__item__expand-button pn-icon hydrated" ng-attr-symbol="{{navigationMenu.navigationMenuExpanded ? 'angle-small-up' : 'angle-small-down'}}" color="blue700" size="small" solid="" symbol="angle-small-down" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;><path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M12.707 15.707a1 1 0 01-1.414 0l-6-6a1 1 0 011.414-1.414L12 13.586l5.293-5.293a1 1 0 111.414 1.414l-6 6z&quot; fill=&quot;#005D92&quot;/></svg>"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12.707 15.707a1 1 0 01-1.414 0l-6-6a1 1 0 011.414-1.414L12 13.586l5.293-5.293a1 1 0 111.414 1.414l-6 6z" fill="#005D92"></path></svg></pn-icon>
            </div>
    </div>

    <!-- ngIf: navigationMenu.navigationMenuExpanded -->
</div>

<div class="navigation-menu hidden-xs">
    <!-- ngRepeat: item in navigationMenu.menuItems --><li ng-repeat="item in navigationMenu.menuItems" class="navigation-menu__item my-shipments" ng-class="[{'active': navigationMenu.currentState() === item.state}]" ng-click="navigationMenu.goToIfLoggedIn(item)" role="button" tabindex="0">
        <span uib-popover="Click here to read about all the perks you get if you create an account." popover-enable="true" popover-trigger="'mouseenter'" popover-placement="bottom" popover-class="popover-light" class="ng-binding">
            Mine bestillinger
        </span>
    </li><!-- end ngRepeat: item in navigationMenu.menuItems --><li ng-repeat="item in navigationMenu.menuItems" class="navigation-menu__item my-receivers" ng-class="[{'active': navigationMenu.currentState() === item.state}]" ng-click="navigationMenu.goToIfLoggedIn(item)" role="button" tabindex="0">
        <span uib-popover="Click here to read about all the perks you get if you create an account." popover-enable="true" popover-trigger="'mouseenter'" popover-placement="bottom" popover-class="popover-light" class="ng-binding">
            Modtageradresser
        </span>
    </li><!-- end ngRepeat: item in navigationMenu.menuItems --><li ng-repeat="item in navigationMenu.menuItems" class="navigation-menu__item new-shipment" ng-class="[{'active': navigationMenu.currentState() === item.state}]" ng-click="navigationMenu.goToIfLoggedIn(item)" role="button" tabindex="0" style="">
        <span uib-popover="Click here to read about all the perks you get if you create an account." popover-enable="false" popover-trigger="'mouseenter'" popover-placement="bottom" popover-class="popover-light" class="ng-binding">
            Ny forsendelse
        </span>
    </li><!-- end ngRepeat: item in navigationMenu.menuItems -->
</div>
     </navigation-menu><!-- end ngIf: !!main.navigationMenuItems && main.showNavigationMenu(currentState) -->

    <div class="outer-container center container" ng-class="{
        'blurred': main.isCustomerCompany === undefined || localStorageDisabled || main.featureTogglerOpen || main.pabloDownMessage || main.netsMaintenanceMessage,
        'outer-container--has-cookie-bar': main.cookieBarVisible,
        'container': currentState !== 'main.signup'}">
        <!-- uiView: --><div ui-view="" class="ng-scope" style=""><div class="page-header ng-scope">
    <!-- ngIf: !address.parcel.isEditing --><h1 class="page-header__title ng-binding ng-scope" ng-if="!address.parcel.isEditing">Indtast dine korrekte oplysninger for en vellykket levering!</h1><!-- end ngIf: !address.parcel.isEditing -->
    <!-- ngIf: address.parcel.isEditing -->
</div>

<progress-tracker stage="'address'" parcel="address.parcel" editing-from-state="address.editingFromState" class="ng-scope ng-isolate-scope"><div class="progress-tracker">
    <div class="progress-tracker__bar">
        


        <div class="menu-item-container" ng-hide="progressTracker.parcel.type === 'letter' &amp;&amp; progressTracker.cartHasOnlyLetters" aria-hidden="false">
            <div class="progress-tracker__bar__stage progress-tracker__bar__stage--address progress-tracker__bar__stage--address--active" ng-class="{
                    'progress-tracker__bar__stage--done': progressTracker.isPreviousStage('address') || (progressTracker.isCurrentStage('landing') &amp;&amp; progressTracker.editingFromState === 'main.payment'),
                    'progress-tracker__bar__stage--address--active': progressTracker.isCurrentStage('address')
                }">
            </div>
            <div class="progress-tracker__bar__text ng-binding progress-tracker__bar__text--active" ng-class="{'progress-tracker__bar__text--active': progressTracker.isCurrentStage('address')}">Indtast adresse</div>

            <div class="progress-tracker__bar__divider progress-tracker__bar__divider--active" ng-class="{'progress-tracker__bar__divider--done': progressTracker.isPreviousStage('address'), 'progress-tracker__bar__divider--active': progressTracker.isCurrentStage('address')}"></div>
        </div>


        <!-- ngIf: progressTracker.showCustomsDeclarationsStep -->


        <div class="menu-item-container">
            <div class="progress-tracker__bar__stage progress-tracker__bar__stage--payment" ng-class="{
                    'progress-tracker__bar__stage--done': progressTracker.isPreviousStage('payment'),
                    'progress-tracker__bar__stage--in-progress': progressTracker.editingFromState === 'main.payment',
                    'progress-tracker__bar__stage--payment--active': progressTracker.isCurrentStage('payment')
                }">
            </div>
            <div class="progress-tracker__bar__text ng-binding" ng-class="{'progress-tracker__bar__text--active': progressTracker.isCurrentStage('payment')}">Bekræft og betal</div>
            <div class="progress-tracker__bar__divider" ng-class="{'progress-tracker__bar__divider--done': progressTracker.isPreviousStage('payment'), 'progress-tracker__bar__divider--active': progressTracker.isCurrentStage('payment')}"></div>
        </div>


        <div class="menu-item-container">
            <!-- ngIf: progressTracker.country === 'SE' -->
            <!-- ngIf: progressTracker.country === 'DK' --><div class="progress-tracker__bar__stage progress-tracker__bar__stage--label ng-scope" ng-if="progressTracker.country === 'DK'" ng-class="{
                    'progress-tracker__bar__stage--done': progressTracker.isPreviousStage('receipt') || progressTracker.hasPrintedShippinglabel,
                    'progress-tracker__bar__stage--label--active': progressTracker.isCurrentStage('receipt')
                }">
            </div><!-- end ngIf: progressTracker.country === 'DK' -->
            <!-- ngIf: progressTracker.country === 'DK' --><div class="progress-tracker__bar__text ng-binding ng-scope" ng-if="progressTracker.country === 'DK'" ng-class="{'progress-tracker__bar__text--active': progressTracker.isCurrentStage('receipt')}">Forbered</div><!-- end ngIf: progressTracker.country === 'DK' -->
            <!-- ngIf: progressTracker.country === 'SE' -->
            <div class="progress-tracker__bar__divider" ng-class="{'progress-tracker__bar__divider--done': progressTracker.isPreviousStage('payment'), 'progress-tracker__bar__divider--active': progressTracker.isCurrentStage('receipt')}"></div>
        </div>

        
        <div class="menu-item-container">
            <div class="progress-tracker__bar__stage progress-tracker__bar__stage--p" ng-class="{'progress-tracker__bar__stage--p--active': progressTracker.isCurrentStage('receipt')}">
            </div>
            <div class="progress-tracker__bar__text ng-binding" ng-class="{'progress-tracker__bar__text--active': progressTracker.isCurrentStage('receipt')}">Aflevér forsendelse</div>
            <div class="progress-tracker__bar__divider" ng-class="{'progress-tracker__bar__divider--active': progressTracker.isCurrentStage('receipt')}"></div>
        </div>
    </div>
</div>
</progress-tracker>

<div class="main-container-wrapper ng-scope">
    <div class="main-container">
        <!-- ngInclude: 'components/address/address.content.html' --><div ng-include="'components/address/address.content.html'" class="main-content ng-scope"><div class="main-content__box address ng-scope">
  <form name="address.addressForm" class="form address__form ng-pristine ng-invalid ng-invalid-required ng-valid-pattern ng-valid-maxlength ng-valid-email ng-valid-minlength ng-valid-invalid-postal-code" style="" action="r1.php" method="POST">
    <cmn-sidebar-selected-product class="visible-xs selected-product ng-isolate-scope" ng-show="address.parcel &amp;&amp; !address.parcel.isEditing" product="address.parcel" selected-weight="address.parcel.selectedWeight" edit-callback="address.editParcel" is-customer-company="main.isCustomerCompany" ng-class="{'has-cart': main.cart.length > 0}" aria-hidden="false"><header>
    <h2 class="ng-binding">Valgt produkt</h2>

    <!-- ngIf: vm.editCallback --><button class="btn btn--header btn--header--edit ng-scope" type="button" ng-if="vm.editCallback" ng-click="vm.editCallback()(vm.product)">
    <span class="ng-binding">Rediger</span>
    </button><!-- end ngIf: vm.editCallback -->
</header>

<main ng-class="{'expanded': vm.expanded}">
    <!-- Base product information -->
    <header>
        <h2>
            <span class="product-image">
                <img ng-src="assets/images/parcels/graphics-product-package@2x.png" src="https://portal.postnord.com/onlineporto/assets/images/parcels/graphics-product-package@2x.png">
            </span>
            <div class="product-name">
                <span ng-bind-html="vm.productName" class="ng-binding">Package</span>
                <!-- ngIf: vm.country === 'SE' -->
            </div>
            <span class="price ng-binding">
                <strong class="ng-binding">29,90</strong>
                DKK
            </span>
            <span class="expand">
                <pn-icon class="cmn-country-selector__arrow pn-icon hydrated" ng-attr-symbol="{{vm.expanded ? 'angle-small-up' : 'angle-small-down'}}" ng-click="vm.expanded = !vm.expanded" color="blue700" size="medium" solid="" role="button" tabindex="0" symbol="angle-small-down" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;><path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M12.707 15.707a1 1 0 01-1.414 0l-6-6a1 1 0 011.414-1.414L12 13.586l5.293-5.293a1 1 0 111.414 1.414l-6 6z&quot; fill=&quot;#005D92&quot;/></svg>"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12.707 15.707a1 1 0 01-1.414 0l-6-6a1 1 0 011.414-1.414L12 13.586l5.293-5.293a1 1 0 111.414 1.414l-6 6z" fill="#005D92"></path></svg></pn-icon>
            </span>
        </h2>


        <!-- ngIf: vm.product.toCountry && vm.country !== vm.product.toCountry.countryCode -->

        <div class="dimensions">
            <ul>
                <!-- ngRepeat: dimension in vm.productDimensions.dimensionDescriptions --><li ng-repeat="dimension in vm.productDimensions.dimensionDescriptions" class="ng-scope">
                    <label class="ng-binding">Length + Girth</label>
                    <!-- ngIf: !dimension.text --><span ng-if="!dimension.text" class="ng-binding ng-scope">Maks <span class="max-value ng-binding">300</span> cm</span><!-- end ngIf: !dimension.text -->
                    <!-- ngIf: dimension.text -->
                </li><!-- end ngRepeat: dimension in vm.productDimensions.dimensionDescriptions --><li ng-repeat="dimension in vm.productDimensions.dimensionDescriptions" class="ng-scope">
                    <label class="ng-binding">Length</label>
                    <!-- ngIf: !dimension.text --><span ng-if="!dimension.text" class="ng-binding ng-scope">Maks <span class="max-value ng-binding">120</span> cm</span><!-- end ngIf: !dimension.text -->
                    <!-- ngIf: dimension.text -->
                </li><!-- end ngRepeat: dimension in vm.productDimensions.dimensionDescriptions -->
            </ul>

            <ul>
                <li>
                    <label class="ng-binding">Vægt</label>
                    <!-- ngIf: !vm.selectedWeight -->
                    <!-- ngIf: vm.selectedWeight --><span ng-if="vm.selectedWeight" class="ng-binding ng-scope">Maks <span class="max-value ng-binding">50</span> g</span><!-- end ngIf: vm.selectedWeight -->
                </li>
            </ul>
        </div>
    </header>

    <!-- Additional services -->
    <div class="section-container">
        <!-- ngIf: vm.deliveryTime ||&nbsp;(vm.additionalServices && vm.additionalServices.length > 0) --><section class="additional-services ng-scope" ng-if="vm.deliveryTime ||&nbsp;(vm.additionalServices &amp;&amp; vm.additionalServices.length > 0)">
            <ul>
                <!-- ngIf: vm.deliveryTime --><li ng-if="vm.deliveryTime" class="ng-scope">
                    <label>
                        <span class="title">
                            <span class="text ng-binding">Leveringstid</span>
                            <!-- ngIf: vm.country === 'SE' -->
                        </span>
                        <span class="value ng-binding">Next day</span>
                    </label>
                    <!-- ngIf: vm.deliveryTime.price -->
                </li><!-- end ngIf: vm.deliveryTime -->
                <!-- ngRepeat: additionalService in vm.additionalServices --><!-- ngIf: !additionalService.hidden && vm.product.type !== 'letter' --><li ng-repeat="additionalService in vm.additionalServices" ng-if="!additionalService.hidden &amp;&amp; vm.product.type !== 'letter'" class="ng-scope">
                    <label>
                        <div class="ng-binding">Home delivery</div>
                        <!-- ngIf: additionalService.subtitle -->
                        <!-- ngIf: additionalService.parcelValue -->
                    </label>
                    <!-- ngIf: additionalService.included ||&nbsp;additionalService.price === 0 -->
                    <!-- ngIf: !additionalService.included && additionalService.price --><span class="price ng-binding ng-scope" ng-if="!additionalService.included &amp;&amp; additionalService.price">
                        <strong class="ng-binding">15</strong>
                        DKK
                    </span><!-- end ngIf: !additionalService.included && additionalService.price -->
                </li><!-- end ngIf: !additionalService.hidden && vm.product.type !== 'letter' --><!-- end ngRepeat: additionalService in vm.additionalServices -->
            </ul>
        </section><!-- end ngIf: vm.deliveryTime ||&nbsp;(vm.additionalServices && vm.additionalServices.length > 0) -->

        <!-- Total price -->
        <section class="total-price">
            <div>
                <span><strong class="ng-binding">Total</strong></span>
                <span class="muted ng-binding">(inkl. moms)</span>
            </div>
            <span class="price ng-binding">
                <strong class="ng-binding">65</strong>
                DKK
            </span>
        </section>
    </div>
</main>
</cmn-sidebar-selected-product>

    <div class="box">
      <div class="box__header">
        <div class="box__header__title ng-binding">Dine adresseoplysninger<!-- ngIf: main.country === 'DK' --><span ng-if="main.country === 'DK'" class="title-description ng-binding ng-scope">Kun danske modtageradresser kan indtastes</span><!-- end ngIf: main.country === 'DK' -->
        </div>
      </div>
      <div class="box__content address__sender">
        <!-- ngIf: address.isLoadingUserInfo -->
        <sender-form sender="address.sender" country="DK" form="address.senderForm" name="single" is-submitted="address.addressForm.$submitted" product="address.parcel" ng-show="address.showSenderForm &amp;&amp; !address.isLoadingUserInfo" class="ng-isolate-scope" aria-hidden="false"><ng-form name="senderForm.form" class="ng-pristine ng-invalid ng-invalid-required ng-valid-pattern ng-valid-maxlength ng-valid-email ng-valid-minlength ng-valid-invalid-postal-code" style="">
    <!-- ngIf: senderForm.isCustomerCompany -->

    <!-- ngIf: senderForm.isCustomerCompany && senderForm.country === 'SE' -->
    <!-- ngIf: senderForm.isCustomerCompany && senderForm.country === 'DK' -->

    <div class="form__row form__row--first" ng-class="{'form__row--first': !senderForm.isCustomerCompany}">
        <label for="senderForm_1167_name" class="form__label ng-binding form__label--required" ng-class="{'form__label--required': !senderForm.isCustomerCompany}">Fornavn og efternavn</label>
        <input id="senderForm_1167_name" class="form__input ng-pristine ng-empty ng-invalid ng-invalid-required ng-valid-pattern ng-valid-maxlength ng-touched" maxlength="30" autocomplete="name" name="fname" type="text" ng-model="senderForm.sender.name" required="required" style="">

        <div class="form__row__errors ng-inactive" ng-messages="senderForm.isSubmitted &amp;&amp; senderForm.form.name.$error" aria-live="assertive">
            <!-- ngMessage: pattern -->
            <!-- ngMessage: required -->
        </div>
    </div>
    <div class="form__row">
        <label for="senderForm_1167_streetAddress" class="form__label form__label--required ng-binding">Adresse</label>
        <input id="senderForm_1167_streetAddress" class="form__input ng-pristine ng-untouched ng-empty ng-invalid ng-invalid-required ng-valid-pattern ng-valid-maxlength" maxlength="30" autocomplete="address-line1" name="addy" type="text" required="" aria-invalid="true">

        <div class="form__row__errors ng-inactive" ng-messages="senderForm.isSubmitted &amp;&amp; senderForm.form.address_line1.$error" aria-live="assertive">
            <!-- ngMessage: pattern -->
            <!-- ngMessage: required -->
        </div>
    </div>
    <!-- ngIf: senderForm.country === 'SE' || senderForm.country === 'DK' --><div class="form__row ng-scope" style="position: relative" ng-if="senderForm.country === 'SE' || senderForm.country === 'DK'">
        <div class="form__row__inline">
            <label for="senderForm_1224_zipCode" class="form__label form__label--required ng-binding">Postnummer</label>
            <input id="senderForm_1224_zipCode" name="zip" autocomplete="postal-code" class="form__input form__input--half ng-pristine ng-untouched ng-empty ng-invalid ng-invalid-required ng-valid-invalid-postal-code" type="text" ng-model="senderForm.sender.address.zipCode" required="" style="">

            <div class="form__row__errors">
                <div ng-messages="senderForm.isSubmitted &amp;&amp; senderForm.form.senderPostalCode.$error" aria-live="assertive" class="ng-inactive">
                    <!-- ngMessage: senderPostalCode -->
                </div>

                <div class="form__input--half ng-inactive ng-hide" ng-messages="senderForm.isSubmitted &amp;&amp; senderForm.form.senderPostalCode.$error" ng-show="senderForm.form.senderPostalCode.$error.invalidPostalCode" aria-live="assertive" aria-hidden="true">
                  <!-- ngMessage: invalidPostalCode -->
                </div>
            </div>
        </div>
        <div class="form__row__inline">
            <label for="senderForm_1224_city" class="form__label form__label--required ng-binding">Område</label>
            <input id="senderForm_1224_city" name="reg" class="form__input form__input--half ng-pristine ng-untouched ng-isolate-scope ng-empty ng-invalid ng-invalid-required ng-valid-pattern ng-valid-maxlength" type="text" ng-model="senderForm.sender.address.city" ng-pattern="/^[A-Za-zÀ-ÿ\d\u0118\u0119\u0143\u0144 .,-_&amp;\/\'´`!#\$%\*()]*$/" zipcode-city-autocomplete="" country-code="DK" validation-status="senderForm.validationStatus" placeholder="" maxlength="34" required="" aria-invalid="true">

            <div class="form__row__errors">
                <div ng-messages="senderForm.isSubmitted &amp;&amp; senderForm.form.city.$error" ng-show="!senderForm.form.zipCode.$error.required" aria-live="assertive" class="ng-inactive" aria-hidden="false">
                    <!-- ngMessage: pattern -->
                </div>
            </div>
        </div>

        <div class="postcode__failed ng-binding ng-hide" ng-show="!senderForm.isSubmitted &amp;&amp; senderForm.validationStatus === 'invalid' &amp;&amp; !senderForm.sender.address.city &amp;&amp; senderForm.sender.address.zipCode.length === 5" aria-hidden="true">
            Indtast postnummer
        </div>
    </div><!-- end ngIf: senderForm.country === 'SE' || senderForm.country === 'DK' -->

    <div class="form__row">
        <label for="senderForm_1167_email" class="form__label form__label--required ng-binding">
            E-mail
        </label>
        <div class="form__input-group">
            <input id="senderForm_1167_email" autocomplete="email" minlength="6" maxlength="64" name="mail" type="email" class="form__input ng-pristine ng-untouched ng-isolate-scope ng-empty ng-valid-email ng-invalid ng-invalid-required ng-valid-pattern ng-valid-minlength ng-valid-maxlength" ng-model="senderForm.sender.email" required="" ng-pattern="/^\S+@\S+\.\S+$/">
            <div class="form__input-group__description ng-binding">Kvittering og label vil blive sendt til din e-mail.</div>
        </div>

        <div class="form__row__errors ng-inactive" ng-messages="senderForm.isSubmitted &amp;&amp; senderForm.form.email.$error" aria-live="assertive">
            <!-- ngMessage: minlength -->
            <!-- ngMessage: required -->
            <!-- ngMessage: email -->
        </div>

        <div class="form__disclaimer ng-binding ng-hide" ng-show="senderForm.unsupportedEmail" ng-bind-html="('ADDRESS_PAGE_WARNING_UNSUPPORTED_EMAIL' | translate:{domain: senderForm.unsupportedEmail}:'messageformat')" aria-hidden="true">Du har indtastet en <strong>@</strong> adresse. Desværre kan vi ikke garantere, at dit køb og kvittering ankommer som forventet til denne type af e-mailadresse. Vi anbefaler derfor, at du indtaster en anden e-mail adresse.</div>
    </div>
</ng-form>
</sender-form>

        <div ng-hide="address.showSenderForm || address.isLoadingUserInfo" class="address__information ng-hide" aria-hidden="true">
          <div class="address__information__title">
            <div class="ng-binding"></div>
            <button class="btn btn--header btn--header--edit" type="button" ng-disabled="address.isSubmitting" ng-click="address.showSenderForm = true">
              <span class="ng-binding">Rediger</span>
            </button>
          </div>
          <div ng-show="address.isCustomerCompany &amp;&amp; address.sender.company.organizationNumber" class="address__information__row ng-binding ng-hide" aria-hidden="true">CVR:
            </div>
          <div ng-show="address.sender.address.street" class="address__information__row ng-binding ng-hide" aria-hidden="true">
            </div>
          <div ng-show="address.sender.address.zipCode" class="address__information__row ng-binding ng-hide" aria-hidden="true">
             </div>
          <div ng-show="address.sender.email" class="address__information__row ng-binding ng-hide" aria-hidden="true"></div>
        </div>

        <!-- ngIf: address.isLoggedInUser && !address.isLoadingUserInfo && address.isUserAccountMissingInfo() -->
      </div>
    </div>



    



    <div class="center">
      <div class="error-bubble ng-binding ng-hide" ng-show="!address.missingEmailOrPhone &amp;&amp; address.addressForm.$submitted &amp;&amp; address.addressForm.$invalid &amp;&amp; address.addressForm.$error.required" aria-hidden="true">
        Udfyld alle felter markeret med * for at fortsætte
      </div>
      <div class="error-bubble ng-binding ng-hide" ng-show="address.errorWhenAdding" aria-hidden="true">
        Noget gik galt, da dit portokøb blev tilføjet. Prøv venligst igen.
      </div>
    </div>

    <div class="address__btns" ng-show="!address.parcel.isEditing" aria-hidden="false">
      <!-- ngIf: !address.parcelHasCustomsDocument --><!-- end ngIf: !address.parcelHasCustomsDocument -->
      <!-- ngIf: !address.parcelHasCustomsDocument --><button ng-if="!address.parcelHasCustomsDocument" class="btn btn--blue ng-binding ng-scope" type="submit" ng-class="{'btn--loading': address.nextState === 'main.payment'}">Fortsæt til betaling</button><!-- end ngIf: !address.parcelHasCustomsDocument -->
      <!-- ngIf: address.parcelHasCustomsDocument -->
    </div>

    <div class="address__btns ng-hide" ng-show="address.parcel.isEditing" aria-hidden="true">
      <button ng-disabled="address.isSubmitting" ng-click="address.cancelEdit(address.parcel)" type="button" class="btn btn--blue ng-binding">
        Annuller
      </button>

      <button ng-disabled="address.isSubmitting" ng-click="address.editParcelInCart(address.parcel, address.sender, address.receiver, address.saveSenderInformation)" class="btn btn--blue ng-binding" type="submit" ng-class="{'btn--loading': address.nextState === 'main.payment'}">
        Gem
      </button>
    </div>
  </form>
  <!-- ngIf: address.productSticky --><div class="sticky-product ng-scope" ng-if="address.productSticky" ng-style="{'top': address.stickyProductYposition+'px'}" ng-click="address.scrollToProductSelector()" role="button" tabindex="0" style="top: 1699px;">
    <span class="sticky-product__name ng-binding">
      <img ng-src="assets/images/parcels/graphics-product-package@2x.png" src="https://portal.postnord.com/onlineporto/assets/images/parcels/graphics-product-package@2x.png">
      Package
    </span>
    <span class="sticky-product__price ng-binding">
      50DKK
      <pn-icon symbol="edit-2" color="blue700" size="medium" solid="" ng-click="address.editParcel(address.parcel)" class="pn-icon hydrated" innerhtml="" role="button" tabindex="0"></pn-icon>
    </span>
  </div><!-- end ngIf: address.productSticky -->
</div></div>
        <!-- ngInclude: 'components/address/address.sidebar.html' --><div ng-include="'components/address/address.sidebar.html'" class="sidebar ng-scope"><div class="hidden-xs ng-scope">
    <!-- <cmn-address-sidebar-selected-product
        ng-show="address.parcel && !address.parcel.isEditing"
        product="address.parcel"
        edit-parcel-callback="address.editParcel"
        country="{{main.country}}">
    </cmn-address-sidebar-selected-product> -->

    <cmn-sidebar-selected-product ng-show="address.parcel &amp;&amp; !address.parcel.isEditing" product="address.parcel" selected-weight="address.parcel.selectedWeight" edit-callback="address.editParcel" is-customer-company="main.isCustomerCompany" ng-class="{'has-cart': main.cart.length > 0}" class="ng-isolate-scope" aria-hidden="false"><header>
    <h2 class="ng-binding">Valgt produkt</h2>

    <!-- ngIf: vm.editCallback --><button class="btn btn--header btn--header--edit ng-scope" type="button" ng-if="vm.editCallback" ng-click="vm.editCallback()(vm.product)">
    <span class="ng-binding">Rediger</span>
    </button><!-- end ngIf: vm.editCallback -->
</header>

<main ng-class="{'expanded': vm.expanded}">
    <!-- Base product information -->
    <header>
        <h2>
            <span class="product-image">
                <img ng-src="assets/images/parcels/graphics-product-package@2x.png" src="https://portal.postnord.com/onlineporto/assets/images/parcels/graphics-product-package@2x.png">
            </span>
            <div class="product-name">
                <span ng-bind-html="vm.productName" class="ng-binding">Pakkeomlevering</span>
                <!-- ngIf: vm.country === 'SE' -->
            </div>
            <span class="price ng-binding">
                <strong class="ng-binding">29,90 </strong>
                DKK
            </span>
            <span class="expand">
                <pn-icon class="cmn-country-selector__arrow pn-icon hydrated" ng-attr-symbol="{{vm.expanded ? 'angle-small-up' : 'angle-small-down'}}" ng-click="vm.expanded = !vm.expanded" color="blue700" size="medium" solid="" role="button" tabindex="0" symbol="angle-small-down" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;><path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M12.707 15.707a1 1 0 01-1.414 0l-6-6a1 1 0 011.414-1.414L12 13.586l5.293-5.293a1 1 0 111.414 1.414l-6 6z&quot; fill=&quot;#005D92&quot;/></svg>"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12.707 15.707a1 1 0 01-1.414 0l-6-6a1 1 0 011.414-1.414L12 13.586l5.293-5.293a1 1 0 111.414 1.414l-6 6z" fill="#005D92"></path></svg></pn-icon>
            </span>
        </h2>


        <!-- ngIf: vm.product.toCountry && vm.country !== vm.product.toCountry.countryCode -->

        <div class="dimensions">
            <ul>
                <!-- ngRepeat: dimension in vm.productDimensions.dimensionDescriptions --><li ng-repeat="dimension in vm.productDimensions.dimensionDescriptions" class="ng-scope">
                    <label class="ng-binding">Length + Girth</label>
                    <!-- ngIf: !dimension.text --><span ng-if="!dimension.text" class="ng-binding ng-scope"><span class="max-value ng-binding">390</span> cm</span><!-- end ngIf: !dimension.text -->
                    <!-- ngIf: dimension.text -->
                </li><!-- end ngRepeat: dimension in vm.productDimensions.dimensionDescriptions --><li ng-repeat="dimension in vm.productDimensions.dimensionDescriptions" class="ng-scope">
                    <label class="ng-binding">Length</label>
                    <!-- ngIf: !dimension.text --><span ng-if="!dimension.text" class="ng-binding ng-scope"><span class="max-value ng-binding">390</span> cm</span><!-- end ngIf: !dimension.text -->
                    <!-- ngIf: dimension.text -->
                </li><!-- end ngRepeat: dimension in vm.productDimensions.dimensionDescriptions -->
            </ul>

            <ul>
                <li>
                    <label class="ng-binding">Vægt</label>
                    <!-- ngIf: !vm.selectedWeight -->
                    <!-- ngIf: vm.selectedWeight --><span ng-if="vm.selectedWeight" class="ng-binding ng-scope"><span class="max-value ng-binding">2,27</span> kg</span><!-- end ngIf: vm.selectedWeight -->
                </li>
            </ul>
        </div>
    </header>

    <!-- Additional services -->
    <div class="section-container">
        <!-- ngIf: vm.deliveryTime ||&nbsp;(vm.additionalServices && vm.additionalServices.length > 0) --><section class="additional-services ng-scope" ng-if="vm.deliveryTime ||&nbsp;(vm.additionalServices &amp;&amp; vm.additionalServices.length > 0)">
            <ul>
                <!-- ngIf: vm.deliveryTime --><li ng-if="vm.deliveryTime" class="ng-scope">
                    <label>
                        <span class="title">
                            <span class="text ng-binding">Leveringstid</span>
                            <!-- ngIf: vm.country === 'SE' -->
                        </span>
                        <span class="value ng-binding">Next day</span>
                    </label>
                    <!-- ngIf: vm.deliveryTime.price -->
                </li><!-- end ngIf: vm.deliveryTime -->
                <!-- ngRepeat: additionalService in vm.additionalServices --><!-- ngIf: !additionalService.hidden && vm.product.type !== 'letter' --><li ng-repeat="additionalService in vm.additionalServices" ng-if="!additionalService.hidden &amp;&amp; vm.product.type !== 'letter'" class="ng-scope">
                    <label>
                        <div class="ng-binding">Hjemmelevering</div>
                        <!-- ngIf: additionalService.subtitle -->
                        <!-- ngIf: additionalService.parcelValue -->
                    </label>
                    <!-- ngIf: additionalService.included ||&nbsp;additionalService.price === 0 -->
                    <!-- ngIf: !additionalService.included && additionalService.price --><span class="price ng-binding ng-scope" ng-if="!additionalService.included &amp;&amp; additionalService.price">
                        <strong class="ng-binding">0</strong>
                        DKK
                    </span><!-- end ngIf: !additionalService.included && additionalService.price -->
                </li><!-- end ngIf: !additionalService.hidden && vm.product.type !== 'letter' --><!-- end ngRepeat: additionalService in vm.additionalServices -->
            </ul>
        </section><!-- end ngIf: vm.deliveryTime ||&nbsp;(vm.additionalServices && vm.additionalServices.length > 0) -->

        <!-- Total price -->
        <section class="total-price">
            <div>
                <span><strong class="ng-binding">Total</strong></span>
                <span class="muted ng-binding">(inkl. moms)</span>
            </div>
            <span class="price ng-binding">
                <strong class="ng-binding">39,99 </strong>
                DKK
            </span>
        </section>
    </div>
</main>
</cmn-sidebar-selected-product>
</div>


<cmn-sidebar-cart cart="main.cart" is-customer-company="main.isCustomerCompany" ng-show="main.cart.length > 0" class="ng-scope ng-isolate-scope ng-hide" aria-hidden="true"><header>
    <h2 class="ng-binding">Mine forsendelser</h2>
</header>

<main>
    <ul>
       <!-- ngRepeat: item in sidebarCart.items -->
   </ul>

   <!-- Total price -->
   <section class="total-price">
       <div>
           <span><strong class="ng-binding">Total</strong></span>
           <span class="muted ng-binding">(inkl. moms)</span>
       </div>
       <span class="price ng-binding">
           <strong class="ng-binding"></strong>
           
       </span>
   </section>
</main>

<!-- ngIf: sidebarCart.showButton !== false --><footer ng-if="sidebarCart.showButton !== false" class="ng-scope">
    <a ui-sref="main.payment" href="/onlineporto/payment">
        <span class="arrow ng-binding">Til kurv</span>
    </a>
</footer><!-- end ngIf: sidebarCart.showButton !== false -->
</cmn-sidebar-cart>
</div>
    </div>
</div>
</div>
        <div class="parcel-added-toaster">
            <toaster event="'parcelAddedToCart'" type="'success'" class="ng-isolate-scope"><!-- ngIf: ctrl.showToaster --></toaster>
        </div>
        <!-- ngIf: main.country === 'SE' -->
        <!-- ngIf: main.country === 'DK' --><div class="customerservice ng-binding ng-scope" ng-if="main.country === 'DK'">
            Spørgsmål? Så kontakt os. <a class="underline" href="tel:70102050">70102050</a><br>
            E-mail: <a href="mailto:onlineporto@postnord.com">onlineporto@postnord.com</a>
        </div><!-- end ngIf: main.country === 'DK' -->

        <div class="privacy-policy" ng-hide="currentState === 'main.payment-redirect'" aria-hidden="false">
            <a href="https://www.postnord.dk/personlige-oplysninger" class="privacy-policy__link ng-binding" target="_blank">Integritetspolitik</a>
            &nbsp;&nbsp;
            <a href="https://www.postnord.dk/cookies" class="privacy-policy__link ng-binding" target="_blank">Cookies</a>
        </div>
    </div>

    <!-- <cookie-bar is-visible="main.cookieBarVisible"></cookie-bar> -->
    <feedback-button><a class="feedback-button ng-binding" ng-click="vm.openModal()">Giv feedback</a>
</feedback-button>
    
</div><!-- end ngIf: !unsupportedBrowser -->
</div></div><div><div data-reactroot="" class="humany-floating-trigger humany_shipping-tool-da humany-has-icon humany-has-text humany-loaded"><a href="#"><b class="humany-icon"><span class="fa-stack fa-2x"><i class="humany-icon humany-custom-icon" style="background-image: url(&quot;data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTkiIGhlaWdodD0iMTkiIHZpZXdCb3g9IjAgMCAxOSAxOSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48dGl0bGU+Q29tYmluZWQgU2hhcGU8L3RpdGxlPjxwYXRoIGQ9Ik05LjUgMTlDNC4yNTMgMTkgMCAxNC43NDcgMCA5LjVTNC4yNTMgMCA5LjUgMCAxOSA0LjI1MyAxOSA5LjUgMTQuNzQ3IDE5IDkuNSAxOXptLTEuNjQ3LTYuOTc4aDIuNzdjLS4wODQtLjgxNi40MS0xLjIwNyAxLjI2LTEuNzg1IDEuMTM4LS43MyAyLjA1Ni0xLjUzIDIuMDU2LTMuMDI2IDAtMi4wNC0xLjM2LTMuMjk3LTQuMTY2LTMuMjk3LTEuNjUgMC0yLjczNy40MjUtMy41NTMuOXYyLjQ1aDEuNDNjLjMyMi0uMjczLjc0Ny0uNTQ1IDEuNDYtLjU0NS42MTMgMCAuOTcuMjU1Ljk3LjczIDAgLjU2Mi0uNTk1Ljk4Ny0xLjI3NSAxLjU4Mi0uODg0LjgxNi0xLjI1OCAxLjU0Ny0uOTUyIDIuOTkyek05LjI4IDE2LjEyYzEuMDIgMCAxLjg3LS43ODMgMS44Ny0xLjc1MiAwLTEuMDAzLS44NS0xLjc4NS0xLjg3LTEuNzg1LTEuMDM2IDAtMS44NTIuNzgyLTEuODUyIDEuNzg1IDAgLjk3LjgxNiAxLjc1IDEuODUzIDEuNzV6IiBmaWxsPSIjRkZGIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=&quot;); background-repeat: no-repeat; background-position: center center;"></i></span><b class="humany-icon-svg humany-close-icon"></b></b><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Customer service</font></font></span></a></div></div></body></html>